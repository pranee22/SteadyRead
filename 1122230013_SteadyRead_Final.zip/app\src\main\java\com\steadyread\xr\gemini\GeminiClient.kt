/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.gemini

import android.graphics.Bitmap
import android.util.Base64
import com.steadyread.xr.BuildConfig
import com.steadyread.xr.ui.NormalizedRect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/**
 * Minimal real Gemini calls (REST generateContent) with an optional camera image.
 *
 * Key and model come from local.properties:
 *   GEMINI_API_KEY=your-key
 *   GEMINI_MODEL=gemini-1.5-flash   (optional)
  * Developed by Praneetha Kamabathula.
 */
object GeminiClient {

    var forceOnDeviceMock: Boolean = false

    val isConfigured: Boolean
        get() = BuildConfig.GEMINI_API_KEY.isNotBlank() && !forceOnDeviceMock

    var userName: String = ""
    var userAge: Int? = null

    /** Whole object found at the tap point. [box] is 0..1 of the frame. */
    data class FoundObject(val label: String, val box: NormalizedRect, val isPerson: Boolean)

    private val NOT_OBJECTS = Regex(
        "\\b(person|people|face|faces|head|man|woman|boy|girl|child|baby|human|hand|hands|finger|fingers|arm|body|selfie|portrait)\\b",
        RegexOption.IGNORE_CASE
    )

    private fun systemInstruction(): String {
        val who = if (userName.isNotBlank()) userName else "the user"
        val age = userAge?.let { ", who is $it," } ?: ""
        return "You are the voice of SteadyRead, an assistant in AR glasses that helps $who$age read small print. " +
            "Use short sentences and everyday words. Never invent text you cannot see; if something is unclear, say so. " +
            "For medicine labels, repeat what the label says and suggest asking a pharmacist or doctor about anything beyond it. " +
            "Answer in plain text only: no markdown, no bullet symbols, no emoji. Keep answers under 60 words unless asked to write out everything."
    }

    /** Returns Gemini's answer text. Throws on network or API errors. */
    suspend fun generate(prompt: String, image: Bitmap? = null, json: Boolean = false): String = withContext(Dispatchers.IO) {
        val model = BuildConfig.GEMINI_MODEL.ifBlank { "gemini-1.5-flash" }
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")

        val parts = JSONArray()
        if (image != null) {
            val out = ByteArrayOutputStream()
            scaleDown(image).compress(Bitmap.CompressFormat.JPEG, 85, out)
            parts.put(JSONObject().put("inline_data", JSONObject()
                .put("mime_type", "image/jpeg")
                .put("data", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))))
        }
        parts.put(JSONObject().put("text", prompt))

        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
        if (json) {
            body.put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.1))
        } else {
            body.put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction()))))
        }

        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", BuildConfig.GEMINI_API_KEY)
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }.getOrNull()
                throw IllegalStateException("Gemini error $code: ${msg ?: text.take(200)}")
            }
            val candidates = JSONObject(text).optJSONArray("candidates")
            val answerParts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (answerParts != null) {
                for (i in 0 until answerParts.length()) sb.append(answerParts.optJSONObject(i)?.optString("text").orEmpty())
            }
            sb.toString().trim().ifBlank { throw IllegalStateException("Gemini returned no text") }
        } finally {
            conn.disconnect()
        }
    }

    /**
     * Find the WHOLE physical object at or nearest the tap point (0..1 of the frame).
     * People, faces and hands are never selected. Returns null when nothing is there.
     */
    suspend fun findObject(frame: Bitmap, tapX: Float, tapY: Float): FoundObject? {
        val px = (tapX * 1000).roundToInt()
        val py = (tapY * 1000).roundToInt()
        val prompt = """
            This is a camera frame from the user's AR glasses. The user tapped at x=$px, y=$py on a 0-1000 scale (x from the left edge, y from the top edge).

            Find the single physical object they mean: the object under that point, or the nearest one to it.
            Return the box of the WHOLE object (the entire card, page, letter, packet, bottle, box, screen or device), not just the area with text.
            Never return a person, a face, a head, a hand or any body part. If the point is on a person, choose the object they are holding or the nearest object instead. If there is no object at all, set found to false.

            Reply with JSON only:
            {"found": true, "label": "short everyday name, e.g. postcard", "box_2d": [ymin, xmin, ymax, xmax], "has_text": true}
            box_2d is on a 0-1000 scale.
        """.trimIndent()

        val text = generate(prompt, frame, json = true)
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        val obj = runCatching { JSONObject(text.substring(start, end + 1)) }.getOrNull() ?: return null
        if (!obj.optBoolean("found", true)) return null
        val arr = obj.optJSONArray("box_2d") ?: return null
        if (arr.length() != 4) return null

        val label = obj.optString("label", "Object").trim().ifBlank { "Object" }
            .replaceFirstChar { it.uppercase() }
        if (NOT_OBJECTS.containsMatchIn(label)) return FoundObject(label, NormalizedRect(), isPerson = true)

        var yMin = arr.optDouble(0).toFloat() / 1000f
        var xMin = arr.optDouble(1).toFloat() / 1000f
        var yMax = arr.optDouble(2).toFloat() / 1000f
        var xMax = arr.optDouble(3).toFloat() / 1000f
        if (listOf(yMin, xMin, yMax, xMax).any { it.isNaN() }) return null
        if (yMax < yMin) { val t = yMin; yMin = yMax; yMax = t }
        if (xMax < xMin) { val t = xMin; xMin = xMax; xMax = t }
        if (xMax - xMin < 0.02f || yMax - yMin < 0.02f) return null

        // pad slightly so the edges of the object are included
        val padX = (xMax - xMin) * 0.03f
        val padY = (yMax - yMin) * 0.03f
        val box = NormalizedRect(
            left = (xMin - padX).coerceIn(0f, 1f),
            top = (yMin - padY).coerceIn(0f, 1f),
            right = (xMax + padX).coerceIn(0f, 1f),
            bottom = (yMax + padY).coerceIn(0f, 1f)
        )
        return FoundObject(label, box, isPerson = false)
    }

    private fun scaleDown(src: Bitmap, maxSide: Int = 1024): Bitmap {
        val longest = maxOf(src.width, src.height)
        if (longest <= maxSide) return src
        val k = maxSide.toFloat() / longest
        return Bitmap.createScaledBitmap(src, (src.width * k).toInt(), (src.height * k).toInt(), true)
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
