﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.steadyread.xr.ui.AssistantVoice
import com.steadyread.xr.ui.SteadyReadARSceneViewport
import com.steadyread.xr.ui.theme.OstGlimmerTheme
import com.steadyread.xr.viewmodel.ARReadingLensViewModel
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Optical See-Through (OST) AI Glasses Entry Point for SteadyRead XR:
 * Sets transparent window decor, binds CameraX to stream live camera frames (laptop webcam
 * or phone camera) into ML Kit OCR + optical image magnification + webcam hand tracker,
 * and integrates Android TextToSpeech & SpeechRecognizer for voice conversation.
  * Developed by Praneetha Kamabathula.
 */
class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private val viewModel: ARReadingLensViewModel by viewModels()
    private lateinit var cameraExecutor: ExecutorService
    private var previewUseCase: Preview? = null
    private var tts: TextToSpeech? = null
    private var isTtsReady: Boolean = false
    private var speechRecognizer: SpeechRecognizer? = null

    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants[Manifest.permission.CAMERA] == true || grants["horizonos.permission.HEADSET_CAMERA"] == true) {
            startCameraX()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()

        // Ensure 100% additive transparency for Optical See-Through AI Glasses
        window.setBackgroundDrawableResource(android.R.color.transparent)
        window.decorView.setBackgroundColor(android.graphics.Color.TRANSPARENT)

        // Initialize TextToSpeech & SpeechRecognizer hooks
        tts = TextToSpeech(this, this)
        setupVoiceHooks()

        // Request camera & microphone permissions and start CameraX live streaming
        checkPermissionsAndStart()

        // On first launch, display the Setup + Instructions guide
        viewModel.startOnboarding()

        setContent {
            val textSizePref by viewModel.textSizePreference.collectAsState()

            OstGlimmerTheme(bodyVisualAngleDegrees = textSizePref.bodyAngleDegrees) {
                SteadyReadARSceneViewport(viewModel = viewModel)
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            isTtsReady = true
        }
    }

    private fun setupVoiceHooks() {
        viewModel.onSpeakTextListener = { rawResponse, voice ->
            if (isTtsReady && voice != AssistantVoice.MUTED) {
                val cleanSpeech = rawResponse
                    .replace("[Clear Voice]", "")
                    .replace("[Calm Voice]", "")
                    .replace("[Concise]", "")
                    .trim()

                when (voice) {
                    AssistantVoice.CLEAR_LOUD -> {
                        tts?.setPitch(1.0f)
                        tts?.setSpeechRate(0.92f)
                    }
                    AssistantVoice.WARM_CALM -> {
                        tts?.setPitch(0.95f)
                        tts?.setSpeechRate(0.85f)
                    }
                    AssistantVoice.CRISP_CONCISE -> {
                        tts?.setPitch(1.05f)
                        tts?.setSpeechRate(1.10f)
                    }
                    AssistantVoice.MUTED -> {}
                }
                tts?.speak(cleanSpeech, TextToSpeech.QUEUE_FLUSH, null, "steadyread_utt")
            }
        }

        viewModel.onStartSpeechListeningListener = {
            startHardwareSpeechRecognition()
        }
    }

    private fun startHardwareSpeechRecognition(): Boolean {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return false
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            return false
        }

        return try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {}
                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {}
                        override fun onError(error: Int) {
                            viewModel.onSpeechRecognitionFallback()
                        }
                        override fun onResults(results: Bundle?) {
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val spoken = matches?.firstOrNull().orEmpty()
                            if (spoken.isNotBlank()) {
                                viewModel.onSpeechRecognized(spoken)
                            } else {
                                viewModel.onSpeechRecognitionFallback()
                            }
                        }
                        override fun onPartialResults(partialResults: Bundle?) {}
                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            speechRecognizer?.startListening(intent)
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun checkPermissionsAndStart() {
        val camGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val micGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        if (camGranted) {
            startCameraX()
        }
        if (!camGranted || !micGranted) {
            permissionsLauncher.launch(
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO) +
                    (if (isMetaQuest) arrayOf("horizonos.permission.HEADSET_CAMERA") else emptyArray<String>())
            )
        }
    }

    private fun startCameraX() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build()
            previewUseCase = preview

            lifecycleScope.launch {
                repeatOnLifecycle(Lifecycle.State.STARTED) {
                    viewModel.cameraSurfaceProvider.collect { provider ->
                        if (provider != null) {
                            preview.setSurfaceProvider(provider)
                        }
                    }
                }
            }

            val imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor, viewModel.ocrPipeline)
                }

            // Initialize Google MediaPipe 21-joint 3D hand tracker for the webcam stream
            viewModel.ocrPipeline.initMediaPipeTracker(this)

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, questPassthroughSelector() ?: CameraSelector.DEFAULT_BACK_CAMERA, preview, imageAnalysis)
            } catch (e: Exception) {
                try {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, imageAnalysis)
                } catch (_: Exception) {
                    // Last resort for devices that report no back or front camera: use any camera
                    try {
                        cameraProvider.unbindAll()
                        val anyCamera = CameraSelector.Builder().addCameraFilter { it.take(1) }.build()
                        cameraProvider.bindToLifecycle(this, anyCamera, preview, imageAnalysis)
                    } catch (_: Exception) {
                        // Camera not available in current environment
                    }
                }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // ========================================================================
    // Meta Quest 3/3S: passthrough camera (only used when running on a Quest)
    // ========================================================================

    private val isMetaQuest: Boolean
        get() = Build.MANUFACTURER.equals("Oculus", ignoreCase = true) ||
            Build.MANUFACTURER.contains("Meta", ignoreCase = true)

    /** Left passthrough RGB camera, found by Meta's Camera2 vendor tags. Null on other devices. */
    @androidx.annotation.OptIn(markerClass = [ExperimentalCamera2Interop::class])
    private fun questPassthroughSelector(): CameraSelector? {
        if (!isMetaQuest) return null
        return try {
            val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val sourceKey = CameraCharacteristics.Key("com.meta.extra_metadata.camera_source", Int::class.javaObjectType)
            val positionKey = CameraCharacteristics.Key("com.meta.extra_metadata.position", Int::class.javaObjectType)
            val passthrough = manager.cameraIdList.filter { id ->
                runCatching { manager.getCameraCharacteristics(id).get(sourceKey) }.getOrNull() == 0
            }
            val chosen = passthrough.firstOrNull { id ->
                runCatching { manager.getCameraCharacteristics(id).get(positionKey) }.getOrNull() == 0
            } ?: passthrough.firstOrNull() ?: return null
            CameraSelector.Builder()
                .addCameraFilter { infos -> infos.filter { Camera2CameraInfo.from(it).cameraId == chosen } }
                .build()
        } catch (_: Throwable) {
            null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.stop()
        tts?.shutdown()
        speechRecognizer?.destroy()
        cameraExecutor.shutdown()
    }

    fun attachXrRuntimeSession(session: androidx.xr.runtime.Session) {
        viewModel.spatialGroundingManager.bindArCoreSession(lifecycleScope, session)
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
