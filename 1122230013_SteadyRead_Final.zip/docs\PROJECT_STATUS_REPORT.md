# SteadyRead XR — Comprehensive System Architecture & Project Status Report

**Author & Lead Researcher:** Praneetha Kamabathula  
**Copyright:** © 2026 Praneetha Kamabathula. All rights reserved.  
**Document Version:** 1.0.0  
**Date:** October 30, 2026  
**Application Target:** Optical See-Through (OST) Smart Glasses & Android XR (with Laptop/Phone Webcam Testing Suite)  
**Package:** `com.steadyread.xr`  
**Active Repository Path:** `E:\Antigravity`  

---

## 1. Executive Summary & Core Philosophy

**SteadyRead XR** is a spatial assistive augmented reality reading application engineered for elderly individuals and users with essential tremors, Parkinson's disease, post-stroke motor impairment, and low vision.

### The Foundational Principle
> **Physical objects shake; digital text must remain anchored and still.**

When an elderly user holds a postcard, prescription label, or receipt, involuntary motor tremor (typically 4–8 Hz) causes the paper to vibrate rapidly, rendering small print unreadable and degrading standard mobile OCR cameras. SteadyRead XR decouples the physical shaking object from the reading interface:
1. **Camera Capture & Motion Stabilization**: Optical tracking captures high-resolution frames, detects text regions, and stabilizes spatial coordinates.
2. **True Optical Magnification**: Rather than displaying synthesized OCR text alone, the user can inspect a stabilized, magnified optical image (1.5x–6.0x) with low-vision contrast filters to verify critical details (dates, dosage, names).
3. **Additive Optical Display**: Pure black (`#000000`) renders as 100% transparent glass on optical see-through waveguides, ensuring zero visual obstruction of the physical environment.
4. **HoloLens Spatial Interaction**: Gross-motor air-taps and directional targeting replace fine pinch gestures or precision dwell timers that fail for shaky hands.

---

## 2. System Architecture Diagram

```mermaid
flowchart TD
    subgraph SENSORS["1. Input & Sensor Layer"]
        CAM["Webcam / Glasses RGB Camera<br/>(CameraX ImageAnalysis)"]
        MIC["Audio Mic Input<br/>(SpeechRecognizer)"]
        PTR["Pointer / Mouse Simulation<br/>(Virtual XR Gaze & Tap)"]
    end

    subgraph VISION["2. Vision & Tracking Pipeline"]
        MP["Google MediaPipe Tasks Vision<br/>(21 3D Joint Hand Landmarker)"]
        LUMA["Fallback Optical Motion Tracker<br/>(32x24 Luminance Grid)"]
        OCR["Google ML Kit Text Recognition v2<br/>(Spatial Bounding Boxes)"]
    end

    subgraph INTERACTION["3. Tremor Damping & Interaction Engine"]
        TAP_FILT["CalibratedTapFilter<br/>(Velocity Gating & Bounce Debounce)"]
        TREMOR_DAMP["Low-Pass 4-8 Hz Jitter Filter<br/>(Smoothed Holographic Focus Ray)"]
        GRIP["GripGuidanceService<br/>(Occupational Therapy Bracing Hints)"]
        SPATIAL["SpatialGroundingManager<br/>(SceneCore & Head-Pose Blending)"]
    end

    subgraph AI["4. Multimodal Reasoning Layer"]
        GEMINI["Gemini 2.5 Flash API<br/>(Image + Text Bounding Prompt)"]
        ON_DEVICE["On-Device Fallback Engine<br/>(Deterministic Offline Ingestion)"]
        TTS["Text-To-Speech Service<br/>(Clear / Warm / Concise Voices)"]
    end

    subgraph UI["5. OST Glimmer UI Layer"]
        HUD["SteadyReadGlassesApp<br/>(GlimmerTheme Additive Canvas)"]
        SKELETON["HandTrackingHudOverlay<br/>(Cyan Holographic Bones & Nodes)"]
        RETICLE["SpatialObjectTargetReticle<br/>(Corner L-Brackets & Target Lock)"]
        PANELS["Expandable Reading Panels<br/>(Magnify, Summary, Q&A Chips)"]
    end

    CAM --> MP
    CAM --> LUMA
    CAM --> OCR
    PTR --> TAP_FILT

    MP --> TAP_FILT
    MP --> TREMOR_DAMP
    LUMA --> TREMOR_DAMP

    OCR --> SPATIAL
    OCR --> GEMINI
    CAM --> GEMINI

    TAP_FILT --> HUD
    TREMOR_DAMP --> SKELETON
    SPATIAL --> RETICLE
    GEMINI --> PANELS
    ON_DEVICE --> PANELS
    MIC --> GEMINI
    PANELS --> TTS
```

---

## 3. Subsystem Breakdown & Implementation Details

### 3.1. Optical See-Through Display & Glimmer Theme
- **Implementation File:** [`OstGlimmerTheme.kt`](file:///E:/Antigravity/app/src/main/java/com/steadyread/xr/ui/theme/OstGlimmerTheme.kt) & [`SteadyReadGlassesApp.kt`](file:///E:/Antigravity/app/src/main/java/com/steadyread/xr/ui/SteadyReadGlassesApp.kt)
- **Framework:** Jetpack Compose Glimmer (`androidx.xr.glimmer:glimmer:1.0.0-alpha22`) and Glimmer Google Fonts.
- **Additive Optical Palette:**
  - Deep Background: Pure black `#000000` (rendered as 100% transparent in optical waveguide lenses).
  - High-Contrast Text: High-luminance white `#FFFFFF` and warm amber `#FFB74D`.
  - Holographic Targeting: Cyber cyan `#00E5FF` and interactive emerald green `#9FD8A8`.
- **Angular Typography:** Implements visual angle scaling (`ssp`). The minimum readable font size is locked to 18sp (0.6° visual angle at 1 meter), eliminating shimmering thin weights that cause eyestrain.

### 3.2. Google MediaPipe 21-Joint 3D Hand Tracking
- **Implementation Files:** [`MediaPipeHandTracker.kt`](file:///E:/Antigravity/app/src/main/java/com/steadyread/xr/interaction/MediaPipeHandTracker.kt) & [`SteadyReadOcrPipeline.kt`](file:///E:/Antigravity/app/src/main/java/com/steadyread/xr/ocr/SteadyReadOcrPipeline.kt)
- **Model Asset:** [`hand_landmarker.task`](file:///E:/Antigravity/app/src/main/assets/hand_landmarker.task) (7.8 MB float16 model bundled in assets).
- **Capabilities:**
  - Tracks 21 3D landmarks in real time per frame from standard RGB webcam/camera feeds.
  - Computes index fingertip velocity ($v > 0.30\text{ m/s}$) to recognize downward air-tap strikes.
  - Implements a 350 ms refractory window to eliminate double-tap tremor bounces.
  - Detects index-to-thumb pinch distance ($d < 0.065$) and bilateral palm distance for two-hand stretch zoom (§3.5 of design doc).
  - Falls back seamlessly to a 32×24 luminance optical flow grid when no hands are in view.

### 3.3. HoloLens Holographic HUD Overlay
- **Implementation File:** [`SteadyReadGlassesApp.kt#HandTrackingHudOverlay`](file:///E:/Antigravity/app/src/main/java/com/steadyread/xr/ui/SteadyReadGlassesApp.kt)
- **Visuals Rendered:**
  - **Holographic Bones:** Cyan line segments connecting wrist to knuckle roots, and knuckles to finger tips.
  - **Joint Nodes:** Glowing circular endpoints on every articulation.
  - **Raw Tremor Ring:** Amber circle (`#FFB74D`) illustrating raw hand oscillation.
  - **Damping Vector:** Damping connector visualizing real-time algorithmic jitter attenuation.
  - **Stabilized HoloLens Reticle:** High-contrast green dual-ring cursor locked to the stabilized focus vector.

### 3.4. Optical Magnifier & Verification Engine
- **Implementation File:** [`ARReadingLensViewModel.kt`](file:///E:/Antigravity/app/src/main/java/com/steadyread/xr/viewmodel/ARReadingLensViewModel.kt)
- **Capabilities:**
  - Performs live spatial cropping of the high-resolution frame centered on the active target bounding box.
  - Continuous zoom range: 1.5x to 6.0x with drag-to-pan support.
  - Image freeze/unfreeze toggle for comfortable handheld inspection without arm fatigue.
  - Three specialized low-vision contrast matrix modes:
    1. *Natural*: Unaltered color spectrum.
    2. *High Contrast*: Amplified edge separation.
    3. *Inverted B&W*: High-contrast white-on-black for cataracts and macular degeneration.

### 3.5. Gemini 2.5 Flash Multimodal Live Assistant
- **Implementation Files:** [`GeminiClient.kt`](file:///E:/Antigravity/app/src/main/java/com/steadyread/xr/gemini/GeminiClient.kt) & [`GeminiLiveAssistantService.kt`](file:///E:/Antigravity/app/src/main/java/com/steadyread/xr/gemini/GeminiLiveAssistantService.kt)
- **Key & Model Injection:** Secured via `local.properties` (`GEMINI_API_KEY` and `GEMINI_MODEL=gemini-1.5-flash`), injected into `BuildConfig`.
- **Multimodal Prompting:** Passes the real cropped frame image along with OCR text and spatial bounding coordinates.
- **Dynamic Context Adaptation:** Generates context-specific suggestion chips based on what was scanned (postcards, medication bottles, mail, bills, grocery items).
- **Clean Typography:** Zero emojis across all assistant responses and UI surfaces.
- **Deterministic Offline Fallback:** If internet connectivity drops, the on-device synthesis engine automatically fulfills queries without failing or stranding the senior user.

### 3.6. First-Run Setup & 5-Step Calibration Wizard
- **Implementation File:** [`GlassesCalibrationCard`](file:///E:/Antigravity/app/src/main/java/com/steadyread/xr/ui/SteadyReadGlassesApp.kt)
- **Steps:**
  1. *Personal Text Size*: Interactive visual angle slider / stretch zoom.
  2. *Rest Tremor Measurement*: 5-second palm hold measuring resting jitter amplitude ($A_{\text{tremor}}$).
  3. *Air-Tap Velocity Calibration*: 5 air-taps measuring downward velocity and bounce timing.
  4. *Aim Cone Calibration*: Directional taps toward multi-angle targets.
  5. *Summary & Confirmation*: Generates customized user profile (`tapVelocityThresholdMps`, `refractoryWindowMs`, `zoneScale`, `aimConeDegrees`).

---

## 4. Source Tree & File Map

```
E:\Antigravity
├── app
│   ├── build.gradle.kts                          # AGP 9.5.0, compileSdk 37, MediaPipe, Glimmer, CameraX
│   └── src
│       ├── main
│       │   ├── AndroidManifest.xml               # Permissions (CAMERA, AUDIO) & XR categories
│       │   ├── assets
│       │   │   └── hand_landmarker.task          # Google MediaPipe 21-joint 3D neural model
│       │   └── java/com/steadyread/xr
│       │       ├── MainActivity.kt               # Lifecycle, CameraX executor, MediaPipe init, TTS
│       │       ├── gemini
│       │       │   ├── GeminiClient.kt           # Multimodal REST generateContent client
│       │       │   └── GeminiLiveAssistantService.kt # Context chips, fallback synthesis, Q&A
│       │       ├── grip
│       │       │   └── GripGuidanceService.kt    # OT-informed ergonomic bracing recommendations
│       │       ├── interaction
│       │       │   ├── CalibratedTapFilter.kt    # Velocity gating, refractory debounce, aim cone
│       │       │   ├── MediaPipeHandTracker.kt   # Real-time 21-joint 3D hand & gesture tracking
│       │       │   └── TremorReachZoneController.kt # Gross-motor reach boundary mapping
│       │       ├── ocr
│       │       │   ├── MultiFrameOcrStabilizer.kt# Multi-frame bounding box hysteresis
│       │       │   └── SteadyReadOcrPipeline.kt  # CameraX ImageAnalysis, ML Kit, MediaPipe hook
│       │       ├── spatial
│       │       │   └── SpatialGroundingManager.kt# Spatial anchors and head-pose blending
│       │       ├── summary
│       │       │   └── LabelSummarizerService.kt # On-device label segmentation and key fields
│       │       ├── ui
│       │       │   ├── ARReadingLens.kt          # Secondary modular lens composables
│       │       │   ├── LensState.kt              # State machine definitions & telemetry structs
│       │       │   ├── SteadyReadGlassesApp.kt   # Core Glimmer HUD, HandTrackingHudOverlay, Reticle
│       │       │   ├── SteadyReadViewport.kt     # Top-level scene viewport bridge
│       │       │   └── theme
│       │       │       └── OstGlimmerTheme.kt    # Additive colors, angular typography, shapes
│       │       └── viewmodel
│       │           └── ARReadingLensViewModel.kt # State machine coordinator, calibration logic
│       └── test/java/com/steadyread/xr
│           └── TremorHysteresisAndStateTest.kt   # Deterministic unit test suite (8 tests)
├── gradle
│   └── libs.versions.toml                        # Version catalog (Glimmer, MediaPipe, CameraX, Compose)
├── local.properties                              # Local SDK paths and GEMINI_API_KEY
└── gradle.properties                             # JVM args, JBR 25 installation path, AndroidX flags
```

---

## 5. State Machine & User Flow

```mermaid
stateDiagram-v2
    [*] --> Onboarding: First Launch
    Onboarding --> SetupInstructions: Profile Saved
    SetupInstructions --> Calibrating: Start Calibration
    SetupInstructions --> Browsing: Dismiss Guide
    Calibrating --> Browsing: Complete 5 Steps

    state Browsing {
        [*] --> EnvironmentScan
        EnvironmentScan --> TargetAcquired: Reticle Over Text
    }

    Browsing --> ObjectTargeted: Directional Air-Tap / Touch
    ObjectTargeted --> PanelExpanded: Select Magnify / Summarize / Ask
    ObjectTargeted --> Browsing: Tap "Close" or Aim Away

    state PanelExpanded {
        [*] --> MagnifyView
        [*] --> SummaryView
        [*] --> GeminiLiveView
        MagnifyView --> GeminiLiveView: Ask Question Chip
    }

    PanelExpanded --> Browsing: Close Panel / Aim Away
    Browsing --> SettingsSheet: Tap "Settings"
    SettingsSheet --> Browsing: Close Settings
```

---

## 6. Verification & Build Status

| Component | Status | Notes |
|---|---|---|
| **Compilation** | **PASS** | Gradle build completed (`assembleDebug`) with zero warnings/errors. |
| **Unit Tests** | **PASS (8/8)** | `testDebugUnitTest` passes offline; `GeminiClient.forceOnDeviceMock` isolates tests. |
| **MediaPipe Model** | **READY** | `hand_landmarker.task` bundled in APK assets (`Length: 7,819,105 bytes`). |
| **Gemini Integration** | **ACTIVE** | Configured with `gemini-1.5-flash` in `local.properties`. |
| **Typography & UI** | **CLEAN** | 100% emoji-free, compliant with Glimmer OST visual angle guidelines. |
| **HoloLens Compatibility**| **READY** | Designed for Jetpack XR / Android XR; runs with MediaPipe RGB fallback on laptops. |
| **APK Output** | **GENERATED** | `E:\Antigravity\app\build\outputs\apk\debug\app-debug.apk` |

---

## 7. How to Run & Demonstrate

### Scenario A: Testing on Laptop / PC (Webcam + Emulator)
1. Launch your Android emulator with camera input set to **Webcam0** (Device Manager > Edit Virtual Device > Advanced > Camera > Front/Back: Webcam0).
2. Install and launch the APK:
   ```powershell
   E:\Android\Sdk\platform-tools\adb.exe install -r E:\Antigravity\app\build\outputs\apk\debug\app-debug.apk
   E:\Android\Sdk\platform-tools\adb.exe shell am start -n com.steadyread.xr/.MainActivity
   ```
3. Hold up your hand: observe the holographic cyan joint skeleton, amber tremor ring, and stabilized green reticle tracking your index finger.
4. Make a downward tap gesture in the air to execute an air-tap.

### Scenario B: Testing with Physical Android Phone Connected via USB
1. Enable Developer Options & USB Debugging on your phone.
2. Run the same `adb install` command above.
3. Point your camera at a postcard, medicine bottle, or printed letter to test live OCR bounding, true optical magnification, and Gemini question chips.

### Scenario C: Testing on Professor's HoloLens / XR Headset
1. Connect the headset via ADB (USB or Wi-Fi).
2. The app's additive transparent canvas (`#000000` = transparent) displays floating holographic cards and reticles directly over the wearer's real-world optical view.
