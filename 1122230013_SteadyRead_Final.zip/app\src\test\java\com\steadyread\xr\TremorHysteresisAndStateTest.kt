﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr

import com.steadyread.xr.grip.GripGuidanceService
import com.steadyread.xr.interaction.CalibratedTapFilter
import com.steadyread.xr.ocr.MultiFrameOcrStabilizer
import com.steadyread.xr.spatial.Vec3Meters
import com.steadyread.xr.summary.LabelSummarizerService
import com.steadyread.xr.ui.CalibrationStep
import com.steadyread.xr.ui.LensAction
import com.steadyread.xr.ui.LensState
import com.steadyread.xr.ui.ReadProblem
import com.steadyread.xr.ui.TextSizePreference
import com.steadyread.xr.ui.TremorProfile
import com.steadyread.xr.viewmodel.ARReadingLensViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class TremorHysteresisAndStateTest {

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        com.steadyread.xr.gemini.GeminiClient.forceOnDeviceMock = true
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
        com.steadyread.xr.gemini.GeminiClient.forceOnDeviceMock = false
    }

    @Test
    fun `calibrated tap filter requires velocity above threshold and suppresses secondary bounces`() {
        val filter = CalibratedTapFilter(
            profile = TremorProfile(
                tapVelocityThresholdMps = 0.35f,
                refractoryWindowMs = 380L
            )
        )

        // 1. Slow movement (< 0.35 m/s) -> Ignored
        assertFalse(filter.evaluateTapStrike(currentVelocityMps = 0.20f, timestampMs = 1000L))

        // 2. High velocity deliberate tap strike (> 0.35 m/s) -> Accepted!
        assertTrue(filter.evaluateTapStrike(currentVelocityMps = 0.45f, timestampMs = 1050L))

        // 3. Involuntary tremor rebound / secondary strike 120ms later (< 380ms refractory) -> Suppressed!
        assertFalse(filter.evaluateTapStrike(currentVelocityMps = 0.50f, timestampMs = 1170L))

        // 4. Intentional second tap 450ms later (> 380ms refractory window) -> Accepted!
        assertTrue(filter.evaluateTapStrike(currentVelocityMps = 0.40f, timestampMs = 1550L))
    }

    @Test
    fun `directional tap resolves candidate object within aim cone`() {
        val filter = CalibratedTapFilter(profile = TremorProfile(aimConeDegrees = 25.0f))

        val handOrigin = Vec3Meters(0f, -0.1f, -0.3f)
        val handDirection = Vec3Meters(0f, 0f, 1f)
        val headGaze = Vec3Meters(0f, 0f, 1f)

        val candidates = listOf(
            "object_near_center" to Vec3Meters(0.02f, -0.1f, 0.4f),
            "object_way_off_to_side" to Vec3Meters(0.85f, -0.1f, 0.4f)
        )

        val target = filter.resolveDirectionalTarget(handOrigin, handDirection, headGaze, candidates)
        assertEquals("object_near_center", target)
    }

    @Test
    fun `label summarizer dynamically parses arbitrary objects into categorized verbatim chips`() {
        val summarizer = LabelSummarizerService()

        // 1. Pointed at Food Packaging
        val cerealBox = """
            ORGANIC OAT CRUNCH CEREAL
            ALLERGEN WARNING: CONTAINS ALMONDS AND PEANUTS
            DIRECTIONS: SERVE WITH COLD MILK
            180 CAL • 5G PROTEIN
            BEST BY 08/2027
        """.trimIndent()

        val cerealSummary = summarizer.summarizeObject(cerealBox)
        assertEquals("ORGANIC OAT CRUNCH CEREAL", cerealSummary.dynamicTitle)
        assertTrue(cerealSummary.chips.any { it.category == "Warnings & Cautions" && it.verbatimValue.contains("ALMONDS") })
        assertTrue(cerealSummary.chips.any { it.category == "Instructions & Directions" && it.verbatimValue.contains("COLD MILK") })
        assertTrue(cerealSummary.chips.any { it.category == "Dates & Validity" && it.verbatimValue.contains("08/2027") })

        // 2. Pointed at Electronics Hardware
        val router = """
            AC1900 GIGABIT WI-FI ROUTER
            CAUTION: DO NOT OPEN ENCLOSURE • HAZARD
            DIRECTIONS: CONNECT ETHERNET CABLE BEFORE POWERING ON
            12V 2.0A • 24W MAX
        """.trimIndent()

        val routerSummary = summarizer.summarizeObject(router)
        assertEquals("AC1900 GIGABIT WI-FI ROUTER", routerSummary.dynamicTitle)
        assertTrue(routerSummary.chips.any { it.category == "Warnings & Cautions" && it.verbatimValue.contains("CAUTION") })
        assertTrue(routerSummary.chips.any { it.category == "Specifications & Amounts" && it.verbatimValue.contains("12V") })
    }

    @Test
    fun `viewModel dynamically updates and summarizes whatever object is pointed at`() {
        val viewModel = ARReadingLensViewModel()

        // User points at an arbitrary food package
        val scannedPackaging = """
            ALMOND MILK VANILLA
            CONTAINS TREE NUTS (ALMONDS)
            KEEP REFRIGERATED • SHAKE WELL
            60 CAL PER 240ML
            EXP: 10/2027
        """.trimIndent()

        // Live OCR feeds the scanned object text
        viewModel.onLiveOcrTextScanned(scannedPackaging, objectIdentifier = "carton_almond_milk")

        // Select and execute Summarize
        viewModel.onDirectionalTap(handStrikeVelocityMps = 0.45f, timestampMs = 1000L)
        viewModel.confirmObjectSelection()
        viewModel.executeAction(LensAction.SUMMARIZE)

        val state = viewModel.lensState.value as LensState.SummaryChips
        assertEquals("ALMOND MILK VANILLA", state.title)
        assertTrue(state.chips.any { it.category == "Warnings & Cautions" })
        assertTrue(state.chips.any { it.category == "Dates & Validity" })
    }

    @Test
    fun `multi-frame stabilizer filters blurry frames and reaches consensus`() {
        val stabilizer = MultiFrameOcrStabilizer(consensusThresholdFrames = 2)

        // Blurry frame (edge variance < 140) -> Dropped
        val (sharp1, _) = stabilizer.isFrameSharp(averageBrightness = 120f, edgeVarianceScore = 80f)
        assertFalse(sharp1)

        // Sharp frames -> Accepted
        val (sharp2, _) = stabilizer.isFrameSharp(averageBrightness = 120f, edgeVarianceScore = 190f)
        assertTrue(sharp2)

        // First sharp observation
        val res1 = stabilizer.ingestFrameText(listOf("PROPRANOLOL 25MG"), timestampMs = 100L)
        assertEquals(0.40f, res1.confidence, 0.01f)

        // Second sharp observation (meets consensus threshold of 2)
        val res2 = stabilizer.ingestFrameText(listOf("PROPRANOLOL 25MG"), timestampMs = 250L)
        assertEquals(0.94f, res2.confidence, 0.01f)
        assertEquals("PROPRANOLOL 25MG", res2.consolidatedHeadline)
    }

    @Test
    fun `viewModel transitions through full setup calibration and action execution`() {
        val viewModel = ARReadingLensViewModel()

        // 1. Initial State: Browsing
        assertTrue(viewModel.lensState.value is LensState.Browsing)

        // 2. Start Calibration Flow
        viewModel.startCalibrationFlow()
        assertTrue(viewModel.lensState.value is LensState.Calibrating)

        // Step up text size
        val initialSize = viewModel.textSizePreference.value.bodyAngleDegrees
        viewModel.stepTextSizeUp()
        assertTrue(viewModel.textSizePreference.value.bodyAngleDegrees > initialSize)

        // Advance through calibration steps
        viewModel.advanceCalibrationStep() // -> Rest Measurement
        viewModel.advanceCalibrationStep() // -> Tap Measurement
        viewModel.advanceCalibrationStep() // -> Tap count increment
        viewModel.advanceCalibrationStep()
        viewModel.advanceCalibrationStep()
        viewModel.advanceCalibrationStep()
        viewModel.advanceCalibrationStep() // -> Aim Measurement
        viewModel.advanceCalibrationStep()
        viewModel.advanceCalibrationStep()
        viewModel.advanceCalibrationStep()
        viewModel.advanceCalibrationStep() // -> Completed
        viewModel.advanceCalibrationStep() // -> Back to Browsing

        assertTrue(viewModel.lensState.value is LensState.Browsing)

        // 3. Directional Tap selects object
        viewModel.onDirectionalTap(handStrikeVelocityMps = 0.45f, timestampMs = 1000L)
        assertTrue(viewModel.lensState.value is LensState.ObjectSelected)

        // 4. Confirm selection opens Action Menu
        viewModel.confirmObjectSelection()
        assertTrue(viewModel.lensState.value is LensState.ActionMenu)

        viewModel.onLiveOcrTextScanned("METFORMIN HCL 500 MG", "item_1")

        // 5. Execute Summarize
        viewModel.executeAction(LensAction.SUMMARIZE)
        val summaryState = viewModel.lensState.value as LensState.SummaryChips
        assertTrue(summaryState.chips.isNotEmpty())

        // 6. Execute Grip Guidance
        viewModel.executeAction(LensAction.HOW_TO_HOLD)
        val gripState = viewModel.lensState.value as LensState.GripGuidance
        assertTrue(gripState.grip.braceElbow)

        // 7. Execute Magnify
        viewModel.executeAction(LensAction.MAGNIFY)
        val magnifyState = viewModel.lensState.value as LensState.Magnified
        assertEquals("METFORMIN HCL 500 MG", magnifyState.keyText)
    }

    @Test
    fun `glasses interaction flow - setup, single tap settings, and double tap bubble with AI chips`() = kotlinx.coroutines.test.runTest {
        val viewModel = ARReadingLensViewModel(startWithSetupInstructions = true)

        // 1. Initial launch shows Setup + Instructions
        assertTrue(viewModel.lensState.value is LensState.SetupInstructions)

        // 2. User dismisses setup -> Enters clean Browsing (Idle) state
        viewModel.dismissSetupInstructions()
        assertTrue(viewModel.lensState.value is LensState.Browsing)
        assertFalse(viewModel.isPeripheralSettingsVisible.value)

        // 3. Single-tap reveals peripheral settings button
        viewModel.onSingleTap()
        assertTrue(viewModel.isPeripheralSettingsVisible.value)

        // Open settings, toggle tremor off -> Show grip is disabled
        viewModel.openSettings()
        assertTrue(viewModel.isSettingsOpen.value)

        viewModel.toggleTremorAssistance(false)
        assertFalse(viewModel.tremorProfile.value.isTremorAssistanceEnabled)
        assertFalse(viewModel.tremorProfile.value.isShowGripEnabled)

        // Re-enable tremor assistance and show grip
        viewModel.toggleTremorAssistance(true)
        viewModel.toggleShowGrip(true)
        assertTrue(viewModel.tremorProfile.value.isTremorAssistanceEnabled)
        assertTrue(viewModel.tremorProfile.value.isShowGripEnabled)

        // Adjust font scaling
        viewModel.updateTextSizeDegrees(1.8f)
        assertEquals(1.8f, viewModel.textSizePreference.value.bodyAngleDegrees, 0.01f)

        // Change assistant voice
        viewModel.setAssistantVoice(com.steadyread.xr.ui.AssistantVoice.WARM_CALM)
        assertEquals(com.steadyread.xr.ui.AssistantVoice.WARM_CALM, viewModel.assistantVoice.value)

        viewModel.closeSettings()
        assertFalse(viewModel.isSettingsOpen.value)

        // 4. Double-tap at an object -> summons side action bubble
        viewModel.onLiveOcrTextScanned("AMOXICILLIN 500MG CAPSULE\nTAKE 1 CAPSULE WITH WATER\nEXP 09/2027", "bottle_amoxicillin")
        viewModel.onDoubleTap(targetObjectId = "bottle_amoxicillin")
        val targeted = viewModel.lensState.value as LensState.ObjectTargeted
        assertEquals("bottle_amoxicillin", targeted.target.id)

        // With Tremor Assistance ON and Show Grip ON, all 4 actions are present
        assertTrue(targeted.availableActions.contains(LensAction.MAGNIFY))
        assertTrue(targeted.availableActions.contains(LensAction.SUMMARIZE))
        assertTrue(targeted.availableActions.contains(LensAction.HOW_TO_HOLD))
        assertTrue(targeted.availableActions.contains(LensAction.CLOSE))

        // If Tremor Assistance is turned off, Show Grip is removed from available actions
        viewModel.toggleTremorAssistance(false)
        val updatedTargeted = viewModel.lensState.value as LensState.ObjectTargeted
        assertFalse(updatedTargeted.availableActions.contains(LensAction.HOW_TO_HOLD))

        // Turn tremor assistance back on
        viewModel.toggleTremorAssistance(true)
        viewModel.toggleShowGrip(true)

        // 5. Select "Summarize" -> Expands panel next to object with AI response chips
        viewModel.onSelectTargetAction(LensAction.SUMMARIZE)
        val expanded = viewModel.lensState.value as LensState.PanelExpanded
        assertEquals(LensAction.SUMMARIZE, expanded.selectedAction)
        assertTrue(expanded.resultDetails.isNotEmpty())
        assertTrue(expanded.aiChips.isNotEmpty())

        // 6. Click an AI response chip -> invokes Gemini Live assistance
        val testChip = expanded.aiChips.first()
        viewModel.onAiChipClicked(testChip)

        // Advance coroutines on test dispatcher
        advanceUntilIdle()

        val updatedExpanded = viewModel.lensState.value as LensState.PanelExpanded
        assertTrue(updatedExpanded.conversationLog.isNotEmpty())
        assertTrue(updatedExpanded.conversationLog.any { it.isGemini })
        assertTrue(updatedExpanded.aiChips.isNotEmpty())

        // 7. Close expanded panel
        viewModel.closeExpandedPanel()
        assertTrue(viewModel.lensState.value is LensState.ObjectTargeted)

        viewModel.onSelectTargetAction(LensAction.CLOSE)
        assertTrue(viewModel.lensState.value is LensState.Browsing)
    }

    @Test
    fun `scanning a postcard generates postcard-specific questions and context-grounded answers`() = kotlinx.coroutines.test.runTest {
        val viewModel = ARReadingLensViewModel()

        val postcardText = """
            GREETINGS FROM GRAND CANYON
            Dear Grandma,
            We are having a wonderful trip in Arizona!
            See you on October 30.
            Love, Maya
        """.trimIndent()

        viewModel.onLiveOcrTextScanned(postcardText, objectIdentifier = "postcard_1")
        viewModel.onDoubleTap(targetObjectId = "postcard_1")

        val targeted = viewModel.lensState.value as LensState.ObjectTargeted
        assertEquals("postcard mail", targeted.target.category)
        assertNotNull(targeted.target.grip)
        assertTrue(targeted.target.grip!!.title.contains("Card Grip"))

        // Expand Summarize on the postcard
        viewModel.onSelectTargetAction(LensAction.SUMMARIZE)
        val expanded = viewModel.lensState.value as LensState.PanelExpanded

        // Verify questions are oriented to postcards/messages, NOT medicine bottles
        assertTrue(expanded.aiChips.any { it.label.contains("main message", ignoreCase = true) })
        assertTrue(expanded.aiChips.any { it.label.contains("Who sent this", ignoreCase = true) })
        assertFalse(expanded.aiChips.any { it.label.contains("miss a dose", ignoreCase = true) })

        // Ask a question about who sent the postcard
        viewModel.askCustomQuestion("Who sent this and where is it from?")
        advanceUntilIdle()

        val afterAnswer = viewModel.lensState.value as LensState.PanelExpanded
        val geminiReply = afterAnswer.conversationLog.last { it.isGemini }.text
        assertTrue(geminiReply.contains("Grandma") || geminiReply.contains("Maya") || geminiReply.contains("GRAND CANYON"))
        assertFalse(geminiReply.contains("pharmacist", ignoreCase = true))
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
