﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.steadyread.xr.viewmodel.ARReadingLensViewModel

/**
 * Root Viewport hosting the AI-Glasses interface [SteadyReadGlassesApp].
  * Developed by Praneetha Kamabathula.
 */
@Composable
fun SteadyReadARSceneViewport(
    viewModel: ARReadingLensViewModel,
    modifier: Modifier = Modifier
) {
    SteadyReadGlassesApp(
        viewModel = viewModel,
        modifier = modifier
    )
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
