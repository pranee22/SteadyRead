﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VerticalAlignBottom
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.steadyread.xr.ui.theme.ssp
import androidx.xr.glimmer.Card
import androidx.xr.glimmer.Text
import com.steadyread.xr.ui.theme.OstOpticalPalette

/**
 * Glimmer UI Components for Glanceable AI Glasses HUD.
  * Developed by Praneetha Kamabathula.
 */

@Composable
fun PositioningHintUI(
    modifier: Modifier = Modifier
) {
    Card(onClick = {}, modifier = modifier) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.VerticalAlignBottom,
                contentDescription = "Place on table",
                tint = OstOpticalPalette.InteractiveGreen,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Hold steady or rest on table to scan",
                color = Color.White,
                fontSize = 15.ssp
            )
        }
    }
}

@Composable
fun MagnifiedPrimaryUI(
    title: String,
    modifier: Modifier = Modifier
) {
    Card(onClick = {}, modifier = modifier) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "KEY FIELD",
                color = OstOpticalPalette.InteractiveGreen,
                fontSize = 13.ssp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 32.ssp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ScaffoldedSummaryUI(
    title: String,
    dosage: String,
    instructions: String,
    warning: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = title,
            color = Color.White,
            fontSize = 20.ssp,
            fontWeight = FontWeight.Bold
        )
        ScaffoldRow(icon = "", label = "Dosage", value = dosage)
        ScaffoldRow(icon = "", label = "Instructions", value = instructions)
        ScaffoldRow(icon = "", label = "Warning", value = warning)
    }
}

@Composable
fun ScaffoldRow(
    icon: String,
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(onClick = {}, modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (icon.isNotBlank()) {
                Text(text = icon, fontSize = 24.ssp)
            }
            Column {
                Text(
                    text = label,
                    color = OstOpticalPalette.InteractiveGreen,
                    fontSize = 13.ssp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = value,
                    color = Color.White,
                    fontSize = 16.ssp
                )
            }
        }
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
