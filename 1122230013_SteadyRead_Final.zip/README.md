# SteadyRead XR

**Author:** Praneetha Kamabathula  
**Copyright:** © 2026 Praneetha Kamabathula. All rights reserved.  
**Platform:** Optical See-Through (OST) Smart Glasses & Android XR  

An Optical See-Through (OST) spatial AR reading assistant for smart glasses and Android XR, engineered for seniors and individuals with Essential Tremor, Parkinson's disease, and low vision.

---

## Documentation

Full architectural and design documentation is available in the [`docs/`](docs/) directory:

1. **[Philosophy, Purpose, Human Factors & Architectural Design Decisions](docs/PHILOSOPHY_AND_DESIGN_DECISIONS.md)**
   - The *Dual Impairment Crisis* and physics of the *Handheld Device Paradox*.
   - The 5 Core Axioms of SteadyRead XR.
   - Medical biomechanics: Essential Tremor (ET) vs. Parkinson's (PD) frequency damping.
   - Occupational therapy ergonomic bracing guidelines.
   - Architectural trade-offs: Optical See-Through (OST) vs. Video Pass-Through (VPT), Directional Air-Taps vs. Pinching, Retinal visual angle scaling ($\ge 0.6^\circ$).
   - Dual vision engine: Google MediaPipe 21-joint 3D hand tracking + optical motion fallback.
   - Multimodal Gemini 2.5 Flash reasoning with deterministic offline fallback.
   - 90-second personalized calibration wizard.

2. **[Current System Architecture & Project Status Report](docs/PROJECT_STATUS_REPORT.md)**
   - End-to-end system dataflow and Mermaid architecture diagrams.
   - Implementation file mapping across all subsystems.
   - HoloLens holographic joint skeleton and optical magnification zoom modes.
   - Complete verification matrix, build status, and unit test results.
   - Step-by-step instructions for running on laptop webcams, Android devices, and HoloLens hardware.

---

## Quick Start & Verification

### Build & Unit Tests
```powershell
cmd.exe /c gradlew.bat testDebugUnitTest assembleDebug
```

### Install to Connected Device / Emulator
```powershell
E:\Android\Sdk\platform-tools\adb.exe install -r E:\Antigravity\app\build\outputs\apk\debug\app-debug.apk
E:\Android\Sdk\platform-tools\adb.exe shell am start -n com.steadyread.xr/.MainActivity
```
