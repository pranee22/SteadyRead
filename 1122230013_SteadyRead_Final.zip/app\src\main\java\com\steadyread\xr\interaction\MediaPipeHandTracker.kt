﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.interaction

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import com.steadyread.xr.ui.HandJoint
import com.steadyread.xr.ui.HandTrackingTelemetry
import kotlin.math.sqrt

/**
 * Real-time 21-joint 3D hand and gesture tracker powered by Google MediaPipe.
 *
 * Runs on the camera frame to:
 * 1. Track 21 3D landmarks per hand (wrist, palm, thumb, index, middle, ring, pinky).
 * 2. Compute index fingertip velocity (m/s) and detect downward air-tap strikes.
 * 3. Calculate tremor jitter (mm) and apply low-pass HoloLens stabilization.
 * 4. Detect pinch gestures (thumb to index) and two-handed distance for text-size stretch zoom.
  * Developed by Praneetha Kamabathula.
 */
class MediaPipeHandTracker(context: Context) {

    private var handLandmarker: HandLandmarker? = null

    init {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath("hand_landmarker.task")
                .build()

            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setMinHandDetectionConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setNumHands(2)
                .setRunningMode(RunningMode.IMAGE)
                .build()

            handLandmarker = HandLandmarker.createFromOptions(context, options)
        } catch (_: Throwable) {
            handLandmarker = null
        }
    }

    val isAvailable: Boolean get() = handLandmarker != null

    private var prevFrameTimeMs: Long = 0L
    private var prevRawHandX: Float = 0.5f
    private var prevRawHandY: Float = 0.5f
    private var smoothedHandX: Float = 0.5f
    private var smoothedHandY: Float = 0.5f
    private var lastStrikeTimeMs: Long = 0L
    private val recentJitterSamplesMm = ArrayDeque<Float>()

    fun processFrame(bitmap: Bitmap): HandTrackingTelemetry? {
        val landmarker = handLandmarker ?: return null
        val nowMs = System.currentTimeMillis()
        val dtSec = if (prevFrameTimeMs > 0L) {
            ((nowMs - prevFrameTimeMs).coerceIn(16L, 500L)) / 1000f
        } else {
            0.033f
        }
        prevFrameTimeMs = nowMs

        return try {
            val mpImage = BitmapImageBuilder(bitmap).build()
            val result: HandLandmarkerResult = landmarker.detect(mpImage)

            val hands = result.landmarks()
            if (hands.isEmpty()) {
                return HandTrackingTelemetry(
                    isHandDetected = false,
                    normalizedX = smoothedHandX,
                    normalizedY = smoothedHandY,
                    smoothedX = smoothedHandX,
                    smoothedY = smoothedHandY,
                    velocityMps = 0f,
                    jitterMm = 0f,
                    isStabilized = true,
                    trackingSource = "Google MediaPipe AI Hands"
                )
            }

            // Primary hand (first hand detected)
            val primaryHand = hands[0]
            val handJoints = primaryHand.map { lm ->
                HandJoint(x = lm.x(), y = lm.y(), z = lm.z())
            }

            // Index finger tip (Landmark 8) is primary HoloLens pointer
            val indexTip = primaryHand.getOrNull(8)
            val thumbTip = primaryHand.getOrNull(4)
            val wrist = primaryHand.getOrNull(0)

            val rawX = indexTip?.x() ?: wrist?.x() ?: 0.5f
            val rawY = indexTip?.y() ?: wrist?.y() ?: 0.5f

            // Pinch detection (Index tip to Thumb tip distance)
            val isPinching = if (indexTip != null && thumbTip != null) {
                val pdx = indexTip.x() - thumbTip.x()
                val pdy = indexTip.y() - thumbTip.y()
                sqrt(pdx * pdx + pdy * pdy) < 0.065f
            } else {
                false
            }

            // Two-hand distance (for two-hand stretch zoom)
            val twoHandDist: Float? = if (hands.size >= 2) {
                val hand1Wrist = hands[1].getOrNull(0)
                if (wrist != null && hand1Wrist != null) {
                    val wdx = wrist.x() - hand1Wrist.x()
                    val wdy = wrist.y() - hand1Wrist.y()
                    sqrt(wdx * wdx + wdy * wdy)
                } else null
            } else null

            // Velocity in physical space (~0.45m depth plane)
            val dx = rawX - prevRawHandX
            val dy = rawY - prevRawHandY
            val distNorm = sqrt(dx * dx + dy * dy)
            val distMeters = distNorm * 0.45f
            val velocityMps = (distMeters / dtSec).coerceIn(0f, 3.5f)

            prevRawHandX = rawX
            prevRawHandY = rawY

            // HoloLens Tremor Low-pass Filter
            val alpha = if (velocityMps > 0.32f) 0.55f else 0.18f
            smoothedHandX += alpha * (rawX - smoothedHandX)
            smoothedHandY += alpha * (rawY - smoothedHandY)

            // Residual jitter in mm
            val residual = sqrt(
                (rawX - smoothedHandX) * (rawX - smoothedHandX) +
                    (rawY - smoothedHandY) * (rawY - smoothedHandY)
            )
            val instantJitterMm = (residual * 450f).coerceIn(0.2f, 45.0f)
            if (recentJitterSamplesMm.size >= 12) recentJitterSamplesMm.removeFirst()
            recentJitterSamplesMm.addLast(instantJitterMm)
            val avgJitterMm = recentJitterSamplesMm.average().toFloat()

            // Detect downward tap strike (> 0.30 m/s downward with 350ms refractory)
            if (dy > 0.020f && velocityMps >= 0.30f && (nowMs - lastStrikeTimeMs) > 350L) {
                lastStrikeTimeMs = nowMs
            }

            HandTrackingTelemetry(
                isHandDetected = true,
                normalizedX = rawX,
                normalizedY = rawY,
                smoothedX = smoothedHandX,
                smoothedY = smoothedHandY,
                velocityMps = velocityMps,
                jitterMm = avgJitterMm,
                isStabilized = true,
                lastStrikeTimestampMs = lastStrikeTimeMs,
                trackingSource = "Google MediaPipe AI Hands (21 Joints)",
                landmarks = handJoints,
                isPinching = isPinching,
                twoHandDistance = twoHandDist
            )
        } catch (_: Throwable) {
            null
        }
    }

    fun close() {
        try {
            handLandmarker?.close()
        } catch (_: Throwable) {}
        handLandmarker = null
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
