# SteadyRead XR — Design Document (Draft v0.2)

A spatial AR reading assistant for optical see-through (OST) smart glasses with 6DoF hand tracking. It's designed first for elderly users with hand tremors and low vision, and it also works for everyone else when tremor assistance is turned off.

> [!NOTE]
> This document describes the **target design**. The current code base does **not** implement it yet, and it has never been compiled. See [Current status & roadmap](#9-current-status--roadmap).

---

## 1. Core concept

Keep the **physical object** separate from the **digital text**. The object can shake, but the text the user reads is shown on a panel that stays fixed in their view and never moves with the hand.

---

## 2. Users & use cases

| Group | Examples |
|---|---|
| **Primary** | Elderly users with essential tremor, Parkinson's, MS, post-stroke recovery, and low vision |
| **Secondary accessibility** | Arthritis (grip guidance), temporary hand injury, medication-induced shakiness, caregivers |
| **Situational** | Moving bus or train, gloves, messy hands, one hand busy |
| **General** | Nutrition and allergen labels, expiry dates, menus in dim light, router passwords, instructions, translation |
| **Professional** | Lab reagent bottles, warehouse labels, pharmacist double-checks |

---

## 3. Interaction model

There are no pinch gestures, no precise raycasts and no dwell timers. **Every action is a tap, made more reliable by calibration.**

### 3.1 First-run setup (about 90 s, each step repeatable from Settings)

| Step | User does | System measures |
|---|---|---|
| 1. Text size | Adjusts a sample label until it feels comfortable (see §3.5) | Personal text size, stored as a visual angle |
| 2. Rest *(tremor assist only)* | Holds a hand out in front for about 5 s | Tremor amplitude and dominant frequency (palm-joint jitter) |
| 3. Tap *(tremor assist only)* | Taps the air about 5 times | Strike speed, and timing/size of secondary bounces |
| 4. Aim *(tremor assist only)* | Taps *toward* 3–4 highlighted targets at different angles | How far off-target their aim usually is |

Text size comes first, so every later step is already shown at a size the user can read.

These measurements produce a per-user **Tremor Profile**:
- `tapVelocityThreshold`: the downward speed above which a movement counts as a deliberate tap, set above the user's tremor-speed range.
- `refractoryWindowMs`: how long further strikes are ignored after an accepted tap, set from their own bounce timing.
- `zoneScale`: how much larger tap zones and buttons should be, based on tremor amplitude.
- `aimConeDegrees`: how wide the selection cone is for directional taps, set from their aiming error.

### 3.2 Selecting objects — directional tap (primary)

The user **taps in the direction of an object**. They don't have to reach or touch it, which matters for elderly users with limited arm extension or balance.

```mermaid
flowchart LR
  A["Tap detected (speed > threshold)"] --> B["Find tap direction (smoothed hand path)"]
  B --> C["Combine with head direction"]
  C --> D["Find candidate objects inside aim cone"]
  D -->|one object| E["Select and highlight in green"]
  D -->|two or more| F["Pick closest, show 'Not this?' option"]
  D -->|none| G["Assistant: 'Tap toward the item you want'"]
```

How it stays tremor-tolerant:
- **The whole tap motion is averaged.** Tremor is a fast back-and-forth wobble (roughly 4–12 Hz), so it cancels out over the course of a tap, and only the intended direction remains.
- **Head direction helps.** The glasses' head pose is much steadier than the hand. The final direction blends hand direction with where the user is looking.
- **The cone is wide and sized per user.** Tables usually hold only a few objects, so a generous cone set from calibration (around 15–25° as a starting point) works well.
- **Selection snaps to real objects.** The tap always picks the nearest detected object rather than an exact point in space.
- **Mistakes are cheap to undo.** The selected object lights up immediately. If it's wrong, the user taps *Not this* or just taps toward the right object.

### 3.3 Selecting objects — touch (secondary)

Tapping **on** the object with a fingertip or flat hand also works. The contact check is padded by the user's tremor amplitude, so a near miss still counts.

### 3.4 Action buttons

After an object is selected and scanned, large buttons appear next to it. Only buttons that apply to that object are shown.

| Button | Shown when |
|---|---|
| **Magnify** | Text detected |
| **Summarize** | Enough text to summarize (e.g. a label or letter) |
| **Translate** *(proposed)* | Text detected in a language other than the user's |
| **How to hold** | Tremor assistance is on |
| **Ask** | Always |

Each button is a tap zone scaled by `zoneScale`, with the bounce filter applied.

### 3.5 Personal text size (setup and any time)

Everyone finds a different size comfortable, so text size is **a personal scale, not a fixed set of options**.

**Two ways to adjust it, available both during setup and on any panel:**
- **Tap buttons:** large **A−** / **A+** buttons next to the sample text. Each tap moves one step.
- **Two-hand stretch:** hold both hands up with palms open, then move them apart to enlarge or together to shrink. Open palms only, so there's no fine pinch involved.

**Keeping it tremor-tolerant:**
- Hand distance is smoothed before it's used, so tremor doesn't make the text pulse.
- Size **snaps to steps** (about 10% each) instead of changing continuously, so it stays put while the hands shake.
- A stretch only starts once both hands have been held up for a moment, so it can't be triggered by accident.
- The new size is kept when the hands drop, or when the user taps **Done**.

**How the size is stored and applied:**
- The size is saved as a **visual angle** (e.g. "body text = 1.6°"), not as pixels. It therefore looks equally large whether the panel is near or far.
- The typical range is about 0.8°–4.0°, and every text style scales together from this one value.
- Panels grow, wrap or paginate to fit the text, and never clip it.

**Saved vs. temporary changes:**
- Changing size during setup or in Settings updates the **saved default**.
- Changing size on a reading panel only applies **to that object**. Afterwards the user is asked: *"Keep this size from now on?"* (Yes / No).

---

## 4. Features

### 4.1 Magnify — readable even while shaking
1. Capture frames continuously and score each one for sharpness, keeping only the sharpest.
2. Track the text region across frames.
3. Run ML Kit Text Recognition on the kept frames and combine the results, so a word only counts once several frames agree on it.
4. Show the key field on a panel **fixed in the user's view**, with text sized by visual angle.
5. **Fallback:** if a stable reading can't be reached within a few seconds, the assistant suggests resting the object on a table and tapping it again.

### 4.2 Summarize — chunks and chips
- The LLM **sorts the actual label text into categories** (Dose / When / Warnings / Expiry). It does not write new text.
- Each chip shows the **exact words from the label**, and the original text is always one tap away.
- Tapping a chip expands it into a detail view.

> [!WARNING]
> Medication safety: the LLM must never change numbers, units or drug names. Any value shown on a chip has to appear word-for-word in the OCR text. If it doesn't, the app shows the raw text instead.

### 4.3 How to hold — grip guidance
1. Identify the object type and approximate size (cloud vision, or an on-device classifier).
2. Choose a grip from a curated library based on the user's Tremor Profile. General principles: whole-hand wraps over fingertip pinches, two hands for stronger tremors, elbow braced on the table, object close to the body.
3. Show a **ghost-hand overlay** on the object.
4. Optional: measure how much the object shakes while held and suggest a different grip if needed.

> [!IMPORTANT]
> The grip library should be reviewed by an occupational therapist. Grips are presented as suggestions, not medical advice.

### 4.4 Assistant
- Available throughout: during calibration, when no object is detected, when reading fails, and through *Ask*.
- **Voice** uses Gemini Live (cloud) when allowed, and falls back to on-device speech recognition and text-to-speech otherwise.
- **Text** prompts appear on the panel.
- The mode is set by the user (see §6).

### 4.5 When things aren't clear — guided next steps

The system never just fails silently or guesses. When it can't read or identify something, it works out **why** and gives **one clear next step at a time**. Each step is spoken, written on the panel, or both, according to the assistant setting, and comes with large option buttons.

**Read problems** (object in view, but the text is unclear):

| Detected cause | How it's detected | Instruction |
|---|---|---|
| Too far / text too small | Text boxes are only a few pixels tall | "Bring it a little closer." |
| Blurry from shaking | Sharp frames are rare | "Rest your elbow on the table." → then "Set it down and tap it again." |
| Too dark | Low image brightness | "Move to a brighter spot, or turn on a light." |
| Glare | Bright, washed-out patches over the text | "Tilt it slightly away from the light." |
| Label wraps around (bottle) | Text cut off at the edges of the object | "Turn it slowly toward you." The app joins the pieces together. |
| Label facing away | Object found, but no text visible | "Turn it around so the label faces you." |
| Partial read | Some fields found, others missing | Shows what *was* read, and says which part is missing |

**Identification problems** (no match, and no previous data about this object):

1. **Explain plainly:** "I can't tell what this is yet."
2. **Offer options as buttons:**
   - **Read the text on it:** go straight to Magnify on whatever text is visible.
   - **Describe it to me:** the user says or types what it is.
   - **Ask online** *(only if cloud is allowed)*: send a photo for a closer look.
   - **Try again.**
3. If cloud is off and the on-device model can't identify it, the app explains this and offers to **allow cloud just this once**.

**Escalation:** if the same problem keeps happening, the advice moves to bigger fixes:
1. Adjust (closer, light, tilt).
2. Set the object down and tap it again.
3. *"I'm having trouble reading this. You may want to ask someone to help."* The app also shows whatever it did read.

**Never guess on medications.** Below a confidence threshold, the app shows the raw text, labelled *"Not sure: please check the label"*, instead of chips.

### 4.6 Known items (proposed)

After a successful read, the user can save the item (e.g. *"My blood pressure pills"*). It's stored **on-device only**. Next time, the item is recognized straight away, and the app can point out if the new label differs from the saved one, for example a different dose.

---

## 5. AI architecture — on-device and cloud

| Task | Default | Cloud used when |
|---|---|---|
| OCR | ML Kit (on-device) | Never |
| Sorting text into chips | Gemini Nano | Nano unavailable or text too complex, *and* the user allows cloud |
| Translation | ML Kit Translate (on-device) | Higher-quality translation, if allowed |
| Object identification (grip) | On-device classifier | Unknown objects, if allowed |
| Ask (open questions) | Gemini Nano | Usually cloud, if allowed |
| Live voice | On-device speech recognition + TTS | Gemini Live, if allowed |

Cloud access should go through **Firebase AI Logic**, so no API keys are embedded in the app.

---

## 6. Settings

| Setting | Options | Default |
|---|---|---|
| Tremor assistance | Off / On (calibrated) | On after calibration |
| Recalibrate | Action | — |
| Text size | Personal scale (A−/A+ or two-hand stretch), stored as visual angle | Chosen at setup |
| Assistant mode | Voice / Text / Both | Both |
| AI processing | On-device only / Prefer on-device / Allow cloud | Prefer on-device |

**With tremor assistance off:** no calibration, bounce filter or oversized zones; the aim cone falls back to a standard width; *How to hold* is hidden. Magnify (including reading while the object moves), Summarize, Translate and Ask all keep working.

---

## 7. Visual design rules (OST additive displays)

- Never use opaque white backgrounds or black drop shadows. Black shows up as transparent on these displays.
- Panels use a dark translucent scrim (50–60% black).
- Text is white or bright; interactive outlines and states use desaturated green `#9FD8A8`.
- Text is sized by visual angle. Default ratios are Title ≈ 1.4°, Body ≈ 1.0°, Magnified key field ≈ 2.3°, and the user's personal scale (§3.5) multiplies all of them.
- Fonts: Google Sans Flex or Atkinson Hyperlegible.
- **Text must fit the panel.** The panel grows, or the text wraps and paginates; text is never clipped.

---

## 8. State machine

```mermaid
stateDiagram-v2
  [*] --> Calibrating: first run (tremor assist on)
  [*] --> Browsing: tremor assist off
  Calibrating --> Browsing
  Browsing --> ObjectSelected: directional or touch tap
  ObjectSelected --> Browsing: Not this
  ObjectSelected --> ActionMenu: scan complete
  ActionMenu --> Magnified: Magnify
  ActionMenu --> SummaryChips: Summarize
  ActionMenu --> GripGuidance: How to hold
  ActionMenu --> Assistant: Ask
  ObjectSelected --> Guidance: unclear or unknown
  Magnified --> Guidance: read problem
  Guidance --> ObjectSelected: retry after fix
  Guidance --> Magnified: read visible text
  Guidance --> Assistant: describe or ask online
  Guidance --> Browsing: give up
  SummaryChips --> ChipDetail: tap chip
  ChipDetail --> SummaryChips
  Magnified --> ActionMenu: back
  SummaryChips --> ActionMenu: back
  GripGuidance --> ActionMenu: back
```

```kotlin
sealed interface LensState {
    data class Calibrating(val step: CalibrationStep) : LensState
    data object Browsing : LensState
    data class ObjectSelected(val objectId: String, val label: String) : LensState
    data class ActionMenu(val objectId: String, val actions: List<LensAction>) : LensState
    data class Magnified(val keyText: String, val confidence: Float) : LensState
    data class SummaryChips(val chips: List<SummaryChip>, val rawText: String) : LensState
    data class ChipDetail(val chip: SummaryChip) : LensState
    data class GripGuidance(val objectType: String, val grip: GripRecommendation) : LensState
    data class Guidance(
        val problem: ReadProblem,          // TooFar, Blurry, TooDark, Glare, Wrapped, FacingAway, Partial, Unknown
        val instruction: String,
        val options: List<GuidanceOption>,
        val attempt: Int                   // drives escalation
    ) : LensState
}

// Personal text size, saved at setup
data class TextSizePreference(val bodyAngleDegrees: Float)   // titles and key fields scale from this
```

---

## 9. Current status & roadmap

**Current status:** source and Gradle config exist but have **never been compiled**. There's no Android SDK and no Gradle wrapper on this machine. XR API names are unverified. `SpatialPanel` and `Orbiter` are placeholder stand-ins. Hand tracking, the AR session and the camera are not connected. The current dwell-based interaction is **replaced** by this design.

| Phase | Work |
|---|---|
| 0. Build foundation | Install SDK and Gradle wrapper, pin real XR library versions, get a compiling app running on the Android XR emulator |
| 1. Core interaction | Setup flow (text size + tremor calibration), tap detection and bounce filter, directional tap selection, action buttons, settings |
| 2. Magnify | Multi-frame OCR with sharpness filtering, fixed panel, personal text sizing (A−/A+, two-hand stretch), guided next steps for read problems |
| 3. Summarize | Nano text sorting, word-for-word value check, chips UI, cloud fallback |
| 4. Assistant | Text mode, voice mode, Gemini Live integration |
| 5. Grip guidance | Object classification, grip library, ghost-hand overlay |
| 6. Extras | Translate, held-grip stability check |

---

## 10. Open questions

1. Target hardware: standalone glasses, or glasses paired with a phone? This decides whether Nano runs on the glasses or on the phone.
2. Should a **directional tap** select immediately, or show a quick highlight and wait for a second confirming tap? The draft selects immediately and relies on cheap undo.
3. Is Translate in scope for v1?
4. Is an occupational therapist available to review the grip library?
5. Are **Known items** (§4.6) in scope? They involve storing personal medication info on the device.
