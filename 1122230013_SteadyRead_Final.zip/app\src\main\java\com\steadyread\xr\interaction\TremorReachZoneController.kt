﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.interaction

import androidx.xr.arcore.Hand
import androidx.xr.arcore.HandJointType
import androidx.xr.runtime.Session
import androidx.xr.arcore.TrackingState
import com.steadyread.xr.spatial.Vec3Meters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Identifies the two large fixed 3D spatial reach zones anchored to the left and right
 * of the UI panel (`SpatialARNode`).
 */
enum class ReachZoneSide {
    LEFT,
    RIGHT
}

/**
 * Large, invisible 3D Axis-Aligned Bounding Box (AABB) collision volume anchored relative
 * to the dropped `SpatialARNode` UI panel.
 *
 * Replaces ray cast pointing and pinch-to-select with gross-motor reach entry.
  * Developed by Praneetha Kamabathula.
 */
data class SpatialCollisionVolume3D(
    val side: ReachZoneSide,
    val centerWorldMeters: Vec3Meters,
    val halfExtentsMeters: Vec3Meters = Vec3Meters(0.095f, 0.095f, 0.095f) // 19cm x 19cm x 19cm volume
) {
    /**
     * Evaluates whether a 6DoF tracked hand joint ([handPointMeters]) lies inside this
     * 3D collision volume.
     */
    fun contains(handPointMeters: Vec3Meters): Boolean {
        return abs(handPointMeters.x - centerWorldMeters.x) <= halfExtentsMeters.x &&
            abs(handPointMeters.y - centerWorldMeters.y) <= halfExtentsMeters.y &&
            abs(handPointMeters.z - centerWorldMeters.z) <= halfExtentsMeters.z
    }
}

/**
 * Immutable UI state for a single 3D Reach Zone's Hold-to-Confirm Hysteresis Timer.
 */
data class ReachZoneHysteresisState(
    val side: ReachZoneSide,
    val isHandInsideVolume: Boolean = false,
    val isInDebounceGracePeriod: Boolean = false,
    val holdElapsedMs: Long = 0L,
    val debounceElapsedMs: Long = 0L,
    val progressFraction: Float = 0f,
    val confirmationCount: Int = 0
)

/**
 * Module 4: Tremor-Tolerant Hand Interaction Controller
 *
 * Interaction Rules:
 * 1. NO raycast/pointing and NO pinch-to-select.
 * 2. Two large fixed 3D collision volumes anchored to the left (-0.24m X) and right (+0.24m X)
 *    of the UI panel's `SpatialARNode`.
 * 3. Hold-to-Confirm Hysteresis Timer: Entering a zone advances a 1.2-second (1200ms) timer
 *    rendered as a Compose loading ring.
 * 4. The Debounce Rule: Exiting the volume does NOT immediately reset the timer. A 0.4-second
 *    (400ms) grace period holds the current progress; re-entering within 400ms seamlessly
 *    resumes the 1.2s timer. Exiting for > 400ms resets the timer to 0.
 */
@Suppress("unused")
    class TremorReachZoneController(
    private val onZoneConfirmed: (ReachZoneSide) -> Unit
) {
    companion object {
        /** Required dwell duration inside the 3D collision volume to trigger confirmation (1.2 seconds). */
        const val HOLD_DURATION_MS = 1200L

        /** Grace period (debounce) allowed when tremor micro-bounces move the hand outside the zone (0.4 seconds). */
        const val DEBOUNCE_GRACE_MS = 400L

        /** Horizontal offset (+/- X in meters) from the UI panel's spatial ARNode center. */
        const val ZONE_HORIZONTAL_OFFSET_METERS = 0.24f
    }

    private val _leftZoneState = MutableStateFlow(ReachZoneHysteresisState(side = ReachZoneSide.LEFT))
    val leftZoneState: StateFlow<ReachZoneHysteresisState> = _leftZoneState.asStateFlow()

    private val _rightZoneState = MutableStateFlow(ReachZoneHysteresisState(side = ReachZoneSide.RIGHT))
    val rightZoneState: StateFlow<ReachZoneHysteresisState> = _rightZoneState.asStateFlow()

    // Rearm flags so a confirmed hold requires a clean release before re-triggering
    private var leftRearmRequired = false
    private var rightRearmRequired = false

    private var handTrackingJob: Job? = null
    private var tickLoopJob: Job? = null

    /**
     * Computes the left and right 3D collision volumes anchored relative to [arNodeWorldPose].
     */
    fun getAnchoredVolumes(arNodeWorldPose: Vec3Meters): Pair<SpatialCollisionVolume3D, SpatialCollisionVolume3D> {
        val leftVolume = SpatialCollisionVolume3D(
            side = ReachZoneSide.LEFT,
            centerWorldMeters = Vec3Meters(
                x = arNodeWorldPose.x - ZONE_HORIZONTAL_OFFSET_METERS,
                y = arNodeWorldPose.y,
                z = arNodeWorldPose.z
            )
        )
        val rightVolume = SpatialCollisionVolume3D(
            side = ReachZoneSide.RIGHT,
            centerWorldMeters = Vec3Meters(
                x = arNodeWorldPose.x + ZONE_HORIZONTAL_OFFSET_METERS,
                y = arNodeWorldPose.y,
                z = arNodeWorldPose.z
            )
        )
        return leftVolume to rightVolume
    }

    /**
     * Subscribes to 6DoF hand tracking (`Hand.left(session)` and `Hand.right(session)`)
     * from `androidx.xr.arcore` and evaluates palm collision against the anchored 3D volumes.
     */
    fun bindHandTracking(
        scope: CoroutineScope,
        session: Session,
        arNodePoseProvider: () -> Vec3Meters?
    ) {
        handTrackingJob?.cancel()
        handTrackingJob = scope.launch {
            launch {
                Hand.left(session).state.collect { handState ->
                    val arNodePose = arNodePoseProvider() ?: return@collect
                    val (leftVolume, rightVolume) = getAnchoredVolumes(arNodePose)
                    val palmPose = extractPalmWorldPosition(handState)
                    if (palmPose != null) {
                        onHandCollisionSample(
                            side = ReachZoneSide.LEFT,
                            isHandInside = leftVolume.contains(palmPose)
                        )
                        if (rightVolume.contains(palmPose)) {
                            onHandCollisionSample(side = ReachZoneSide.RIGHT, isHandInside = true)
                        }
                    }
                }
            }
            launch {
                Hand.right(session).state.collect { handState ->
                    val arNodePose = arNodePoseProvider() ?: return@collect
                    val (leftVolume, rightVolume) = getAnchoredVolumes(arNodePose)
                    val palmPose = extractPalmWorldPosition(handState)
                    if (palmPose != null) {
                        onHandCollisionSample(
                            side = ReachZoneSide.RIGHT,
                            isHandInside = rightVolume.contains(palmPose)
                        )
                        if (leftVolume.contains(palmPose)) {
                            onHandCollisionSample(side = ReachZoneSide.LEFT, isHandInside = true)
                        }
                    }
                }
            }
        }
    }

    private fun extractPalmWorldPosition(handState: Hand.State): Vec3Meters? {
        if (handState.trackingState != TrackingState.TRACKING) return null
        val palmPose = handState.handJoints[HandJointType.PALM]
            ?: handState.handJoints[HandJointType.WRIST]
            ?: return null
        val t = palmPose.translation
        return Vec3Meters(t.x, t.y, t.z)
    }

    /**
     * Starts a 60Hz (16ms) hysteresis & debounce ticker coroutine.
     */
    fun startHysteresisTicker(scope: CoroutineScope, tickIntervalMs: Long = 16L) {
        tickLoopJob?.cancel()
        tickLoopJob = scope.launch {
            while (isActive) {
                delay(tickIntervalMs)
                advanceTimeStep(deltaMs = tickIntervalMs)
            }
        }
    }

    /**
     * Updates whether a user's tracked hand is currently inside the specified 3D reach volume.
     */
    fun onHandCollisionSample(side: ReachZoneSide, isHandInside: Boolean) {
        val flow = if (side == ReachZoneSide.LEFT) _leftZoneState else _rightZoneState
        val current = flow.value

        if (isHandInside) {
            // Hand entered or re-entered within the 0.4s debounce window: cancel debounce and resume hold
            flow.value = current.copy(
                isHandInsideVolume = true,
                isInDebounceGracePeriod = false,
                debounceElapsedMs = 0L
            )
        } else if (current.isHandInsideVolume) {
            // Hand just exited the 3D collision volume: enter 0.4s grace period if progress > 0
            val shouldEnterGrace = current.holdElapsedMs > 0L
            flow.value = current.copy(
                isHandInsideVolume = false,
                isInDebounceGracePeriod = shouldEnterGrace,
                debounceElapsedMs = 0L
            )
        }
    }

    /**
     * Deterministic time-step evaluation of the 1.2s Hold-to-Confirm timer and 0.4s Debounce rule.
     */
    fun advanceTimeStep(deltaMs: Long) {
        if (deltaMs <= 0L) return
        _leftZoneState.value = stepSingleZone(
            current = _leftZoneState.value,
            deltaMs = deltaMs,
            rearmRequired = leftRearmRequired,
            setRearmRequired = { leftRearmRequired = it }
        )
        _rightZoneState.value = stepSingleZone(
            current = _rightZoneState.value,
            deltaMs = deltaMs,
            rearmRequired = rightRearmRequired,
            setRearmRequired = { rightRearmRequired = it }
        )
    }

    private fun stepSingleZone(
        current: ReachZoneHysteresisState,
        deltaMs: Long,
        rearmRequired: Boolean,
        setRearmRequired: (Boolean) -> Unit
    ): ReachZoneHysteresisState {
        if (current.isHandInsideVolume) {
            if (rearmRequired) {
                return current
            }
            val updatedHoldMs = (current.holdElapsedMs + deltaMs).coerceAtMost(HOLD_DURATION_MS)
            val fraction = (updatedHoldMs.toFloat() / HOLD_DURATION_MS.toFloat()).coerceIn(0f, 1f)

            if (updatedHoldMs >= HOLD_DURATION_MS) {
                // 1.2-second Hold-to-Confirm reached! Fire callback and reset progress until hand exits.
                setRearmRequired(true)
                onZoneConfirmed(current.side)
                return current.copy(
                    isInDebounceGracePeriod = false,
                    holdElapsedMs = 0L,
                    debounceElapsedMs = 0L,
                    progressFraction = 0f,
                    confirmationCount = current.confirmationCount + 1
                )
            }

            return current.copy(
                isInDebounceGracePeriod = false,
                holdElapsedMs = updatedHoldMs,
                debounceElapsedMs = 0L,
                progressFraction = fraction
            )
        } else {
            // Hand is outside the 3D volume
            if (current.isInDebounceGracePeriod && current.holdElapsedMs > 0L) {
                val updatedDebounceMs = current.debounceElapsedMs + deltaMs
                return if (updatedDebounceMs <= DEBOUNCE_GRACE_MS) {
                    // Within 0.4s (400ms) grace period: preserve holdElapsedMs and progressFraction!
                    current.copy(
                        isInDebounceGracePeriod = true,
                        debounceElapsedMs = updatedDebounceMs
                    )
                } else {
                    // Grace period (0.4s) expired: reset timer completely
                    setRearmRequired(false)
                    current.copy(
                        isInDebounceGracePeriod = false,
                        holdElapsedMs = 0L,
                        debounceElapsedMs = 0L,
                        progressFraction = 0f
                    )
                }
            } else {
                // Idle outside volume
                setRearmRequired(false)
                return current.copy(
                    isInDebounceGracePeriod = false,
                    holdElapsedMs = 0L,
                    debounceElapsedMs = 0L,
                    progressFraction = 0f
                )
            }
        }
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
