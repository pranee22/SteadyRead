﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.interaction

import com.steadyread.xr.spatial.Vec3Meters
import com.steadyread.xr.ui.TextSizePreference
import com.steadyread.xr.ui.TremorProfile
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sqrt

/**
 * Directional Tap Result from 6DoF hand tracking + head pose.
  * Developed by Praneetha Kamabathula.
 */
data class DirectionalTapEvent(
    val origin: Vec3Meters,
    val directionVector: Vec3Meters,
    val timestampMs: Long
)

/**
 * Mathematical filter for gross-motor reach zones and directional tapping (§3.1, §3.2).
 *
 * Enforces:
 * 1. Strike velocity gating: downward velocity must exceed [TremorProfile.tapVelocityThresholdMps].
 * 2. Tremor bounce suppression: ignores all secondary strikes during [TremorProfile.refractoryWindowMs].
 * 3. Directional tap selection: projects hand tap trajectory + head gaze, matching against candidate objects.
 * 4. Two-hand open-palm stretch detection for personal text size zooming (§3.5).
 */
class CalibratedTapFilter(
    var profile: TremorProfile = TremorProfile()
) {
    private var lastAcceptedTapTimestampMs: Long = 0L

    // History for smoothing two-hand distance
    private var previousHandDistanceMeters: Float? = null
    private var accumulatedZoomSteps: Int = 0

    /**
     * Evaluates a potential tap strike.
     * Returns true ONLY if the downward velocity exceeds the tremor-calibrated threshold
     * AND the refractory window has elapsed since the last accepted tap.
     */
    fun evaluateTapStrike(
        currentVelocityMps: Float,
        timestampMs: Long
    ): Boolean {
        if (!profile.isTremorAssistanceEnabled) {
            // Standard tap mode without tremor filter
            return currentVelocityMps >= 0.15f && (timestampMs - lastAcceptedTapTimestampMs >= 150L)
        }

        val elapsedSinceLastTap = timestampMs - lastAcceptedTapTimestampMs
        if (elapsedSinceLastTap < profile.refractoryWindowMs) {
            // Secondary bounce / tremor vibration suppressed!
            return false
        }

        if (currentVelocityMps >= profile.tapVelocityThresholdMps) {
            lastAcceptedTapTimestampMs = timestampMs
            return true
        }

        return false
    }

    /**
     * Resolves which candidate object is targeted by a directional tap (§3.2).
     *
     * Combines the smoothed hand strike direction with the head gaze direction
     * and evaluates candidate object angles against [TremorProfile.aimConeDegrees].
     */
    fun resolveDirectionalTarget(
        handStrikeOrigin: Vec3Meters,
        handStrikeDirection: Vec3Meters,
        headGazeDirection: Vec3Meters,
        candidateObjects: List<Pair<String, Vec3Meters>> // objectId to world position
    ): String? {
        if (candidateObjects.isEmpty()) return null

        // Blend hand strike direction (70%) with steady head gaze (30%)
        val combinedDirection = normalize(
            Vec3Meters(
                x = handStrikeDirection.x * 0.70f + headGazeDirection.x * 0.30f,
                y = handStrikeDirection.y * 0.70f + headGazeDirection.y * 0.30f,
                z = handStrikeDirection.z * 0.70f + headGazeDirection.z * 0.30f
            )
        )

        val coneAngleRad = Math.toRadians((profile.aimConeDegrees / 2.0)).toFloat()
        var bestMatchId: String? = null
        var minAngleRad = Float.MAX_VALUE

        for ((id, position) in candidateObjects) {
            val toObject = normalize(
                Vec3Meters(
                    x = position.x - handStrikeOrigin.x,
                    y = position.y - handStrikeOrigin.y,
                    z = position.z - handStrikeOrigin.z
                )
            )

            val dot = dotProduct(combinedDirection, toObject).coerceIn(-1.0f, 1.0f)
            val angleRad = acos(dot)

            if (angleRad <= coneAngleRad && angleRad < minAngleRad) {
                minAngleRad = angleRad
                bestMatchId = id
            }
        }

        return bestMatchId
    }

    /**
     * Two-hand open-palm stretch zoom (§3.5).
     *
     * Evaluates distance between left and right open palms.
     * Snaps to discrete 10% steps and smoothes out tremor fluctuations.
     */
    fun evaluateTwoHandStretch(
        leftPalmPose: Vec3Meters,
        rightPalmPose: Vec3Meters,
        currentPreference: TextSizePreference
    ): TextSizePreference {
        val currentDistance = leftPalmPose.distanceTo(rightPalmPose)
        val prevDistance = previousHandDistanceMeters

        if (prevDistance == null) {
            previousHandDistanceMeters = currentDistance
            return currentPreference
        }

        val deltaMeters = currentDistance - prevDistance

        // Require intentional hand movement > 3.5cm to trigger a step (tremor dead-zone)
        val stepThresholdMeters = 0.035f

        var updated = currentPreference
        if (deltaMeters >= stepThresholdMeters) {
            updated = currentPreference.stepUp()
            previousHandDistanceMeters = currentDistance
        } else if (deltaMeters <= -stepThresholdMeters) {
            updated = currentPreference.stepDown()
            previousHandDistanceMeters = currentDistance
        }

        return updated
    }

    fun resetTwoHandTracking() {
        previousHandDistanceMeters = null
        accumulatedZoomSteps = 0
    }

    private fun normalize(v: Vec3Meters): Vec3Meters {
        val len = sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
        if (len < 0.0001f) return Vec3Meters(0f, 0f, 1f)
        return Vec3Meters(v.x / len, v.y / len, v.z / len)
    }

    private fun dotProduct(a: Vec3Meters, b: Vec3Meters): Float {
        return a.x * b.x + a.y * b.y + a.z * b.z
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
