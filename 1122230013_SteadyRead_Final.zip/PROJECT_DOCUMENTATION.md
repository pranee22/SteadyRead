# SteadyRead XR — Final UX Project Documentation

**Student Name:** Praneetha Kamabathula  
**Student ID:** 1122230013  
**Course / Assignment:** Final UX Assignment  
**Project Repository:** `SteadyRead XR` (`E:\Antigravity`)  
**Package:** `com.steadyread.xr`  
**Date:** October 30, 2026  

---

## 1. Project Overview

### 1.1 Project Title
**SteadyRead XR: A Spatial Augmented Reality Reading Assistant for Optical See-Through (OST) Smart Glasses & Android XR**

### 1.2 The Problem
In aging populations, visual decline (presbyopia, macular degeneration, cataracts) and motor tremors (Essential Tremor, Parkinson's disease) frequently co-occur. 

**Epidemiological Scale of the Problem:**
According to a meta-analysis of 42 population-based studies across 23 countries (*Tremor and Other Hyperkinetic Movements*, DOI: 10.5334/tohm.632), Essential Tremor (ET) affects 1.33% of the global population across all age groups, surging to 5.79% in adults aged 65 and older, and reaching a median of 9.3% in the oldest cohorts. Prevalence compounds dramatically, rising by 74% per decade of life.

When elderly individuals attempt to read small print on medicine bottles, utility bills, receipts, or letters:
- Holding the object at arm's length turns the arm into a mechanical lever, magnifying natural 4–12 Hz hand tremors.
- Existing smartphone magnifiers and digital loupes exacerbate the problem: the handheld camera shakes violently with the user's hand, causing optical character recognition (OCR) failure, severe motion blur, and visual vertigo/nausea for the user.
- Fine-motor user interfaces that rely on pinch-to-zoom, precise laser pointer raycasting, or hover/dwell timers are frustrating and unusable for shaky hands.

### 1.3 Intended Users
- **Primary Users:** Elderly individuals (aged 60+) and adults diagnosed with Essential Tremor (ET), Parkinson's Disease (PD), post-stroke motor impairment, arthritis, or age-related low vision.
- **Secondary Users:** Caregivers assisting elderly family members; individuals in situational impairment (reading on a moving train/bus, wearing gloves, or with messy/busy hands).
- **Professional Users (Future Scope):** Pharmacists double-checking cylindrical drug bottles, warehouse staff, and lab technicians handling hazardous reagent labels.

### 1.4 Goals
1. **Decouple Physical Instability from Digital Reading:** Keep the real-world shaking object completely separate from the digital reading interface. The object may shake in the user's hand, but the reading text panel remains anchored and still in the glasses' field of view.
2. **True Optical Verification:** Ensure users can inspect a high-contrast, magnified crop of the actual physical camera image (1.5x–6.0x) so they can verify life-critical details (e.g., dosage numbers, dates) rather than blindly trusting an AI summary.
3. **Tremor-Calibrated Interaction:** Replace micro-pinches and dwell timers with gross-motor directional air-taps, velocity gating, and bounce debounce filters calibrated to each user's unique tremor profile.
4. **Context-Aware Multimodal Assistance:** Use Gemini 1.5 Flash to automatically detect what type of item is being held (postcard, medicine bottle, receipt, document) and generate tailored, readable action chips and spoken answers.

### 1.5 Scope & Implementation Boundary
- **Implemented in Native App:** Jetpack Compose Glimmer UI, CameraX live stream analysis, Google ML Kit Text Recognition v2, Google MediaPipe 21-joint 3D hand tracking, HoloLens holographic joint skeleton overlay, live optical image magnification (zoom, pan, freeze, contrast filters), multimodal Gemini 1.5 Flash API with on-device fallback, and a 5-step interactive Calibration Wizard.
- **Simulated / Emulated for Testing:** Laptop webcam / USB phone camera integration used in place of custom optical waveguide hardware; on-screen mouse pointer movement serving as simulated 6DoF hand ray during emulator runs.
- **Planned / Future Scope:** Direct OpenXR runtime deployment to physical HoloLens 2 / Magic Leap 2 waveguide hardware via Android XR SceneCore bindings; multi-language translation; cloud sync of user tremor profiles.

---

## 2. UX Process

### 2.1 Documented Research & Clinical Foundations
*Source Evidence: [`docs/PHILOSOPHY_AND_DESIGN_DECISIONS.md`](docs/PHILOSOPHY_AND_DESIGN_DECISIONS.md), [`docs/DESIGN_DOC_v0.2.md`](docs/DESIGN_DOC_v0.2.md)*
- **Epidemiological Scope (Essential Tremor):** 1.33% across all ages, 5.79% at age 65+, median 9.3% in oldest cohorts; increases 74% per decade (*Tremor and Other Hyperkinetic Movements*, DOI: 10.5334/tohm.632; 42 population studies across 23 countries).
- **Tremor Frequency Profiles:** Clinical neurology literature distinguishes Action/Postural Tremor (Essential Tremor: 4–12 Hz, worst when holding or reaching) from Resting Tremor (Parkinson's: 4–6 Hz, often accompanied by muscular rigidity). Both exhibit elastic tissue rebound "bounces" within 100–250 ms of a purposeful tap strike.
- **Dwell Timing Empirical Research & Midas Touch Problem:** In gaze-based input, empirical evaluations establish that a 600 ms dwell window is the most efficient threshold, whereas 1000 ms is more accurate but causes severe ocular and cognitive fatigue ($n=38$, *ISPRS Int. J. Geo-Information* 2022, 11(2), 127). Crucially, gaze dwell triggers the classic "Midas Touch" dilemma (Jacob 1991), where involuntary fixations while simply reading text unintentionally activate digital controls.
- **Occupational Therapy Distal Kinetic Grounding:** Stabilizing proximal joints (elbows and forearms against a table or armrest) shortens the mechanical lever arm from 70 cm to 15 cm, mechanically attenuating physical vibration amplitude by up to 80% before any software processing occurs.
- **Visual Ergonomics & Visual Angle:** Legibility in optical see-through AR is governed by the visual angle subtended on the retina ($\theta = 2 \arctan(h / 2d)$). Google Android XR guidelines specify an absolute minimum legibility floor of $0.6^\circ$ visual angle (18sp at 1 m). SteadyRead XR defaults body text to $0.95^\circ$–$1.35^\circ$ and strictly forbids thin/hairline font weights that shimmer on diffractive waveguides.

### 2.2 User Insights
1. **Dignity Matters:** Senior users reject playful emojis, gamification badges, or cartoonish assistants that feel patronizing. The interface must feel like an authoritative, calm clinical assistant.
2. **Fear of Misreading:** Low-vision seniors are deeply anxious about taking the wrong medication dose. Providing only an AI summary is insufficient; they demand to see the real label magnified.
3. **Fatigue from Holding Hands Up:** Sustained mid-air gestures cause rapid shoulder fatigue ("gorilla arm"). Interactions must be brief, and magnification must feature a "Freeze Snapshot" toggle so users can drop their hands and rest while reading.

### 2.3 User Journey (Primary Task: Reading a Prescription Vial)

```mermaid
journey
    title Primary User Journey: Reading a Shaking Medicine Bottle
    section Setup & Calibration
      Adjust comfortable text size: 5: User
      Calibrate resting tremor (5s): 4: User
      Perform 5 air-taps: 4: User
    section Detection & Targeting
      Hold bottle in front of glasses: 3: User
      SteadyRead reticle locks onto bottle: 5: System
      Perform directional air-tap toward bottle: 4: User
    section Reading & Verification
      Tap 'Magnify' to verify dosage in high contrast: 5: User
      Tap 'Freeze' and rest hands on table: 5: User
      Tap 'Summarize' for plain-language overview: 5: User
    section Assistant Q&A
      Tap 'What is the dosage?' chip: 5: User
      Listen to clear spoken response: 5: User
```

### 2.4 Information Architecture

```mermaid
graph TD
    ROOT["SteadyRead XR HUD (OST Canvas)"]
    
    ROOT --> RETICLE["Spatial Reticle<br/>(Bounding Box, L-Brackets, Text Blocks)"]
    ROOT --> HAND["HoloLens Hand Skeleton<br/>(21 Joints, Cyan Bones, Green Reticle)"]
    ROOT --> TOPBAR["Top Bar<br/>(Settings Trigger, Status Badges)"]
    
    ROOT --> ONBOARD["Onboarding Flow<br/>(Name, Age, Tremor Assist Toggle)"]
    ROOT --> INSTRUCT["Setup Instructions<br/>(Start Calibration Option)"]
    ROOT --> CALIB["5-Step Calibration Wizard<br/>(Text Size, Rest, Tap, Aim, Summary)"]
    
    ROOT --> TARGETED["Targeted Actions Hub<br/>(Magnify, Summarize, Grip Guide, Ask)"]
    TARGETED --> MAG["Magnify Panel<br/>(1.5x-6.0x Zoom, Pan, Freeze, Contrast Modes)"]
    TARGETED --> SUM["Summary Panel<br/>(Structured Key Fields, Voice Readout)"]
    TARGETED --> GRIP["Grip Guidance<br/>(OT Bracing Recommendations)"]
    TARGETED --> CHIPS["Dynamic Gemini Q&A Chips<br/>(Contextual Questions + Voice Input)"]
    
    ROOT --> SETTINGS["Settings Modal Sheet<br/>(Text Slider, Voice Toggle, Camera/Hand Toggles)"]
```

### 2.5 Key Design Decisions
1. **Optical See-Through (OST) over Video Pass-Through (VPT):** Avoids camera pass-through latency (15–35 ms) that causes vestibular disorientation and fall hazards in elderly users.
2. **Directional Air-Tap over Pinch Gestures & Gaze Dwell:**
   - *Rejection of Pinch:* Delicate index-thumb pinches fail completely under action tremors.
   - *Rejection of Gaze Dwell:* The initial speculative design brief suggested a 1.2 s dwell timer, which sat far above the published ergonomic range (600–1000 ms; *ISPRS Int. J. Geo-Information* 2022) with zero empirical basis, while inducing severe visual fatigue and Midas Touch errors (Jacob 1991). Gaze dwell was therefore decisively removed.
   - *Chosen Approach:* Tapping *toward* an item within an angular cone ($15^\circ$–$25^\circ$) translates gross-motor intent into stable selection without requiring micro-dexterity.
3. **Dual Vision Pipeline:** Real-time Google MediaPipe AI Hand Tracking (21 joints) running on RGB webcam feeds, with fallback to optical luminance motion tracking and mouse simulation.
4. **Additive Waveguide Rendering:** Background is pure black (`#000000`), emitting zero light on optical see-through glasses to preserve real-world sight.

### 2.6 Unvalidated Assumptions
- *Assumption 1:* Laboratory performance of MediaPipe 21-joint tracking on a 2D webcam translates directly to senior hands with severe contractures, rheumatoid arthritis deformities, or tremors exceeding 8 Hz in clinical field conditions. *(Status: Needs clinical testing).*
- *Assumption 2:* A 90-second first-run calibration wizard is brief enough that elderly users with cognitive decline or short attention spans will complete it without abandonment. *(Status: Needs usability trial).*
- *Assumption 3:* External user testing data with real patient populations is *[Not documented — see Section 9]*.

---

## 3. Features and Flows

### 3.1 Main Functional Flows

| Flow | Primary User Action | System Response | States Handled |
|---|---|---|---|
| **First-Run Onboarding** | Enter name/age; choose Tremor Assistance (Yes/No). | Initializes personalized profile; transitions to Setup Instructions. | Empty (defaults), Success, Recovery. |
| **Calibration Wizard** | 5-step guided calibration (Text Size, Rest Jitter, Tap Velocity, Aim Cone). | Measures hand jitter (mm) and tap speed (m/s); sets `zoneScale` and debounce timing. | Active measurement, Countdown, Success summary. |
| **Object Spatial Reticle** | Point glasses/webcam toward object (card, bottle, paper). | Draws corner L-brackets around text bounds; displays category and confidence badge. | Scanning (empty), Target Acquired (locked). |
| **Directional Air-Tap** | Make downward tap motion toward candidate object in air. | Evaluates downward velocity (> threshold); checks refractory debounce; selects target. | Strike detected, Strike rejected (bounce), Target locked. |
| **Optical Image Magnification** | Tap **Magnify** button on targeted item. | Displays stabilized cropped optical bitmap with 1.5x–6.0x zoom, pan, freeze, and contrast filters. | Loading crop, Live stream, Frozen snapshot, Natural / High-Contrast / Inverted B&W. |
| **Plain-Language Summary** | Tap **Summarize** button. | Displays high-contrast key fields (Dosage, Medication, Warnings, Sender, Due Date). | Parsing OCR, Structured fields, TTS readout. |
| **Contextual Gemini Assistant** | Tap any dynamic chip (e.g., "What is the dosage?", "Who is this from?"). | Sends cropped image + OCR prompt to Gemini 1.5 Flash; renders plain text answer and speaks via TTS. | Processing query, Success response, Offline on-device fallback. |
| **OT Grip Guidance** | Tap **How to hold** button. | Displays ergonomic bracing illustration and instructions tailored to the object type. | Card grip, Bottle clamp, Document palm anchor. |

### 3.2 State Handling & Edge Case Recovery

```mermaid
stateDiagram-v2
    [*] --> Idle_Scanning: Camera Open
    Idle_Scanning --> Target_Locked: Text detected (confidence > 0.6)
    Idle_Scanning --> Empty_Scanning: No text in view
    
    Target_Locked --> Panel_Expanded: Air-Tap or Screen Tap
    
    state Panel_Expanded {
        [*] --> Loading_Gemini: Chip Tapped
        Loading_Gemini --> Success_Response: API 200 OK
        Loading_Gemini --> Fallback_Offline: Network Timeout / Error
        Fallback_Offline --> Success_Response: On-Device Engine Fulfills
    }
    
    Panel_Expanded --> Idle_Scanning: Tap Close / Aim Away
```

- **Empty States:** When no object is in view, the reticle gently pulses in amber (`#FFB74D`) displaying *"Aim at item..."* without jarring error sounds.
- **Error & Recovery (Offline / Network Drop):** If `GeminiClient.generate()` throws a network exception or timeout, the app automatically falls through to `LabelSummarizerService.kt` to extract structured key fields on-device. The user is never presented with a raw HTTP error code.
- **Tremor Bounce Rejection:** Secondary strikes occurring within the 350–500 ms `refractoryWindowMs` are silently absorbed and discarded, preventing unintended menu loops.

---

## 4. How to Use the App

### 4.1 Numbered Instructions for a First-Time Visitor

1. **Launch the Application:** Open SteadyRead XR on your Android device, Android XR emulator, or smart glasses.
2. **Complete First-Time Setup:**
   - Enter your name (or tap **Continue as Guest**).
   - Tap **Yes, Enable Tremor Help** to activate tremor damping, bounce suppression, and ergonomic grip advice.
3. **(Optional) Run the 90-Second Calibration Wizard:**
   - On the instructions card, tap **Start 5-Step Setup**.
   - Adjust the text slider until comfortable.
   - Hold your hand steady in front of the camera for 5 seconds to calibrate baseline resting jitter.
   - Tap the air 5 times to calibrate your downward tap strike velocity.
   - Tap toward the highlighted targets to calibrate your directional aim cone.
4. **Target an Everyday Object:**
   - Place a postcard, letter, utility bill, food package, or medicine vial in front of the camera.
   - Watch the green reticle and corner L-brackets lock onto the printed text.
5. **Select Your Desired Tool:**
   - **Magnify:** Inspect a high-resolution, stabilized image of the text. Tap **+** / **−** to zoom (1.5x–6.0x), drag to pan, and tap **Freeze** to drop your hand and read comfortably. Tap **Contrast** to switch between Natural, High Contrast, and Inverted White-on-Black modes.
   - **Summarize:** Read key fields extracted into large, high-contrast cards.
   - **How to Hold:** Read occupational-therapy ergonomic advice on how to brace your forearms on the table to stop hand shake.
   - **Question Chips:** Tap any suggested question (e.g., *"What is the dosage?"*, *"Who sent this?"*) or type/speak your own question to hear Gemini answer in plain language.
6. **Access Settings:** Tap the **Settings** button in the top-right corner at any time to adjust text scale, switch voice cadences, or toggle tracking HUD overlays.

### 4.2 Device, Hardware & Permission Requirements
- **Hardware:** Android device or emulator running Android 14+ (API 34 to 37); front or rear RGB camera / laptop webcam; microphone (optional, for voice questions); minimum 4 GB RAM.
- **Permissions Required:**
  - `android.permission.CAMERA`: Live frame capture for OCR, magnification, and MediaPipe hand tracking.
  - `android.permission.RECORD_AUDIO`: Voice question Q&A with assistant.
- **Safe Demo Mode:** If no physical camera is attached, the app uses simulated pointer interactions and built-in sample text cards. If no internet connection or Gemini API key is configured, the built-in deterministic on-device engine fulfills all requests offline.

### 4.3 Plain Text for Gallery Submission Form
```
SteadyRead XR is an accessibility spatial AR reading assistant for optical see-through smart glasses and Android devices, engineered for seniors with low vision and hand tremors (Parkinson's, Essential Tremor).

To use the app:
1. Launch SteadyRead XR and select 'Enable Tremor Help' during setup.
2. (Optional) Complete the 90-second Calibration Wizard to measure your resting hand jitter and air-tap speed.
3. Hold any postcard, letter, bill, or medicine bottle in front of the camera.
4. The smart reticle automatically detects text and locks with green L-brackets.
5. Tap 'Magnify' to view a stabilized, 1.5x-6.0x optical image crop with low-vision contrast filters, and tap 'Freeze' to rest your hand while reading.
6. Tap 'Summarize' or tap dynamic Gemini question chips (e.g., 'What is the dosage?', 'Who sent this?') to view clear, large text and hear spoken answers.
7. Tap 'How to hold' to see occupational therapy bracing hints that reduce hand shake by resting elbows on a tabletop.
```

---

## 5. Visual and Interaction Design

### 5.1 Color System (Optical See-Through Palette)
*Source Evidence: [`app/src/main/java/com/steadyread/xr/ui/theme/OstGlimmerTheme.kt`](app/src/main/java/com/steadyread/xr/ui/theme/OstGlimmerTheme.kt)*

| Token Name | Color Hex / ARGB | Optical Physics Purpose on Waveguides |
|---|---|---|
| `WaveguideTransparentBlack` | `#FF000000` (Pure Black) | Emits 0 nits of light; renders as 100% transparent clear glass on optical waveguides. |
| `PanelScrim50` | `#80000000` (50% Black) | Semi-transparent scrim providing contrast for floating panels without blinding the real world. |
| `InteractiveGreen` | `#FF9FD8A8` (Desaturated Green) | Optical reticle and button outlines; aligned with human photopic peak sensitivity (555 nm). |
| `HighContrastWhite` | `#FFFFFFFF` (Pure White) | Primary text; maximum luminance against the dark scrim. |
| `WarningAmber` | `#FFFFB74D` (Soft Amber) | Raw hand tremor indicator ring and scanning state alerts. |
| `HoloLensCyan` | `#AA00E5FF` (Holographic Cyan) | 21-joint 3D hand skeleton bones and knuckle articulation nodes. |

### 5.2 Typography System
*Source Evidence: [`OstGlimmerTheme.kt`](app/src/main/java/com/steadyread/xr/ui/theme/OstGlimmerTheme.kt)*
- **Typeface:** Google Sans Flex (`createGoogleSansFlexTypography()`) and Roboto fallback.
- **Unit of Scale:** Visual angle degrees converted to spatial scalable pixels (`ssp`).
  - Title: $1.35^\circ$ visual angle ($\approx 24\text{sp}$ at 1 m).
  - Body: $0.95^\circ$ to $1.25^\circ$ visual angle ($\approx 18\text{sp}$–$22\text{sp}$ at 1 m).
  - Minimum Readability Floor: Locked to $0.60^\circ$ ($18\text{sp}$).
- **Weight Rule:** Thin/Hairline weights strictly excluded to prevent high-frequency diffractive shimmering on glasses waveguides. All labels use Medium (500) to Bold (700).

### 5.3 AR / XR Interaction Models
- **HoloLens 3D Hand Tracking:** MediaPipe 21 3D joint landmarks render a glowing cyan skeleton over the user's hand in real time.
- **Damped Holographic Cursor:** A vector line connects the user's raw vibrating index finger (amber circle) to the low-pass damped cursor (green target), providing instant visual proof of software tremor stabilization.
- **Directional Air-Tap:** Blends 70% hand strike downward vector with 30% head gaze vector, matching candidate items within the calibrated aim cone ($15^\circ$–$25^\circ$).
- **Bounce Debounce:** A refractory timer ($350$–$500\text{ ms}$) blocks involuntary muscle rebound strikes.

---

## 6. Technical Implementation

### 6.1 Frameworks and Architecture
- **Language & Runtime:** Kotlin 2.4.21, JetBrains OpenJDK 25.0.4 (`jbr-25`).
- **UI Toolkit:** Jetpack Compose with Jetpack Compose Glimmer (`androidx.xr.glimmer:glimmer:1.0.0-alpha22`).
- **Spatial Framework:** Jetpack XR SceneCore & ARCore for Android XR (`androidx.xr.arcore:1.0.0`, `androidx.xr.scenecore:1.0.0`).
- **Computer Vision:**
  - Google ML Kit Text Recognition v2 (`com.google.mlkit:text-recognition:16.0.1`).
  - Google MediaPipe Tasks Vision (`com.google.mediapipe:tasks-vision:0.10.14`) with bundled `hand_landmarker.task`.
  - CameraX (`androidx.camera:camera-core:1.6.2`, `camera-camera2`, `camera-lifecycle`, `camera-view`).
- **AI Multimodal Reasoning:** Google Gemini REST API (`generateContent`) targeting `gemini-1.5-flash`.
- **Audio:** Android `TextToSpeech` (custom pitch/rate profiles) and `SpeechRecognizer`.

### 6.2 Key Source File Paths

| Subsystem | Key File Path |
|---|---|
| **Entry Point & Lifecycle** | [`app/src/main/java/com/steadyread/xr/MainActivity.kt`](app/src/main/java/com/steadyread/xr/MainActivity.kt) |
| **State Coordinator** | [`app/src/main/java/com/steadyread/xr/viewmodel/ARReadingLensViewModel.kt`](app/src/main/java/com/steadyread/xr/viewmodel/ARReadingLensViewModel.kt) |
| **UI & Holographic HUD** | [`app/src/main/java/com/steadyread/xr/ui/SteadyReadGlassesApp.kt`](app/src/main/java/com/steadyread/xr/ui/SteadyReadGlassesApp.kt) |
| **Glimmer Theme & Colors** | [`app/src/main/java/com/steadyread/xr/ui/theme/OstGlimmerTheme.kt`](app/src/main/java/com/steadyread/xr/ui/theme/OstGlimmerTheme.kt) |
| **State Definitions** | [`app/src/main/java/com/steadyread/xr/ui/LensState.kt`](app/src/main/java/com/steadyread/xr/ui/LensState.kt) |
| **MediaPipe Hand Tracker** | [`app/src/main/java/com/steadyread/xr/interaction/MediaPipeHandTracker.kt`](app/src/main/java/com/steadyread/xr/interaction/MediaPipeHandTracker.kt) |
| **Tap Velocity & Debounce** | [`app/src/main/java/com/steadyread/xr/interaction/CalibratedTapFilter.kt`](app/src/main/java/com/steadyread/xr/interaction/CalibratedTapFilter.kt) |
| **OCR & Vision Pipeline** | [`app/src/main/java/com/steadyread/xr/ocr/SteadyReadOcrPipeline.kt`](app/src/main/java/com/steadyread/xr/ocr/SteadyReadOcrPipeline.kt) |
| **Gemini Client** | [`app/src/main/java/com/steadyread/xr/gemini/GeminiClient.kt`](app/src/main/java/com/steadyread/xr/gemini/GeminiClient.kt) |
| **Assistant Service** | [`app/src/main/java/com/steadyread/xr/gemini/GeminiLiveAssistantService.kt`](app/src/main/java/com/steadyread/xr/gemini/GeminiLiveAssistantService.kt) |
| **Grip Guidance Service** | [`app/src/main/java/com/steadyread/xr/grip/GripGuidanceService.kt`](app/src/main/java/com/steadyread/xr/grip/GripGuidanceService.kt) |
| **Label Summarizer** | [`app/src/main/java/com/steadyread/xr/summary/LabelSummarizerService.kt`](app/src/main/java/com/steadyread/xr/summary/LabelSummarizerService.kt) |
| **Unit Test Suite** | [`app/src/test/java/com/steadyread/xr/TremorHysteresisAndStateTest.kt`](app/src/test/java/com/steadyread/xr/TremorHysteresisAndStateTest.kt) |

### 6.3 Data Storage & Privacy
- **User Profile:** Stored in-memory via Kotlin `StateFlow` in `ARReadingLensViewModel`. No personal health data, names, or images are written to public persistent storage or synced to external telemetry servers.
- **Camera Frames:** Processed ephemerally in RAM buffers; discarded immediately following OCR/magnification extraction.
- **Credentials:** `GEMINI_API_KEY` stored exclusively in gitignored `local.properties` and injected via `BuildConfig`.

---

## 7. How the Project Was Built

### 7.1 Development Stages & Timeline
*Source Evidence: Conversation trajectory logs, git commits, and design doc versions.*

1. **Stage 1 — Architectural Conception & Speculative Design (Oct 26, 2026):**
   - Defined core problem: tremor-vision co-occurrence and the *Handheld Device Paradox*.
   - Established the 5 axioms and authored [`design_doc.md`](docs/DESIGN_DOC_v0.2.md).
   - Set up Gradle build with AGP 9.5.0, compileSdk 37, and Jetpack XR Glimmer alpha22.
2. **Stage 2 — Core State Machine & Mock Pipeline (Oct 26–27, 2026):**
   - Implemented `ARReadingLensViewModel` and state router (`Onboarding`, `SetupInstructions`, `Calibrating`, `Browsing`, `ObjectTargeted`, `PanelExpanded`).
   - Wrote unit tests for tremor hysteresis and debounce timing (`TremorHysteresisAndStateTest`).
3. **Stage 3 — CameraX Live Stream & Real ML Kit OCR (Oct 27–28, 2026):**
   - Bound live camera analyzer to ML Kit Text Recognition v2.
   - Built spatial bounding box calculation and multi-frame bounding hysteresis.
4. **Stage 4 — Optical Magnification & Dynamic Object Adaptation (Oct 28–29, 2026):**
   - Replaced pure OCR text display in Magnify mode with real bitmap cropping, 1.5x–6.0x zoom, pan, freeze, and contrast filters.
   - Refactored assistant questions from medicine-only to dynamic multi-object contexts (postcards, mail, receipts, documents).
5. **Stage 5 — Gemini 1.5 Flash Multimodal Integration (Oct 29, 2026):**
   - Integrated live REST `generateContent` passing cropped frame bitmaps.
   - Built deterministic offline fallback in `GeminiLiveAssistantService.kt` to ensure offline resilience.
6. **Stage 6 — Google MediaPipe 21-Joint 3D Hand Tracking & HoloLens Simulation (Oct 29–30, 2026):**
   - Downloaded and bundled `hand_landmarker.task`.
   - Built `MediaPipeHandTracker.kt` to track 21 3D joints and air-tap kinematics from webcam feeds.
   - Rendered HoloLens holographic cyan bone skeleton and stabilized green cursor in `SteadyReadGlassesApp.kt`.
7. **Stage 7 — UX Polish, Typography & Production Packaging (Oct 30, 2026):**
   - Removed all emojis across UI and assistant speech.
   - Refined typography scales, color contrast, and production packaging.

### 7.2 Technical Challenges, Fixes & Trade-Offs

| Challenge Encountered | Root Cause | Engineering Fix Applied |
|---|---|---|
| **Android SDK License Rejection** | Gradle daemon could not accept licenses for build-tools 36 and platform 37 automatically. | Manually provisioned `android-sdk-license` hashes in `E:\Android\Sdk\licenses\android-sdk-license` and updated `source.properties`. |
| **Unit Test Network Failure** | Adding a real Gemini API key caused unit tests to attempt live HTTP calls on JVM. | Added `GeminiClient.forceOnDeviceMock = true` in test `@Before` setup to ensure 100% offline deterministic test runs. |
| **Webcam Lack of 3D Depth Sensor** | Laptop webcam lacks HoloLens 4-camera IR depth sensors for 6DoF joint tracking. | Integrated Google MediaPipe Tasks Vision (`tasks-vision:0.10.14`) to infer 21 3D coordinates from standard 2D RGB frames. |
| **AI Label Hallucination Risk** | Pure LLM summaries can hallucinate critical numbers on blurry labels. | Created dual-pane architecture: AI summary on top, real optical magnified bitmap below for user verification. |
| **Accidental Double-Clicks** | Tremor bounce rebounds within 200 ms of a tap strike. | Implemented velocity threshold gating ($v > 0.30\text{ m/s}$) combined with a $350\text{ ms}$ refractory window. |

---

## 8. AI Collaboration

### 8.1 Tools Used
- **Google Antigravity Agentic IDE:** Primary agentic pair programmer driving project scaffolding, code generation, refactoring, and command execution.
- **Models Utilized:** Gemini 4 Argon, Claude Opus 5.5, Gemini 3.8 Flash, and Gemini 1.5 Flash.

### 8.2 Division of Responsibility: Student Direction vs. AI Execution

| Dimension | Directed by Student (Praneetha Kamabathula) | Generated / Executed by AI |
|---|---|---|
| **UX & Problem Framing** | Conceived the concept of decoupled reading for tremor seniors; established requirement for optical magnification over blind OCR trust. | Synthesized architectural design documents and medical literature citations. |
| **Visual Tone & Dignity** | Explicitly ordered all emojis removed from UI; specified clean, dignified clinical typography and high-contrast palette. | Refactored UI composables and system prompts to enforce 100% emoji-free output. |
| **Multi-Object Flexibility** | Corrected early medicine-only bias: "Why are the questions all oriented to medicine bottles? I scanned a postcard." | Implemented dynamic context classification supporting postcards, mail, receipts, and food packages. |
| **Hardware Workaround Choice** | Selected Workaround 2 (Google MediaPipe AI Hands) for real webcam tracking over static simulator or WebXR prototype. | Integrated MediaPipe Tasks Vision library, bundled model task, and wired frame processing analyzer. |
| **Testing & Debugging** | Provided error screenshots and directed compilation fixes; verified API key injection. | Resolved Gradle toolchain paths, SDK license hashes, and unit test mocks. |

### 8.3 Representative Actual User Prompts (From Trajectory Logs)
1. *"Project Objective: Initialize Version 1 of a native Android XR accessibility application designed for a speculative optical see-through (OST) headset featuring both AI-glasses form factor and 6DoF hand-tracking..."* (Oct 26, 2026)
2. *"Remove the emojis across the UI. And check if the logic is correct."* (Oct 28, 2026)
3. *"Is the hand tracking working? I can't see it. Is it possible for me to test using my web cam itself? The calibration setup should appear as an option after the instructions. Also currently the way the scanned object is indicated is too rudimentary. And the accuracy is not good for a magnification software. In magnify, I want a magnified image of the object shown, not ocr. Magnify is to ensure the summary is accurate. Also, the assistant is not actually working currently. Why are the questions all oriented to medicine bottles? I scanned a postcard."* (Oct 28, 2026)
4. *"Workaround 2: Google MediaPipe Hands (Real AI Hand Tracking via Webcam). Let's go with this. Also, my professor has a hololens for testing the finished prototype."* (Oct 29, 2026)

---

## 9. Testing

### 9.1 Completed Automated Tests
*Source Evidence: [`app/src/test/java/com/steadyread/xr/TremorHysteresisAndStateTest.kt`](app/src/test/java/com/steadyread/xr/TremorHysteresisAndStateTest.kt)*

All automated unit tests run via Gradle (`gradlew testDebugUnitTest`) and execute offline on the JVM:
1. `testInitialStateIsIdle`: Verifies application boots into `LensState.Browsing` or `Onboarding`.
2. `testRapidTremorExitsDoNotResetActiveTimer`: Validates that simulated 6 Hz hand tremor bounces do not abort active hysteresis confirmations.
3. `testProlongedExitResetsTimer`: Validates that sustained hand exit (> 400 ms debounce grace period) resets the confirmation ring.
4. `testHysteresisCompletionAdvancesState`: Confirms timer reaching 1.2 s triggers state transition from `ObjectLocked` to `PrimaryRead`.
5. `testOfflineGracefulDegradation`: Verifies on-device fallback returns valid structured dosage and warning fields when network is disconnected.
6. `testDirectionalTapAimConeResolution`: Validates angular matching of combined hand+head aiming vectors against candidate targets.
7. `testStrikeVelocityGating`: Verifies downward velocity below threshold is rejected as ambient tremor.
8. `testRefractoryBounceWindowDebounce`: Confirms secondary strikes within 350 ms are ignored.

- **Test Execution Result:** **PASS (8 of 8 tests passing)**.

### 9.2 Completed Manual & Environmental Tests
- **Webcam OCR Ingestion:** Tested using physical postcards, receipts, and medicine containers held up to laptop webcam.
- **MediaPipe Hand Tracking:** Verified real-time detection of 21 3D landmarks, holographic cyan skeleton overlay, pinch detection, and air-tap strike triggering.
- **Multimodal Gemini Q&A:** Tested live API response generation for dosage instructions, postcard sender identification, and invoice total calculations.

### 9.3 Known Limitations & Bugs
- **Single RGB Camera Depth Ambiguity:** On standard 2D webcams, MediaPipe infers the $Z$ coordinate from 2D joint geometry. In severe low light or extreme angles, depth estimation can jitter.
- **Webcam Latency on Low-End Laptops:** Processing both ML Kit Text Recognition and MediaPipe 3D Hand Landmarks simultaneously at 1080p can drop frame rates on low-spec integrated GPUs.
- **External Clinical Trials:** *Not documented* (formal patient trials with clinically diagnosed Parkinson's or Essential Tremor cohorts have not yet been conducted; see student checklist).

### 9.4 Recommended Future Tests
- **Cohort Usability Study:** 15 elderly participants (7 with Parkinson's, 8 with Essential Tremor) testing task completion time on prescription bottles vs. smartphone camera.
- **Waveguide Optical Contrast Benchmarking:** Photometric lux and contrast ratio measurements on physical HoloLens 2 / Magic Leap 2 diffractive waveguides.

---

## 10. Setup and Deployment

### 10.1 System Requirements
- **OS:** Windows 10/11, macOS, or Linux.
- **JDK:** OpenJDK 17 or higher (JetBrains Runtime JBR 25 recommended).
- **Android SDK:** Platforms `android-34` through `android-37`, Build-Tools `36.0.0`.
- **Hardware:** PC with webcam or connected Android phone/emulator.

### 10.2 Configuration (Environment Variables & Properties)
Create a `local.properties` file in the project root based on `local.properties.example`:
```properties
## Local SDK Location
sdk.dir=C:\\Users\\your_username\\AppData\\Local\\Android\\Sdk

## Gemini API Configuration (No quotes, no spaces)
GEMINI_API_KEY=your_gemini_api_key_here
GEMINI_MODEL=gemini-1.5-flash
```
*Note: Never commit `local.properties` or real API keys to version control.*

### 10.3 Build Instructions
To build the debug APK and run all unit tests from the command line:
```bash
# Run unit tests
./gradlew testDebugUnitTest

# Assemble debug APK
./gradlew assembleDebug
```
The output APK is generated at:
`app/build/outputs/apk/debug/app-debug.apk`

### 10.4 Deployment to Device or Emulator
```bash
# Verify connected devices
adb devices

# Install APK
adb install -r app/build/outputs/apk/debug/app-debug.apk

# Launch MainActivity
adb shell am start -n com.steadyread.xr/.MainActivity
```

---

## 11. Credits and Next Steps

### 11.1 Author & Attribution
- **Author & Lead Researcher:** Praneetha Kamabathula (Student ID: 1122230013)
- **Copyright:** © 2026 Praneetha Kamabathula. All rights reserved.

### 11.2 External Libraries & Research References
- **Clinical & Interaction References:**
  - *Tremor and Other Hyperkinetic Movements* (Meta-analysis of 42 population studies across 23 countries on Essential Tremor prevalence and progression per decade, DOI: 10.5334/tohm.632).
  - *ISPRS International Journal of Geo-Information* 2022, 11(2), 127 (Empirical evaluation of 600 ms vs. 1000 ms dwell thresholds, visual fatigue, and fixation accuracy, $n=38$).
  - Jacob, R. J. K. (1991). *The use of eye movements in human-computer interaction techniques: What you look at is what you get.* ACM Transactions on Information Systems (Foundational study on the Midas Touch problem).
- **Libraries & Models:**
  - **Google Jetpack Compose Glimmer:** Optical see-through UI components and spatial typography tokens.
  - **Google MediaPipe Tasks Vision:** Pre-trained `hand_landmarker.task` 21-joint 3D hand tracking neural model.
  - **Google ML Kit:** Text Recognition v2 (on-device Latin script OCR).
  - **Google Gemini 1.5 Flash:** Multimodal generative reasoning REST API.
  - **AndroidX & CameraX:** Modern Android camera streaming pipeline.

### 11.3 Planned Improvements
1. **Physical HoloLens 2 / OpenXR Runtime Port:** Deploy native Android XR APK directly to HoloLens 2 headset using OpenXR hand tracking subsystem.
2. **Hand Tracking Precision & Depth Resilience:**
   - Enhance $Z$-axis depth stability and filter noise under low-light or backlit environments.
   - Improve joint tracking resilience for arthritic hand deformities, muscle contractures, and severe motor tremor vibrations (> 8 Hz).
   - Optimize on-device neural inference to achieve ultra-low latency (< 16 ms) tracking.
3. **Target Hardware Environment — XREAL Aura:**
   - While the current prototype can be demonstrated via webcams and Android XR emulators, the ideal target hardware environment for SteadyRead XR is the **XREAL Aura** (lightweight optical see-through smart glasses with dedicated spatial compute). This form factor provides all-day wearable comfort, true additive optical waveguide pass-through, and dedicated sensor placement without the weight or social stigma of bulky VR/MR headsets.
4. **Multi-Language OCR & Translation:** Real-time on-device translation of foreign language packaging and multilingual medicine labels.

---

## 12. Submission Details

- **Student Name:** Praneetha Kamabathula
- **Student ID:** 1122230013
- **Live Project Web Demo:** [https://steadyread-demo.netlify.app/](https://steadyread-demo.netlify.app/)
- **LinkedIn Profile:** [https://www.linkedin.com/in/praneetha-kamabathula](https://www.linkedin.com/in/praneetha-kamabathula)
- **Demo Video File Name:** `SteadyRead_XR_Demo_1122230013.mp4`

---

## 13. Student Verification Checklist

Before submitting this document and the final ZIP package, please review and confirm the following items:

- [x] **Verify Personal Details:** Check your name spelling (*Praneetha Kamabathula*) and Student ID (*1122230013*).
- [x] **Fill In Submission Links:** Live web demo and LinkedIn profile inserted in Section 12.
- [x] **Demo Video File Name:** Upload file named `SteadyRead_XR_Demo_1122230013.mp4`.
- [x] **Confirm External Clinical Testing Label:** Section 9 accurately marks clinical patient trials as *Not documented* (testing conducted via webcam/emulator simulations).
- [x] **API Key Exclusion:** Verify that `local.properties` is NOT included in the submission ZIP (only `local.properties.example` is present).
- [x] **Build Verification:** Code compiles cleanly without errors and unit tests pass.

---

## Appendix: Project Documentation Links

- **Philosophy & Human Factors:** [`docs/PHILOSOPHY_AND_DESIGN_DECISIONS.md`](docs/PHILOSOPHY_AND_DESIGN_DECISIONS.md)
- **System Architecture & Status Report:** [`docs/PROJECT_STATUS_REPORT.md`](docs/PROJECT_STATUS_REPORT.md)
- **Original Speculative Design Doc (v0.2):** [`docs/DESIGN_DOC_v0.2.md`](docs/DESIGN_DOC_v0.2.md)
- **Quick-Start Guide:** [`README.md`](README.md)
