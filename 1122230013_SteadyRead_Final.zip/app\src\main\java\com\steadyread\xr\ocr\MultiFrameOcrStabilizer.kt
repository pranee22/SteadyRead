﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.ocr

import android.graphics.Rect
import com.steadyread.xr.ui.ReadProblem
import kotlin.math.max

/**
 * A single OCR word hypothesis observed in a sharp frame.
  * Developed by Praneetha Kamabathula.
 */
data class WordObservation(
    val word: String,
    val boundingBox: Rect?,
    val timestampMs: Long
)

/**
 * Result of multi-frame stabilization.
 */
data class StabilizedOcrResult(
    val consolidatedHeadline: String,
    val fullConsolidatedText: String,
    val confidence: Float,
    val diagnosedProblem: ReadProblem? = null
)

/**
 * Feature 4: Motion-Tolerant Multi-Frame Magnification & Diagnostics (§4.1, §4.5)
 *
 * Keeps text legible even while the held object is shaking:
 * 1. Discards blurry frames, keeping only the sharpest.
 * 2. Aggregates text hypotheses across frames using consensus voting (words must be confirmed
 *    across multiple frames to eliminate motion blur artifacts).
 * 3. Diagnoses specific read impediments (Too Far, Blurry/Shaking, Too Dark, Glare, Wrapped Label).
 */
class MultiFrameOcrStabilizer(
    private val consensusThresholdFrames: Int = 3,
    private val historyWindowMs: Long = 1800L
) {
    // Sliding window of recognized lines grouped by normalized key
    private val lineObservationHistory = mutableListOf<Pair<Long, String>>()
    private val wordFrequencyMap = mutableMapOf<String, Int>()

    private var sharpFramesProcessed = 0
    private var blurryFramesDropped = 0
    private var totalFramesSampled = 0

    /**
     * Scores frame sharpness using image gradient/edge variance.
     * Returns true if the frame is sharp enough to be fed into ML Kit OCR.
     */
    fun isFrameSharp(
        averageBrightness: Float, // 0.0 to 255.0
        edgeVarianceScore: Float  // Higher is sharper
    ): Pair<Boolean, ReadProblem?> {
        totalFramesSampled++

        if (averageBrightness < 35.0f) {
            return false to ReadProblem.TOO_DARK
        }

        val sharpnessThreshold = 140.0f
        if (edgeVarianceScore < sharpnessThreshold) {
            blurryFramesDropped++
            val severeBlurRatio = blurryFramesDropped.toFloat() / max(1, totalFramesSampled).toFloat()
            val problem = if (severeBlurRatio > 0.70f && totalFramesSampled > 10) {
                ReadProblem.BLURRY_SHAKING
            } else null
            return false to problem
        }

        sharpFramesProcessed++
        return true to null
    }

    /**
     * Ingests raw OCR text lines from a sharp frame and updates consensus tracking.
     */
    fun ingestFrameText(
        extractedLines: List<String>,
        timestampMs: Long
    ): StabilizedOcrResult {
        // Purge observations older than the history window
        val cutoff = timestampMs - historyWindowMs
        lineObservationHistory.removeAll { it.first < cutoff }

        for (line in extractedLines) {
            val clean = line.trim()
            if (clean.length > 2) {
                lineObservationHistory.add(timestampMs to clean)
            }
        }

        // Tally line frequencies across observed sharp frames
        val lineCounts = mutableMapOf<String, Int>()
        for ((_, text) in lineObservationHistory) {
            lineCounts[text] = (lineCounts[text] ?: 0) + 1
        }

        // Retain only lines confirmed in >= consensusThresholdFrames
        val confirmedLines = lineCounts
            .filter { it.value >= consensusThresholdFrames }
            .keys
            .toList()

        if (confirmedLines.isEmpty()) {
            // Check if we have detected text but cannot reach consensus due to tremor
            val candidateLines = lineCounts.keys.toList()
            val diagnosis = if (candidateLines.isNotEmpty() && blurryFramesDropped > 5) {
                ReadProblem.BLURRY_SHAKING
            } else if (candidateLines.isEmpty() && totalFramesSampled > 15) {
                ReadProblem.FACING_AWAY
            } else null

            val fallbackHeadline = candidateLines.firstOrNull() ?: ""
            return StabilizedOcrResult(
                consolidatedHeadline = fallbackHeadline,
                fullConsolidatedText = candidateLines.joinToString("\n"),
                confidence = 0.40f,
                diagnosedProblem = diagnosis
            )
        }

        // The largest/first confirmed line becomes the primary magnified headline
        val primaryHeadline = confirmedLines.maxByOrNull { it.length } ?: confirmedLines.first()
        val fullText = confirmedLines.joinToString("\n")

        return StabilizedOcrResult(
            consolidatedHeadline = primaryHeadline,
            fullConsolidatedText = fullText,
            confidence = 0.94f,
            diagnosedProblem = null
        )
    }

    fun reset() {
        lineObservationHistory.clear()
        wordFrequencyMap.clear()
        sharpFramesProcessed = 0
        blurryFramesDropped = 0
        totalFramesSampled = 0
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
