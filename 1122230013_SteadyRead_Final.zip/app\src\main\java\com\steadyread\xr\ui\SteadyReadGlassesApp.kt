﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.ui

import android.graphics.Bitmap
import android.view.ViewGroup
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.xr.glimmer.Button
import androidx.xr.glimmer.Card
import androidx.xr.glimmer.Text
import com.steadyread.xr.ui.theme.LocalSpatialAngularTypography
import com.steadyread.xr.ui.theme.OstOpticalPalette
import com.steadyread.xr.ui.theme.ssp
import com.steadyread.xr.viewmodel.ARReadingLensViewModel
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Main Application View for AI Glasses (Optical See-Through Smart Glasses).
 *
 * Implements Google's Made for AI Glasses & Augmented Architecture Guidelines:
 * 1. Live Camera Preview Layer + Webcam Optical Hand & Tremor Tracker.
 * 2. First-time Setup + Instructions with direct option to launch the 5-Step Calibration Wizard.
 * 3. Precision Spatial Object Targeting Reticle (adaptive bounding box, corner L-brackets,
 *    individual text line highlights, and category/confidence lock badge).
 * 4. True Optical Image Magnification in Magnify mode (stabilized high-res cropped image
 *    with 1.5x-6.0x zoom, drag-to-pan, and low-vision contrast filters to verify summary accuracy).
 * 5. Context-aware Gemini Live assistant & question chips tailored to the actual scanned object
 *    (Postcards, Mail, Receipts, Food, Hardware, or Medication).
  * Developed by Praneetha Kamabathula.
 */
@Composable
fun SteadyReadGlassesApp(
    viewModel: ARReadingLensViewModel,
    modifier: Modifier = Modifier
) {
    val currentLensState by viewModel.lensState.collectAsState()
    val textSizePref by viewModel.textSizePreference.collectAsState()
    val tremorProfile by viewModel.tremorProfile.collectAsState()
    val assistantVoice by viewModel.assistantVoice.collectAsState()
    val isSettingsOpen by viewModel.isSettingsOpen.collectAsState()
    val isPeripheralSettingsVisible by viewModel.isPeripheralSettingsVisible.collectAsState()
    val isWebcamPreviewVisible by viewModel.isWebcamPreviewVisible.collectAsState()
    val isVoiceListening by viewModel.isVoiceListening.collectAsState()

    val handTelemetry by viewModel.handTrackingTelemetry.collectAsState()
    val isHandOverlayVisible by viewModel.isHandOverlayVisible.collectAsState()
    val liveDetectedBox by viewModel.liveDetectedBox.collectAsState()
    val liveTextBlockBoxes by viewModel.liveTextBlockBoxes.collectAsState()
    val liveCroppedBitmap by viewModel.liveCroppedBitmap.collectAsState()
    val liveFullFrameBitmap by viewModel.liveFullFrameBitmap.collectAsState()
    val magnificationZoom by viewModel.magnificationZoom.collectAsState()
    val magnificationContrast by viewModel.magnificationContrast.collectAsState()
    val isMagnifierFrozen by viewModel.isMagnifierFrozen.collectAsState()
    val userName by viewModel.userName.collectAsState()
    val userAge by viewModel.userAge.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val change = event.changes.firstOrNull()
                        if (change != null && size.width > 0 && size.height > 0) {
                            val normX = (change.position.x / size.width).coerceIn(0f, 1f)
                            val normY = (change.position.y / size.height).coerceIn(0f, 1f)
                            viewModel.onPointerMoved(normX, normY)
                        }
                    }
                }
            }
    ) {
        // ====================================================================
        // Layer 0: Live Webcam Video Stream (CameraX PreviewView)
        // ====================================================================
        if (isWebcamPreviewVisible) {
            AndroidView(
                factory = { context ->
                    PreviewView(context).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        viewModel.setCameraSurfaceProvider(surfaceProvider)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x28000000))
            )
        }

        // ====================================================================
        // Layer 0.5: Live Webcam Hand & Tremor Tracking Visual Overlay
        // ====================================================================
        if (isHandOverlayVisible) {
            HandTrackingHudOverlay(
                telemetry = handTelemetry,
                isTremorFilterEnabled = tremorProfile.isTremorAssistanceEnabled,
                modifier = Modifier.fillMaxSize()
            )
        }

        // ====================================================================
        // Layer 1: Gesture Detection & Spatial AR HUD
        // ====================================================================
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { viewModel.onSingleTap() },
                        onDoubleTap = { offset ->
                            viewModel.onDoubleTap(
                                tapX = offset.x / size.width.coerceAtLeast(1),
                                tapY = offset.y / size.height.coerceAtLeast(1)
                            )
                        }
                    )
                }
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            // ----------------------------------------------------------------
            // Top HUD Bar: Camera Mode, Hand Tracking Telemetry & Settings
            // ----------------------------------------------------------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(modifier = Modifier.width(1.dp))

                AnimatedVisibility(
                    visible = (isPeripheralSettingsVisible && !isSettingsOpen),
                    enter = fadeIn() + slideInVertically(initialOffsetY = { -30 }),
                    exit = fadeOut() + slideOutVertically(targetOffsetY = { -30 })
                ) {
                    Button(onClick = { viewModel.openSettings() }) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "Settings", fontSize = 14.ssp, fontWeight = FontWeight.Bold)
                            if (tremorProfile.isTremorAssistanceEnabled) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(OstOpticalPalette.InteractiveGreen, CircleShape)
                                )
                            }
                        }
                    }
                }
            }

            // ----------------------------------------------------------------
            // Core View Router
            // ----------------------------------------------------------------
            when (val state = currentLensState) {
                is LensState.Onboarding -> {
                    GlassesOnboardingCard(
                        step = state.step,
                        initialName = userName,
                        initialAge = userAge,
                        onName = { viewModel.submitName(it) },
                        onAge = { viewModel.submitAge(it) },
                        onTremor = { viewModel.chooseTremorAssistance(it) },
                        modifier = Modifier.align(Alignment.Center)
                    )
                }

                is LensState.SetupInstructions -> {
                    GlassesSetupInstructionsCard(
                        onStartCalibration = { viewModel.startTremorCalibrationWizard() },
                        onDismiss = { viewModel.dismissSetupInstructions() },
                        modifier = Modifier.align(Alignment.Center)
                    )
                }

                is LensState.Browsing -> {
                    // Live spatial acquisition reticle showing what the camera is currently tracking
                    Box(modifier = Modifier.fillMaxSize()) {
                        SpatialObjectTargetReticle(
                            boundingBox = liveDetectedBox,
                            textBlockBoxes = liveTextBlockBoxes,
                            title = state.detectedObjectsInView.firstOrNull() ?: "Scanning Environment...",
                            category = if (liveTextBlockBoxes.isNotEmpty()) "LIVE TARGET READY" else "AIM AT ITEM",
                            confidence = if (liveTextBlockBoxes.isNotEmpty()) 0.96f else 0.0f,
                            isLocked = false,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = 48.dp, bottom = 84.dp)
                        )

                        GlassesIdleView(
                            onTriggerSingleTap = { viewModel.onSingleTap() },
                            onTriggerDoubleTap = { viewModel.onDoubleTap() },
                            modifier = Modifier.align(Alignment.BottomCenter)
                        )
                    }
                }

                is LensState.ObjectTargeted -> {
                    GlassesObjectTargetedView(
                        state = state,
                        onSelectAction = { action -> viewModel.onSelectTargetAction(action) },
                        onClose = { viewModel.onSelectTargetAction(LensAction.CLOSE) },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                is LensState.PanelExpanded -> {
                    GlassesPanelExpandedView(
                        state = state,
                        textSizePref = textSizePref,
                        isVoiceListening = isVoiceListening,
                        liveCroppedBitmap = liveCroppedBitmap ?: liveFullFrameBitmap,
                        magnificationZoom = magnificationZoom,
                        magnificationContrast = magnificationContrast,
                        isMagnifierFrozen = isMagnifierFrozen,
                        onSetZoom = { z -> viewModel.setMagnificationZoom(z) },
                        onStepZoom = { dz -> viewModel.stepMagnificationZoom(dz) },
                        onSetContrast = { mode -> viewModel.setMagnificationContrast(mode) },
                        onToggleFrozen = { viewModel.toggleMagnifierFrozen() },
                        onRecaptureSnapshot = { viewModel.recaptureMagnifierSnapshot() },
                        onChipClicked = { chip -> viewModel.onAiChipClicked(chip) },
                        onAskCustomQuestion = { text -> viewModel.askCustomQuestion(text) },
                        onToggleVoiceListening = { viewModel.toggleVoiceListening() },
                        onBackToActions = { viewModel.closeExpandedPanel() },
                        onDismissAll = { viewModel.dismissTarget() },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                is LensState.Calibrating -> {
                    GlassesCalibrationWizard(
                        step = state.step,
                        handTelemetry = handTelemetry,
                        onAdvance = { viewModel.advanceCalibrationStep() },
                        onStepUp = { viewModel.stepTextSizeUp() },
                        onStepDown = { viewModel.stepTextSizeDown() },
                        onExit = { viewModel.exitCalibration() },
                        modifier = Modifier.align(Alignment.Center)
                    )
                }

                else -> {
                    GlassesIdleView(
                        onTriggerSingleTap = { viewModel.onSingleTap() },
                        onTriggerDoubleTap = { viewModel.onDoubleTap() },
                        modifier = Modifier.align(Alignment.BottomCenter)
                    )
                }
            }
        }

        // Status line (finding the object, errors)
        statusMessage?.let { msg ->
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 28.dp)
                    .background(Color(0xE6303030), RoundedCornerShape(50))
                    .border(2.dp, Color(0xFF606460), RoundedCornerShape(50))
                    .padding(horizontal = 22.dp, vertical = 12.dp)
            ) {
                Text(text = msg, fontSize = 16.ssp, color = OstOpticalPalette.HighContrastWhite, fontWeight = FontWeight.SemiBold)
            }
        }

        // ====================================================================
        // Layer 2: Modal Accessibility Settings Sheet
        // ====================================================================
        if (isSettingsOpen) {
            GlassesSettingsSheet(
                viewModel = viewModel,
                textSizePref = textSizePref,
                tremorProfile = tremorProfile,
                assistantVoice = assistantVoice,
                isWebcamPreviewVisible = isWebcamPreviewVisible,
                isHandOverlayVisible = isHandOverlayVisible,
                onClose = { viewModel.closeSettings() }
            )
        }
    }
}

// ============================================================================
// 0. Live Hand & Tremor Tracking Overlay + Spatial Object Reticle
// ============================================================================

@Composable
private fun HandTrackingHudOverlay(
    telemetry: HandTrackingTelemetry,
    isTremorFilterEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val rawCenter = Offset(
            x = (telemetry.normalizedX * size.width).coerceIn(0f, size.width),
            y = (telemetry.normalizedY * size.height).coerceIn(0f, size.height)
        )
        val smoothCenter = Offset(
            x = (telemetry.smoothedX * size.width).coerceIn(0f, size.width),
            y = (telemetry.smoothedY * size.height).coerceIn(0f, size.height)
        )

        // If MediaPipe 21-joint 3D hand landmarks are available, draw HoloLens holographic skeleton
        if (telemetry.landmarks.size >= 21) {
            val joints = telemetry.landmarks.map { jm ->
                Offset(
                    x = (jm.x * size.width).coerceIn(0f, size.width),
                    y = (jm.y * size.height).coerceIn(0f, size.height)
                )
            }

            val bones = listOf(
                // Palm base
                0 to 1, 0 to 5, 0 to 17, 5 to 9, 9 to 13, 13 to 17,
                // Thumb
                1 to 2, 2 to 3, 3 to 4,
                // Index
                5 to 6, 6 to 7, 7 to 8,
                // Middle
                9 to 10, 10 to 11, 11 to 12,
                // Ring
                13 to 14, 14 to 15, 15 to 16,
                // Pinky
                17 to 18, 18 to 19, 19 to 20
            )

            // 1. Draw HoloLens cyan holographic bones
            for ((from, to) in bones) {
                if (from < joints.size && to < joints.size) {
                    drawLine(
                        color = Color(0xAA00E5FF),
                        start = joints[from],
                        end = joints[to],
                        strokeWidth = 2.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // 2. Draw holographic joint nodes
            for ((idx, pos) in joints.withIndex()) {
                val isTip = idx in listOf(4, 8, 12, 16, 20)
                drawCircle(
                    color = if (isTip) Color(0xFF00E5FF) else Color(0xCC80D8FF),
                    radius = if (isTip) 4.5.dp.toPx() else 3.dp.toPx(),
                    center = pos
                )
            }

            // 3. Pinch indicator (Thumb tip + Index tip)
            if (telemetry.isPinching) {
                val pinchCenter = Offset(
                    x = (joints[4].x + joints[8].x) * 0.5f,
                    y = (joints[4].y + joints[8].y) * 0.5f
                )
                drawCircle(
                    color = Color(0xFF00E676),
                    radius = 14.dp.toPx(),
                    center = pinchCenter,
                    style = Stroke(width = 2.5.dp.toPx())
                )
            }
        }

        // 4. Raw unfiltered hand pointer (amber ring showing real hand tremor jitter)
        drawCircle(
            color = Color(0x88FFB74D),
            radius = 18.dp.toPx(),
            center = rawCenter,
            style = Stroke(width = 1.5.dp.toPx())
        )

        // 5. Vector damping line between raw hand tremor and stabilized focus
        if (isTremorFilterEnabled) {
            drawLine(
                color = Color(0x999FD8A8),
                start = rawCenter,
                end = smoothCenter,
                strokeWidth = 1.5.dp.toPx()
            )
        }

        // 6. Stabilized HoloLens holographic cursor (high-contrast interactive green reticle)
        val activeCenter = if (isTremorFilterEnabled) smoothCenter else rawCenter
        drawCircle(
            color = OstOpticalPalette.InteractiveGreen,
            radius = 10.dp.toPx(),
            center = activeCenter,
            style = Stroke(width = 2.4.dp.toPx())
        )
        drawCircle(
            color = OstOpticalPalette.InteractiveGreen,
            radius = 3.5.dp.toPx(),
            center = activeCenter
        )
    }
}

/**
 * Precision AR Spatial Object Reticle with dynamic corner L-brackets,
 * sub-block text line highlights, and an anchored telemetry badge.
 */
@Composable
private fun SpatialObjectTargetReticle(
    boundingBox: NormalizedRect,
    textBlockBoxes: List<NormalizedRect>,
    title: String,
    category: String,
    confidence: Float,
    isLocked: Boolean,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier) {
        val wPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val hPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)

        val leftPx = (boundingBox.left * wPx).coerceIn(8f, wPx - 40f)
        val topPx = (boundingBox.top * hPx).coerceIn(8f, hPx - 40f)
        val rightPx = (boundingBox.right * wPx).coerceIn(leftPx + 40f, wPx - 8f)
        val bottomPx = (boundingBox.bottom * hPx).coerceIn(topPx + 40f, hPx - 8f)

        val primaryColor = if (isLocked) OstOpticalPalette.InteractiveGreen else Color(0xCC9FD8A8)

        Canvas(modifier = Modifier.fillMaxSize()) {
            val boxW = rightPx - leftPx
            val boxH = bottomPx - topPx

            // Subtle translucent framing fill when locked
            if (isLocked) {
                drawRoundRect(
                    color = Color(0x189FD8A8),
                    topLeft = Offset(leftPx, topPx),
                    size = Size(boxW, boxH),
                    cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx())
                )
            }

            // Dashed perimeter guide
            drawRoundRect(
                color = primaryColor.copy(alpha = 0.45f),
                topLeft = Offset(leftPx, topPx),
                size = Size(boxW, boxH),
                cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx()),
                style = Stroke(
                    width = 1.2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f), 0f)
                )
            )

            // Precision Corner L-Brackets
            val bracketLen = minOf(boxW, boxH) * 0.22f
            val strokeW = if (isLocked) 3.2.dp.toPx() else 2.2.dp.toPx()

            // Top-Left Bracket
            drawLine(primaryColor, Offset(leftPx, topPx), Offset(leftPx + bracketLen, topPx), strokeW, StrokeCap.Round)
            drawLine(primaryColor, Offset(leftPx, topPx), Offset(leftPx, topPx + bracketLen), strokeW, StrokeCap.Round)

            // Top-Right Bracket
            drawLine(primaryColor, Offset(rightPx, topPx), Offset(rightPx - bracketLen, topPx), strokeW, StrokeCap.Round)
            drawLine(primaryColor, Offset(rightPx, topPx), Offset(rightPx, topPx + bracketLen), strokeW, StrokeCap.Round)

            // Bottom-Left Bracket
            drawLine(primaryColor, Offset(leftPx, bottomPx), Offset(leftPx + bracketLen, bottomPx), strokeW, StrokeCap.Round)
            drawLine(primaryColor, Offset(leftPx, bottomPx), Offset(leftPx, bottomPx - bracketLen), strokeW, StrokeCap.Round)

            // Bottom-Right Bracket
            drawLine(primaryColor, Offset(rightPx, bottomPx), Offset(rightPx - bracketLen, bottomPx), strokeW, StrokeCap.Round)
            drawLine(primaryColor, Offset(rightPx, bottomPx), Offset(rightPx, bottomPx - bracketLen), strokeW, StrokeCap.Round)

            // Individual detected text block highlights inside the object
            for (sub in textBlockBoxes) {
                val sx = (sub.left * wPx).coerceIn(leftPx, rightPx)
                val sy = (sub.top * hPx).coerceIn(topPx, bottomPx)
                val sw = ((sub.right - sub.left) * wPx).coerceAtLeast(8f)
                val sh = ((sub.bottom - sub.top) * hPx).coerceAtLeast(6f)

                drawRoundRect(
                    color = Color(0x269FD8A8),
                    topLeft = Offset(sx, sy),
                    size = Size(sw, sh),
                    cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                )
                drawRoundRect(
                    color = primaryColor.copy(alpha = 0.65f),
                    topLeft = Offset(sx, sy),
                    size = Size(sw, sh),
                    cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                    style = Stroke(width = 1.dp.toPx())
                )
            }
        }

        // Anchored Telemetry Header Pill at the top-left of the bounding box
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .offset {
                    IntOffset(
                        x = leftPx.roundToInt(),
                        y = (topPx - 36.dp.toPx()).coerceAtLeast(4f).roundToInt()
                    )
                }
                .background(OstOpticalPalette.SurfaceDark, RoundedCornerShape(10.dp))
                .border(1.dp, primaryColor, RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(primaryColor, CircleShape)
            )
            Text(
                text = category.uppercase(Locale.ROOT),
                color = OstOpticalPalette.InteractiveGreen,
                fontSize = 11.ssp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "•",
                color = OstOpticalPalette.SecondaryText,
                fontSize = 11.ssp
            )
            Text(
                text = title.take(34),
                color = OstOpticalPalette.HighContrastWhite,
                fontSize = 12.ssp,
                fontWeight = FontWeight.SemiBold
            )
            if (confidence > 0f) {
                Text(
                    text = "${(confidence * 100).roundToInt()}% LOCK",
                    color = OstOpticalPalette.SecondaryText,
                    fontSize = 10.ssp
                )
            }
        }
    }
}

// ============================================================================
// 1. Setup + Instructions Card (with immediate Calibration Wizard option)
// ============================================================================

@Composable
private fun GlassesSetupInstructionsCard(
    onStartCalibration: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val typography = LocalSpatialAngularTypography.current

    Card(
        onClick = {},
        modifier = modifier.widthIn(max = 540.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SteadyRead XR",
                        style = typography.titleStyle,
                        color = OstOpticalPalette.HighContrastWhite
                    )
                    Text(
                        text = "Optical Magnification & Tremor-Stabilized AI Glasses",
                        style = typography.captionStyle,
                        color = OstOpticalPalette.InteractiveGreen
                    )
                }

                Button(onClick = onDismiss) {
                    Text(text = "Skip", fontSize = 13.ssp)
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            InstructionRow(
                stepNumber = "1",
                title = "Double-tap to read",
                description = "Double-tap anything with print on it. It is highlighted and a bubble with Magnify, Summarize and Close appears beside it."
            )

            InstructionRow(
                stepNumber = "2",
                title = "Magnify or Summarize",
                description = "Pick one and the answer opens next to the object, with more options underneath."
            )

            InstructionRow(
                stepNumber = "3",
                title = "Ask Gemini",
                description = "Tap a suggested question under the answer, or ask your own by voice or keyboard."
            )

            InstructionRow(
                stepNumber = "4",
                title = "Tap once for Settings",
                description = "A single tap shows the Settings button at the edge of your view. It hides again after a few seconds."
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Primary Option 1: Launch Calibration Setup immediately after instructions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onStartCalibration,
                    modifier = Modifier.weight(1.15f)
                ) {
                    Text(
                        text = "Redo calibration",
                        fontSize = 14.ssp,
                        fontWeight = FontWeight.Bold,
                        color = OstOpticalPalette.InteractiveGreen,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.weight(0.85f)
                ) {
                    Text(
                        text = "Start Reading ->",
                        fontSize = 14.ssp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun InstructionRow(
    stepNumber: String,
    title: String,
    description: String
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .background(OstOpticalPalette.InteractiveGreenDim, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stepNumber,
                color = OstOpticalPalette.HighContrastWhite,
                fontSize = 12.ssp,
                fontWeight = FontWeight.Bold
            )
        }
        Column {
            Text(
                text = title,
                color = OstOpticalPalette.HighContrastWhite,
                fontSize = 14.ssp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = description,
                color = OstOpticalPalette.SecondaryText,
                fontSize = 12.ssp,
                lineHeight = 16.ssp
            )
        }
    }
}

// ============================================================================
// 2. Idle View (Unobstructed physical view)
// ============================================================================

@Composable
private fun GlassesIdleView(
    onTriggerSingleTap: () -> Unit,
    onTriggerDoubleTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.padding(bottom = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .background(OstOpticalPalette.CardScrim, RoundedCornerShape(24.dp))
                .border(1.dp, OstOpticalPalette.InteractiveGreenDim, RoundedCornerShape(24.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = "Double-tap to lock & inspect item  •  Single-tap for Settings",
                color = OstOpticalPalette.HighContrastWhite,
                fontSize = 13.ssp
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onTriggerSingleTap) {
                Text(text = "Single Tap (Settings)", fontSize = 12.ssp)
            }
            Button(onClick = onTriggerDoubleTap) {
                Text(text = "Double Tap (Lock Target)", fontSize = 12.ssp)
            }
        }
    }
}

// ============================================================================
// 3. Object Targeted View: Spatial Precision Reticle + Anchored Side Bubble
// ============================================================================

@Composable
private fun GlassesObjectTargetedView(
    state: LensState.ObjectTargeted,
    onSelectAction: (LensAction) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val typography = LocalSpatialAngularTypography.current

    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(top = 46.dp, bottom = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left / Center: Adaptive Spatial Target Reticle over the scanned object
        SpatialObjectTargetReticle(
            boundingBox = state.target.boundingBox,
            textBlockBoxes = state.target.textBlockBoxes,
            title = state.target.title,
            category = state.target.category,
            confidence = state.target.confidence,
            isLocked = true,
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(end = 20.dp)
        )

        // Right: Anchored Side Action Bubble
        Column(
            modifier = Modifier.width(320.dp)
        ) {
            Column(
                modifier = Modifier.padding(0.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = state.target.category.uppercase(Locale.ROOT),
                        style = typography.captionStyle,
                        color = OstOpticalPalette.InteractiveGreen,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = state.target.title,
                    style = typography.titleStyle,
                    color = OstOpticalPalette.HighContrastWhite
                )

                Spacer(modifier = Modifier.height(2.dp))

                state.availableActions.forEach { action ->
                    Button(
                        onClick = { onSelectAction(action) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = action.label,
                                fontSize = 15.ssp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// 4. Panel Expanded View: Optical Magnifier / Summary + Questions Outside Box
// ============================================================================

@Composable
private fun GlassesPanelExpandedView(
    state: LensState.PanelExpanded,
    textSizePref: TextSizePreference,
    isVoiceListening: Boolean,
    liveCroppedBitmap: Bitmap?,
    magnificationZoom: Float,
    magnificationContrast: MagnificationContrastMode,
    isMagnifierFrozen: Boolean,
    onSetZoom: (Float) -> Unit,
    onStepZoom: (Float) -> Unit,
    onSetContrast: (MagnificationContrastMode) -> Unit,
    onToggleFrozen: () -> Unit,
    onRecaptureSnapshot: () -> Unit,
    onChipClicked: (AiResponseChip) -> Unit,
    onAskCustomQuestion: (String) -> Unit,
    onToggleVoiceListening: () -> Unit,
    onBackToActions: () -> Unit,
    onDismissAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    val typography = LocalSpatialAngularTypography.current
    var customQueryText by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(top = 46.dp, bottom = 10.dp, start = 4.dp, end = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        // ====================================================================
        // Left Column: Target Reticle + Floating Question Cards (OUTSIDE Box)
        // ====================================================================
        Column(
            modifier = Modifier
                .weight(0.95f)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. Compact Precision Target Reticle
            SpatialObjectTargetReticle(
                boundingBox = NormalizedRect(0.06f, 0.22f, 0.94f, 0.94f),
                textBlockBoxes = emptyList(),
                title = state.target.title,
                category = state.target.category,
                confidence = state.target.confidence,
                isLocked = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            )

            // 2. Context-Aware Suggested Questions (Completely OUTSIDE bounding box)
            Card(
                onClick = {},
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    Text(
                        text = "Questions for ${state.target.category.uppercase(Locale.ROOT)}:",
                        style = typography.captionStyle,
                        color = OstOpticalPalette.InteractiveGreen,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )

                    Text(
                        text = "Tap any question to ask Gemini Live:",
                        fontSize = 11.ssp,
                        color = OstOpticalPalette.SecondaryText,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(state.aiChips) { chip ->
                            Card(
                                onClick = { onChipClicked(chip) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(
                                        width = 1.dp,
                                        color = OstOpticalPalette.InteractiveGreenDim,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(horizontal = 12.dp, vertical = 10.dp)
                                        .fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = chip.label,
                                        color = OstOpticalPalette.HighContrastWhite,
                                        fontSize = 13.ssp,
                                        fontWeight = FontWeight.Medium,
                                        lineHeight = 17.ssp,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = " ->",
                                        color = OstOpticalPalette.InteractiveGreen,
                                        fontSize = 14.ssp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ====================================================================
        // Right Column: True Optical Magnifier OR Summary + Gemini Chat
        // ====================================================================
        Card(
            onClick = {},
            modifier = Modifier
                .weight(1.35f)
                .fillMaxHeight()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (state.selectedAction == LensAction.MAGNIFY) {
                                "OPTICAL MAGNIFIER (${String.format(Locale.US, "%.1fx", magnificationZoom)})"
                            } else {
                                state.selectedAction.label.uppercase(Locale.ROOT)
                            },
                            color = OstOpticalPalette.InteractiveGreen,
                            fontSize = 14.ssp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (state.selectedAction == LensAction.MAGNIFY) {
                                "Drag image to pan • Verify print & handwriting accuracy"
                            } else {
                                state.target.title
                            },
                            color = OstOpticalPalette.SecondaryText,
                            fontSize = 11.ssp
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onBackToActions) {
                            Text(text = "Back", fontSize = 12.ssp)
                        }
                        Button(onClick = onDismissAll) {
                            Text(text = "Close", fontSize = 12.ssp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Main Body Content
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (state.selectedAction == LensAction.MAGNIFY) {
                        // TRUE OPTICAL IMAGE MAGNIFICATION VIEWPORT (Not OCR text!)
                        item {
                            val displayBitmap = if (isMagnifierFrozen) {
                                state.target.capturedBitmap ?: state.target.fullFrameBitmap ?: liveCroppedBitmap
                            } else {
                                liveCroppedBitmap ?: state.target.capturedBitmap ?: state.target.fullFrameBitmap
                            }

                            OpticalMagnifierViewport(
                                bitmap = displayBitmap,
                                fallbackTitle = state.target.title,
                                fallbackRawText = state.target.rawText,
                                zoom = magnificationZoom,
                                contrastMode = magnificationContrast,
                                isFrozen = isMagnifierFrozen,
                                onSetZoom = onSetZoom,
                                onStepZoom = onStepZoom,
                                onSetContrast = onSetContrast,
                                onToggleFrozen = onToggleFrozen,
                                onRecapture = onRecaptureSnapshot
                            )
                        }
                    } else {
                        // Summarize or Show Grip View
                        item {
                            Text(
                                text = state.resultTitle,
                                style = typography.titleStyle,
                                color = OstOpticalPalette.HighContrastWhite
                            )
                        }

                        items(state.resultDetails) { detail ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0x2BFFFFFF), RoundedCornerShape(10.dp))
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = detail,
                                    style = typography.bodyStyle,
                                    color = OstOpticalPalette.HighContrastWhite
                                )
                            }
                        }
                    }

                    // Gemini Live Conversation Log
                    if (state.conversationLog.isNotEmpty()) {
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "GEMINI LIVE CONVERSATION",
                                style = typography.captionStyle,
                                color = OstOpticalPalette.InteractiveGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        items(state.conversationLog) { msg ->
                            val isGemini = msg.isGemini
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        if (isGemini) Color(0x339FD8A8) else Color(0x33FFFFFF),
                                        RoundedCornerShape(12.dp)
                                    )
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Text(
                                        text = if (isGemini) "Gemini Live:" else "You:",
                                        color = if (isGemini) OstOpticalPalette.InteractiveGreen else OstOpticalPalette.SecondaryText,
                                        fontSize = 12.ssp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = msg.text,
                                        style = typography.bodyStyle,
                                        color = OstOpticalPalette.HighContrastWhite
                                    )
                                }
                            }
                        }
                    }

                    if (state.isAiThinking) {
                        item {
                            Text(
                                text = "Gemini Live is analyzing...",
                                color = OstOpticalPalette.InteractiveGreen,
                                fontSize = 13.ssp,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Bottom Conversational Input Bar (Keyboard typing & Microphone Speech)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = customQueryText,
                        onValueChange = { customQueryText = it },
                        placeholder = {
                            Text(
                                text = "Ask about this ${state.target.category}...",
                                color = OstOpticalPalette.SecondaryText,
                                fontSize = 13.ssp
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (customQueryText.isNotBlank()) {
                                    onAskCustomQuestion(customQueryText)
                                    customQueryText = ""
                                    keyboardController?.hide()
                                    focusManager.clearFocus()
                                }
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = OstOpticalPalette.HighContrastWhite,
                            unfocusedTextColor = OstOpticalPalette.HighContrastWhite,
                            focusedBorderColor = OstOpticalPalette.InteractiveGreen,
                            unfocusedBorderColor = OstOpticalPalette.InteractiveGreenDim,
                            cursorColor = OstOpticalPalette.InteractiveGreen
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    Button(
                        onClick = {
                            if (customQueryText.isNotBlank()) {
                                onAskCustomQuestion(customQueryText)
                                customQueryText = ""
                                keyboardController?.hide()
                                focusManager.clearFocus()
                            }
                        }
                    ) {
                        Text(text = "Send", fontSize = 13.ssp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onToggleVoiceListening
                    ) {
                        Text(
                            text = if (isVoiceListening) "Listening..." else "Talk",
                            fontSize = 13.ssp,
                            color = if (isVoiceListening) Color(0xFFFF5252) else OstOpticalPalette.HighContrastWhite,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

/**
 * True Optical Image Magnifier Viewport:
 * Renders the captured high-resolution Bitmap of the scanned object with interactive
 * zoom (1.5x - 6.0x), drag-to-pan, freeze-frame tremor stabilization, and low-vision
 * contrast enhancement filters.
 */
@Composable
private fun OpticalMagnifierViewport(
    bitmap: Bitmap?,
    fallbackTitle: String,
    fallbackRawText: String,
    zoom: Float,
    contrastMode: MagnificationContrastMode,
    isFrozen: Boolean,
    onSetZoom: (Float) -> Unit,
    onStepZoom: (Float) -> Unit,
    onSetContrast: (MagnificationContrastMode) -> Unit,
    onToggleFrozen: () -> Unit,
    onRecapture: () -> Unit
) {
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }

    val colorFilter = remember(contrastMode) {
        when (contrastMode) {
            MagnificationContrastMode.NATURAL -> null
            MagnificationContrastMode.HIGH_CONTRAST -> {
                // Boost contrast (1.65x) for crisp print legibility
                val c = 1.65f
                val t = -128f * (c - 1f)
                ColorFilter.colorMatrix(
                    ColorMatrix(
                        floatArrayOf(
                            c, 0f, 0f, 0f, t,
                            0f, c, 0f, 0f, t,
                            0f, 0f, c, 0f, t,
                            0f, 0f, 0f, 1f, 0f
                        )
                    )
                )
            }
            MagnificationContrastMode.INVERTED_LOW_VISION -> {
                // Inverted high-contrast grayscale for low-vision / glare reduction
                ColorFilter.colorMatrix(
                    ColorMatrix(
                        floatArrayOf(
                            -0.45f, -0.45f, -0.45f, 0f, 255f,
                            -0.45f, -0.45f, -0.45f, 0f, 255f,
                            -0.45f, -0.45f, -0.45f, 0f, 255f,
                            0f, 0f, 0f, 1f, 0f
                        )
                    )
                )
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 1. Optical Loupe Image Window (Drag to Pan, Zoomed to [zoom])
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF101412))
                .border(2.dp, OstOpticalPalette.InteractiveGreen, RoundedCornerShape(14.dp))
                .pointerInput(zoom) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val maxOffset = (zoom - 1f) * 260f
                        panX = (panX + dragAmount.x).coerceIn(-maxOffset, maxOffset)
                        panY = (panY + dragAmount.y).coerceIn(-maxOffset, maxOffset)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            if (bitmap != null) {
                val imageBitmap = remember(bitmap) { bitmap.asImageBitmap() }
                Image(
                    bitmap = imageBitmap,
                    contentDescription = "Magnified optical view of $fallbackTitle",
                    contentScale = ContentScale.Fit,
                    colorFilter = colorFilter,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = zoom
                            scaleY = zoom
                            translationX = panX
                            translationY = panY
                        }
                )
            } else {
                // Optical simulation sheet when camera bitmap is not yet captured
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .graphicsLayer {
                            scaleX = zoom.coerceIn(1f, 2.5f)
                            scaleY = zoom.coerceIn(1f, 2.5f)
                            translationX = panX
                            translationY = panY
                        }
                        .background(
                            if (contrastMode == MagnificationContrastMode.INVERTED_LOW_VISION) Color.Black else Color(0xFFF7F4EB),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(14.dp)
                ) {
                    val inkColor = if (contrastMode == MagnificationContrastMode.INVERTED_LOW_VISION) Color.White else Color(0xFF1A1A1A)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = fallbackTitle,
                            color = inkColor,
                            fontSize = 15.ssp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = fallbackRawText,
                            color = inkColor,
                            fontSize = 12.ssp,
                            lineHeight = 16.ssp
                        )
                    }
                }
            }

            // Corner HUD Indicator inside Loupe
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .background(Color(0xCC0D1310), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isFrozen) "STABILIZED SNAPSHOT" else "LIVE OPTICAL LOUPE",
                    color = OstOpticalPalette.InteractiveGreen,
                    fontSize = 10.ssp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "• ${String.format(Locale.US, "%.1fx", zoom)}",
                    color = OstOpticalPalette.HighContrastWhite,
                    fontSize = 10.ssp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (panX != 0f || panY != 0f) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                ) {
                    Button(onClick = { panX = 0f; panY = 0f }) {
                        Text(text = "Center View", fontSize = 10.ssp)
                    }
                }
            }
        }

        // 2. Optical Zoom Controls Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { onStepZoom(-0.5f) }) {
                    Text(text = "-", fontSize = 13.ssp, fontWeight = FontWeight.Bold)
                }
                listOf(2.0f, 3.0f, 4.5f).forEach { preset ->
                    val isSelected = kotlin.math.abs(zoom - preset) < 0.2f
                    Button(onClick = { onSetZoom(preset) }) {
                        Text(
                            text = "${preset}x",
                            fontSize = 11.ssp,
                            color = if (isSelected) OstOpticalPalette.InteractiveGreen else OstOpticalPalette.HighContrastWhite,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Button(onClick = { onStepZoom(0.5f) }) {
                    Text(text = "+", fontSize = 13.ssp, fontWeight = FontWeight.Bold)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = onToggleFrozen) {
                    Text(
                        text = if (isFrozen) "Live View" else "Freeze",
                        fontSize = 11.ssp,
                        color = OstOpticalPalette.InteractiveGreen
                    )
                }
                Button(onClick = onRecapture) {
                    Text(text = "Recapture", fontSize = 11.ssp)
                }
            }
        }

        // 3. Low-Vision Contrast Filter Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MagnificationContrastMode.values().forEach { mode ->
                val isSelected = mode == contrastMode
                Button(
                    onClick = { onSetContrast(mode) },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = mode.label,
                        fontSize = 11.ssp,
                        color = if (isSelected) OstOpticalPalette.InteractiveGreen else OstOpticalPalette.HighContrastWhite,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

// ============================================================================
// 5. Accessibility Settings Sheet (Scrollable, Tremor Wizard, Sizing, Voice)
// ============================================================================

@Composable
private fun GlassesSettingsSheet(
    viewModel: ARReadingLensViewModel,
    textSizePref: TextSizePreference,
    tremorProfile: TremorProfile,
    assistantVoice: AssistantVoice,
    isWebcamPreviewVisible: Boolean,
    isHandOverlayVisible: Boolean,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val typography = LocalSpatialAngularTypography.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xB3000000))
            .pointerInput(Unit) {
                detectTapGestures { onClose() }
            },
        contentAlignment = Alignment.Center
    ) {
        Card(
            onClick = {},
            modifier = modifier
                .widthIn(max = 580.dp)
                .fillMaxHeight(0.92f)
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header (Fixed)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Settings & Accessibility",
                        style = typography.titleStyle,
                        color = OstOpticalPalette.HighContrastWhite
                    )

                    Button(onClick = onClose) {
                        Text(text = "Done", fontSize = 14.ssp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // 1. Hand Tremor Assistance Section
                    Text(
                        text = "HAND TREMOR ASSISTANCE & TRACKING",
                        style = typography.captionStyle,
                        color = OstOpticalPalette.InteractiveGreen,
                        fontWeight = FontWeight.Bold
                    )

                    SettingToggleRow(
                        title = "Tremor Assistance Filter",
                        description = "Filters involuntary hand jitter (4-8 Hz), debounce refractory window (380ms), and expands hitboxes.",
                        isActive = tremorProfile.isTremorAssistanceEnabled,
                        onToggle = { viewModel.toggleTremorAssistance(!tremorProfile.isTremorAssistanceEnabled) }
                    )

                    SettingToggleRow(
                        title = "Show Grip Guidance",
                        description = if (tremorProfile.isTremorAssistanceEnabled) {
                            "Shows ergonomic holding techniques on scanned objects to stabilize hands."
                        } else {
                            "Requires Tremor Assistance to be enabled."
                        },
                        isActive = tremorProfile.isTremorAssistanceEnabled && tremorProfile.isShowGripEnabled,
                        isEnabled = tremorProfile.isTremorAssistanceEnabled,
                        onToggle = { viewModel.toggleShowGrip(!tremorProfile.isShowGripEnabled) }
                    )

                    SettingToggleRow(
                        title = "Show Live Hand Tracking Reticle",
                        description = "Displays the webcam optical hand tracker and tremor stabilization vector on screen.",
                        isActive = isHandOverlayVisible,
                        onToggle = { viewModel.toggleHandOverlay() }
                    )

                    // Calibration Wizard Action Card
                    Card(
                        onClick = { viewModel.startTremorCalibrationWizard() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.5.dp, OstOpticalPalette.InteractiveGreen, RoundedCornerShape(16.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Hand Tremor Calibration Wizard",
                                    color = OstOpticalPalette.HighContrastWhite,
                                    fontSize = 15.ssp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Run the 5-step webcam test to tune rest jitter dampening, intentional tap velocity, and targeting cone.",
                                    color = OstOpticalPalette.SecondaryText,
                                    fontSize = 12.ssp,
                                    lineHeight = 16.ssp
                                )
                            }
                            Button(onClick = { viewModel.startTremorCalibrationWizard() }) {
                                Text(text = "Start ->", fontSize = 13.ssp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    // 2. Setup & Gesture Guide
                    Text(
                        text = "INSTRUCTIONS & GESTURES",
                        style = typography.captionStyle,
                        color = OstOpticalPalette.InteractiveGreen,
                        fontWeight = FontWeight.Bold
                    )

                    Button(
                        onClick = { viewModel.showSetupInstructions() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Text(text = "Review First-Time Setup & Gesture Guide", fontSize = 14.ssp)
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    // 3. Low-Vision Font Visual Angle Scaling
                    Text(
                        text = "LOW-VISION TYPOGRAPHY (VISUAL ANGLE)",
                        style = typography.captionStyle,
                        color = OstOpticalPalette.InteractiveGreen,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Current: ${String.format(Locale.US, "%.1f", textSizePref.bodyAngleDegrees)}° Visual Angle",
                            color = OstOpticalPalette.HighContrastWhite,
                            fontSize = 14.ssp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(onClick = { viewModel.stepTextSizeDown() }) {
                                Text(text = "- A", fontSize = 14.ssp)
                            }
                            Button(onClick = { viewModel.stepTextSizeUp() }) {
                                Text(text = "+ A", fontSize = 14.ssp)
                            }
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = { viewModel.updateTextSizeDegrees(1.0f) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = "1.0° Std", fontSize = 12.ssp)
                        }
                        Button(
                            onClick = { viewModel.updateTextSizeDegrees(1.5f) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = "1.5° Large", fontSize = 12.ssp)
                        }
                        Button(
                            onClick = { viewModel.updateTextSizeDegrees(2.2f) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = "2.2° XL", fontSize = 12.ssp)
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    // 4. Voice Options
                    Text(
                        text = "GEMINI LIVE ASSISTANT VOICE",
                        style = typography.captionStyle,
                        color = OstOpticalPalette.InteractiveGreen,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        AssistantVoice.values().forEach { voice ->
                            val isSelected = voice == assistantVoice
                            Button(
                                onClick = { viewModel.setAssistantVoice(voice) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = if (isSelected) "[Active] ${voice.label}" else voice.label,
                                    fontSize = 11.ssp,
                                    color = if (isSelected) OstOpticalPalette.InteractiveGreen else OstOpticalPalette.HighContrastWhite
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    // 5. Camera & Display
                    Text(
                        text = "CAMERA & ENVIRONMENT DISPLAY",
                        style = typography.captionStyle,
                        color = OstOpticalPalette.InteractiveGreen,
                        fontWeight = FontWeight.Bold
                    )

                    SettingToggleRow(
                        title = "Live Webcam Feed",
                        description = "Displays live webcam frames directly behind AR HUD. Turn off for 100% transparent Optical See-Through.",
                        isActive = isWebcamPreviewVisible,
                        onToggle = { viewModel.toggleWebcamPreview() }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Footer (Fixed)
                Button(
                    onClick = onClose,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Save & Close Settings",
                        fontSize = 15.ssp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    description: String,
    isActive: Boolean,
    isEnabled: Boolean = true,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                color = if (isEnabled) OstOpticalPalette.HighContrastWhite else OstOpticalPalette.SecondaryText,
                fontSize = 14.ssp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = description,
                color = OstOpticalPalette.SecondaryText,
                fontSize = 12.ssp,
                lineHeight = 16.ssp
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Button(
            onClick = { if (isEnabled) onToggle() }
        ) {
            Text(
                text = if (!isEnabled) "DISABLED" else if (isActive) "ON" else "OFF",
                color = if (isActive && isEnabled) OstOpticalPalette.InteractiveGreen else OstOpticalPalette.SecondaryText,
                fontWeight = FontWeight.Bold,
                fontSize = 13.ssp
            )
        }
    }
}

// ============================================================================
// 6. Calibration Wizard (with Live Webcam Hand Telemetry & Exit Button)
// ============================================================================

@Composable
private fun GlassesCalibrationWizard(
    step: CalibrationStep,
    handTelemetry: HandTrackingTelemetry,
    onAdvance: () -> Unit,
    onStepUp: () -> Unit,
    onStepDown: () -> Unit,
    onExit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val typography = LocalSpatialAngularTypography.current

    Card(
        onClick = {},
        modifier = modifier.widthIn(max = 520.dp)
    ) {
        Column(
            modifier = Modifier.padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header with Live Webcam Hand Status & Exit
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TREMOR & VISION CALIBRATION",
                    style = typography.captionStyle,
                    color = OstOpticalPalette.InteractiveGreen,
                    fontWeight = FontWeight.Bold
                )

                Button(onClick = onExit) {
                    Text(text = "Exit", fontSize = 12.ssp)
                }
            }

            // Live Webcam Hand Telemetry Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x229FD8A8), RoundedCornerShape(10.dp))
                    .border(1.dp, OstOpticalPalette.InteractiveGreenDim, RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Webcam Hand Tracker: ACTIVE",
                    color = OstOpticalPalette.InteractiveGreen,
                    fontSize = 12.ssp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Jitter: ${String.format(Locale.US, "%.1f mm", handTelemetry.jitterMm)}  |  Speed: ${String.format(Locale.US, "%.2f m/s", handTelemetry.velocityMps)}",
                    color = OstOpticalPalette.HighContrastWhite,
                    fontSize = 12.ssp
                )
            }

            when (step) {
                is CalibrationStep.TextSize -> {
                    Text(
                        text = "Text size",
                        style = typography.titleStyle,
                        color = OstOpticalPalette.HighContrastWhite
                    )
                    Text(
                        text = "Adjust the visual angle (${String.format(Locale.US, "%.1f", step.currentSize.bodyAngleDegrees)}°) until you can read effortlessly without squinting.",
                        style = typography.bodyStyle,
                        color = OstOpticalPalette.SecondaryText,
                        textAlign = TextAlign.Center
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(onClick = onStepDown) { Text(text = "Smaller (-)") }
                        Button(onClick = onStepUp) { Text(text = "Larger (+)") }
                    }
                    Button(onClick = onAdvance, modifier = Modifier.fillMaxWidth()) {
                        Text(text = "Continue ->")
                    }
                }

                is CalibrationStep.RestMeasurement -> {
                    Text(
                        text = "Step 1 of 3: Hold your hand still",
                        style = typography.titleStyle,
                        color = OstOpticalPalette.HighContrastWhite
                    )
                    Text(
                        text = "Hold your hand in front of the webcam for 5 seconds. Measuring resting oscillation (${String.format(Locale.US, "%.1f mm", handTelemetry.jitterMm)})...",
                        style = typography.bodyStyle,
                        color = OstOpticalPalette.SecondaryText,
                        textAlign = TextAlign.Center
                    )
                    Button(onClick = onAdvance, modifier = Modifier.fillMaxWidth()) {
                        Text(text = "Lock Rest Jitter (${String.format(Locale.US, "%.1f mm", handTelemetry.jitterMm)}) ->")
                    }
                }

                is CalibrationStep.TapMeasurement -> {
                    Text(
                        text = "Step 2 of 3: Tap test",
                        style = typography.titleStyle,
                        color = OstOpticalPalette.HighContrastWhite
                    )
                    Text(
                        text = "Tap downward in front of your webcam or click below (${step.tapsCompleted}/${step.totalTapsRequired} taps recorded).",
                        style = typography.bodyStyle,
                        color = OstOpticalPalette.SecondaryText,
                        textAlign = TextAlign.Center
                    )
                    Button(onClick = onAdvance, modifier = Modifier.fillMaxWidth()) {
                        Text(text = "Record Tap (${step.tapsCompleted + 1}/${step.totalTapsRequired})")
                    }
                }

                is CalibrationStep.AimMeasurement -> {
                    Text(
                        text = "Step 3 of 3: Aim test",
                        style = typography.titleStyle,
                        color = OstOpticalPalette.HighContrastWhite
                    )
                    Text(
                        text = "Move your hand toward the highlighted reticle to verify aim cone (${step.targetsHit}/${step.totalTargets}).",
                        style = typography.bodyStyle,
                        color = OstOpticalPalette.SecondaryText,
                        textAlign = TextAlign.Center
                    )
                    Button(onClick = onAdvance, modifier = Modifier.fillMaxWidth()) {
                        Text(text = "Confirm Target Hit (${step.targetsHit + 1}/${step.totalTargets})")
                    }
                }

                is CalibrationStep.Completed -> {
                    Text(
                        text = "Calibration Complete",
                        style = typography.titleStyle,
                        color = OstOpticalPalette.InteractiveGreen
                    )
                    Text(
                        text = "Tremor filter calibrated from webcam telemetry. Tap strike threshold: ${step.profile.tapVelocityThresholdMps} m/s | Refractory debounce: ${step.profile.refractoryWindowMs} ms",
                        style = typography.bodyStyle,
                        color = OstOpticalPalette.HighContrastWhite,
                        textAlign = TextAlign.Center
                    )
                    Button(onClick = onAdvance, modifier = Modifier.fillMaxWidth()) {
                        Text(text = "Continue ->")
                    }
                }
            }
        }
    }
}


// ============================================================================
// 0. First-run profile: name, age, tremor assistance
// ============================================================================

@Composable
private fun GlassesOnboardingCard(
    step: OnboardingStep,
    initialName: String,
    initialAge: Int?,
    onName: (String) -> Unit,
    onAge: (Int?) -> Unit,
    onTremor: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val typography = LocalSpatialAngularTypography.current
    var name by remember { mutableStateOf(initialName) }
    var age by remember { mutableStateOf(initialAge ?: 65) }
    val stepNumber = when (step) {
        OnboardingStep.Name -> 1
        OnboardingStep.Age -> 2
        OnboardingStep.Tremor -> 3
    }

    Card(
        onClick = {},
        modifier = modifier.widthIn(max = 540.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "SETUP · $stepNumber OF 5",
                style = typography.captionStyle,
                color = OstOpticalPalette.InteractiveGreen,
                fontWeight = FontWeight.Bold
            )
            when (step) {
                OnboardingStep.Name -> {
                    Text(text = "What should I call you?", style = typography.titleStyle, color = OstOpticalPalette.HighContrastWhite)
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it.take(40) },
                        singleLine = true,
                        textStyle = typography.bodyStyle,
                        placeholder = { Text(text = "Your first name", color = OstOpticalPalette.SecondaryText) },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { onName(name) }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = OstOpticalPalette.HighContrastWhite,
                            unfocusedTextColor = OstOpticalPalette.HighContrastWhite,
                            focusedBorderColor = OstOpticalPalette.InteractiveGreen,
                            unfocusedBorderColor = OstOpticalPalette.InteractiveGreenDim,
                            cursorColor = OstOpticalPalette.InteractiveGreen
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(onClick = { onName(name) }, modifier = Modifier.fillMaxWidth()) {
                        Text(text = "Continue ->", style = typography.bodyStyle)
                    }
                }

                OnboardingStep.Age -> {
                    Text(text = "How old are you?", style = typography.titleStyle, color = OstOpticalPalette.HighContrastWhite)
                    Text(
                        text = "This only sets a comfortable starting text size.",
                        style = typography.bodyStyle,
                        color = OstOpticalPalette.SecondaryText
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        Button(onClick = { age = (age - 1).coerceAtLeast(18) }) {
                            Text(text = "-", style = typography.titleStyle)
                        }
                        Text(text = age.toString(), style = typography.titleStyle, color = OstOpticalPalette.HighContrastWhite)
                        Button(onClick = { age = (age + 1).coerceAtMost(110) }) {
                            Text(text = "+", style = typography.titleStyle)
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(onClick = { onAge(age) }, modifier = Modifier.weight(1f)) {
                            Text(text = "Continue ->", style = typography.bodyStyle)
                        }
                        Button(onClick = { onAge(null) }, modifier = Modifier.weight(1f)) {
                            Text(text = "Skip", style = typography.bodyStyle)
                        }
                    }
                }

                OnboardingStep.Tremor -> {
                    Text(text = "Turn on tremor assistance?", style = typography.titleStyle, color = OstOpticalPalette.HighContrastWhite)
                    Text(
                        text = "If your hands shake, the lens ignores accidental extra taps and can show you a steadier way to hold things. Next, it measures your hand.",
                        style = typography.bodyStyle,
                        color = OstOpticalPalette.SecondaryText
                    )
                    Button(onClick = { onTremor(true) }, modifier = Modifier.fillMaxWidth()) {
                        Text(text = "Yes, turn it on", style = typography.bodyStyle, color = OstOpticalPalette.InteractiveGreen)
                    }
                    Button(onClick = { onTremor(false) }, modifier = Modifier.fillMaxWidth()) {
                        Text(text = "No, not now", style = typography.bodyStyle)
                    }
                }
            }
        }
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
