﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.ui

/**
 * Visual angle preference for scalable typography (§3.5).
 * Sized in degrees subtended at nominal viewing distance (e.g. 0.55m).
 * Titles, key fields, and buttons scale proportionally from this value.
  * Developed by Praneetha Kamabathula.
 */
data class TextSizePreference(
    val bodyAngleDegrees: Float = 0.85f // Nominal: 0.85° (range: 0.8° to 4.0°)
) {
    val titleAngleDegrees: Float get() = bodyAngleDegrees * 1.4f
    val keyFieldAngleDegrees: Float get() = bodyAngleDegrees * 2.3f
    val captionAngleDegrees: Float get() = bodyAngleDegrees * 0.78f

    fun stepUp(): TextSizePreference =
        copy(bodyAngleDegrees = (bodyAngleDegrees * 1.15f).coerceAtMost(4.0f))

    fun stepDown(): TextSizePreference =
        copy(bodyAngleDegrees = (bodyAngleDegrees / 1.15f).coerceAtLeast(0.75f))

    fun setDegrees(degrees: Float): TextSizePreference =
        copy(bodyAngleDegrees = degrees.coerceIn(0.75f, 4.0f))
}

/**
 * User-calibrated tremor profile (§3.1).
 */
data class TremorProfile(
    val isTremorAssistanceEnabled: Boolean = true,
    val isShowGripEnabled: Boolean = true,       // Toggleable in Tremor Settings
    val tremorAmplitudeMeters: Float = 0.035f,   // Measured peak-to-peak palm jitter
    val dominantFrequencyHz: Float = 5.5f,       // Typ: 4-8 Hz for essential tremor/Parkinson's
    val tapVelocityThresholdMps: Float = 0.35f,  // Minimum downward strike speed for deliberate tap
    val refractoryWindowMs: Long = 380L,         // Suppress secondary bounces/tremor strikes
    val zoneScaleMultiplier: Float = 1.35f,      // Oversizes hitboxes and buttons
    val aimConeDegrees: Float = 22.0f            // Directional tap selection cone width
)

/** First-run setup steps before calibration and text size. */
enum class OnboardingStep { Name, Age, Tremor }

/**
 * Assistant Voice tuning for senior acoustic comfort and clarity.
 */
enum class AssistantVoice(val label: String, val description: String) {
    WARM_CALM("Warm & Calm", "Gentle, calm pacing for low-stress reading"),
    CLEAR_LOUD("Clear & Loud", "Acoustically tuned for senior hearing"),
    CRISP_CONCISE("Crisp & Concise", "Fast, succinct bullet-point guidance"),
    MUTED("Muted (Text Only)", "No voice prompts, screen overlays only")
}

/**
 * Setup calibration steps (§3.1).
 */
sealed interface CalibrationStep {
    data class TextSize(val currentSize: TextSizePreference) : CalibrationStep
    data class RestMeasurement(val secondsRemaining: Int, val currentJitterMeters: Float) : CalibrationStep
    data class TapMeasurement(val tapsCompleted: Int, val totalTapsRequired: Int = 5) : CalibrationStep
    data class AimMeasurement(val targetsHit: Int, val totalTargets: Int = 4) : CalibrationStep
    data class Completed(val profile: TremorProfile) : CalibrationStep
}

/**
 * Actions available when an object is selected.
 */
enum class LensAction(val label: String, val icon: String) {
    MAGNIFY("Magnify", ""),
    SUMMARIZE("Summarize", ""),
    HOW_TO_HOLD("Show Grip", ""),
    TRANSLATE("Translate", ""),
    CLOSE("Close", ""),
    ASK("Ask Assistant", "")
}

/**
 * Verbatim chunked summary chip (§4.2).
 */
data class SummaryChip(
    val category: String,
    val icon: String,
    val verbatimValue: String,
    val isVerifiedVerbatim: Boolean = true
)

/**
 * Interactive AI response chip for follow-up conversational turns.
 */
data class AiResponseChip(
    val id: String,
    val icon: String,
    val label: String,
    val prompt: String
)

/**
 * Message in the conversational Gemini Live log.
 */
data class AiChatMessage(
    val isGemini: Boolean,
    val text: String,
    val timestampMs: Long = System.currentTimeMillis()
)

/**
 * Normalized 2D bounding box in [0.0 .. 1.0] camera frame coordinates.
 */
data class NormalizedRect(
    val left: Float = 0.20f,
    val top: Float = 0.20f,
    val right: Float = 0.80f,
    val bottom: Float = 0.80f
) {
    val width: Float get() = (right - left).coerceAtLeast(0.04f)
    val height: Float get() = (bottom - top).coerceAtLeast(0.04f)
    val centerX: Float get() = (left + right) * 0.5f
    val centerY: Float get() = (top + bottom) * 0.5f
}

/**
 * 3D Hand Joint coordinates in normalized camera view space ([0..1], z in relative depth).
 */
data class HandJoint(
    val x: Float,
    val y: Float,
    val z: Float = 0f
)

/**
 * Live hand and tremor tracking telemetry from Google MediaPipe AI / optical flow / pointer / XR hand tracking.
 */
data class HandTrackingTelemetry(
    val isHandDetected: Boolean = false,
    val normalizedX: Float = 0.5f,
    val normalizedY: Float = 0.5f,
    val smoothedX: Float = 0.5f,
    val smoothedY: Float = 0.5f,
    val velocityMps: Float = 0.0f,
    val jitterMm: Float = 0.0f,
    val isStabilized: Boolean = true,
    val lastStrikeTimestampMs: Long = 0L,
    val trackingSource: String = "Google MediaPipe AI Hands",
    val landmarks: List<HandJoint> = emptyList(),
    val isPinching: Boolean = false,
    val twoHandDistance: Float? = null
)

/**
 * Contrast modes for optical image magnification (low-vision enhancement).
 */
enum class MagnificationContrastMode(val label: String) {
    NATURAL("Natural"),
    HIGH_CONTRAST("High Contrast"),
    INVERTED_LOW_VISION("Inverted B&W")
}

/**
 * Targeted physical object currently highlighted in the user's view.
 */
data class ScannedObjectTarget(
    val id: String,
    val title: String,
    val category: String,
    val rawText: String,
    val grip: GripRecommendation? = null,
    val boundingBox: NormalizedRect = NormalizedRect(0.18f, 0.18f, 0.82f, 0.82f),
    val textBlockBoxes: List<NormalizedRect> = emptyList(),
    val confidence: Float = 0.96f,
    val capturedBitmap: android.graphics.Bitmap? = null,
    val fullFrameBitmap: android.graphics.Bitmap? = null
)

/**
 * Diagnostic reasons why an object/text cannot be clearly read (§4.5).
 */
enum class ReadProblem(val headline: String, val detail: String) {
    TOO_FAR("Bring Object Closer", "Text is too small to resolve. Move it 10-15 cm closer to your glasses."),
    BLURRY_SHAKING("Rest on Surface", "Shaking is blurring the small print. Rest your elbow or place the item on a table."),
    TOO_DARK("Move to Light", "Lighting is too dim. Face toward a window or lamp."),
    GLARE("Tilt Away from Light", "Reflections are washing out the label. Tilt the item slightly away from overhead glare."),
    WRAPPED_LABEL("Turn Slowly", "The label wraps around the container. Slowly rotate the bottle so we can scan all sides."),
    FACING_AWAY("Turn Label Forward", "An object is in view, but the text is facing away. Rotate the label toward you."),
    PARTIAL_READ("Partial Label Captured", "Some fields are missing. Hold steady while we capture the rest."),
    UNKNOWN_OBJECT("Unidentified Object", "I can't tell what this is yet. No previous data exists for this item.")
}

/**
 * Options presented to the user during guidance (§4.5).
 */
data class GuidanceOption(
    val title: String,
    val actionType: ActionType
) {
    enum class ActionType {
        RETRY_SCAN,
        READ_VISIBLE_TEXT_ANYWAY,
        DESCRIBE_TO_ASSISTANT,
        ASK_ONLINE_CLOUD,
        SET_ON_TABLE,
        CANCEL
    }
}

/**
 * Recommended ergonomic grip taking user's tremor profile into account (§4.3).
 */
data class GripRecommendation(
    val title: String,
    val description: String,
    val isTwoHanded: Boolean,
    val braceElbow: Boolean,
    val visualHandPoseHint: String
)

/**
 * Core Lens State Machine implementing the AI Glasses interaction model:
 * 1. SetupInstructions: First launch guide with gestures.
 * 2. Browsing: Idle, unobstructed view; single-tap shows peripheral Settings button.
 * 3. ObjectTargeted: Double-tap highlights object and anchors side action bubble.
 * 4. PanelExpanded: Expands panel next to object with result + AI response chips underneath.
 */
sealed interface LensState {
    /** 1. First setup + instructions card */
    data object SetupInstructions : LensState

    /** 0. First-run profile: name, age, tremor assistance choice */
    data class Onboarding(val step: OnboardingStep) : LensState

    /** 2. Idle browsing: Real world unobstructed. Single-tap shows peripheral settings */
    data class Browsing(
        val isTremorAssistanceActive: Boolean = true,
        val detectedObjectsInView: List<String> = emptyList(),
        val isPeripheralSettingsVisible: Boolean = false
    ) : LensState

    /** 3. Object Targeted: Object highlighted with green outline, side bubble shows actions */
    data class ObjectTargeted(
        val target: ScannedObjectTarget,
        val availableActions: List<LensAction>
    ) : LensState

    /** 4. Expanded Panel: Result next to object + AI response chips under it */
    data class PanelExpanded(
        val target: ScannedObjectTarget,
        val selectedAction: LensAction,
        val resultTitle: String,
        val resultDetails: List<String>,
        val aiChips: List<AiResponseChip>,
        val conversationLog: List<AiChatMessage> = emptyList(),
        val isAiThinking: Boolean = false
    ) : LensState

    /** 5. Calibration Wizard */
    data class Calibrating(val step: CalibrationStep) : LensState

    // ========================================================================
    // Legacy / Convenience States preserved for backward compatibility
    // ========================================================================
    data class ObjectSelected(
        val objectId: String,
        val label: String,
        val isConfirmed: Boolean = false
    ) : LensState

    data class ActionMenu(
        val objectId: String,
        val actions: List<LensAction>
    ) : LensState

    data class Magnified(
        val keyText: String,
        val subText: String = "",
        val confidence: Float = 0.95f
    ) : LensState

    data class SummaryChips(
        val title: String,
        val chips: List<SummaryChip>,
        val rawOcrText: String
    ) : LensState

    data class ChipDetail(
        val chip: SummaryChip,
        val parentTitle: String
    ) : LensState

    data class GripGuidance(
        val objectType: String,
        val grip: GripRecommendation
    ) : LensState

    data class Guidance(
        val problem: ReadProblem,
        val instruction: String,
        val options: List<GuidanceOption>,
        val attemptCount: Int = 1
    ) : LensState
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
