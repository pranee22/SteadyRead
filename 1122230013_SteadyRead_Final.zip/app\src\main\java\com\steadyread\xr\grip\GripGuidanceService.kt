﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.grip

import com.steadyread.xr.ui.GripRecommendation
import com.steadyread.xr.ui.TremorProfile

/**
 * Service providing occupational-therapy-informed ergonomic grip recommendations
 * tailored to reduce mechanical tremor propagation (§4.3) across diverse everyday objects
 * (postcards, mail, books, food packages, bottles, mugs, and documents).
  * Developed by Praneetha Kamabathula.
 */
class GripGuidanceService {

    /**
     * Resolves the most stable grip for a detected object type and user tremor severity.
     */
    fun getStableGripForObject(
        objectType: String,
        tremorProfile: TremorProfile
    ): GripRecommendation {
        val isSevereTremor = tremorProfile.tremorAmplitudeMeters > 0.04f

        return when (objectType.uppercase()) {
            "POSTCARD_MAIL", "POSTCARD", "CARD", "LETTER", "ENVELOPE" -> {
                GripRecommendation(
                    title = "Tabletop Edge-Braced Card Grip",
                    description = "Rest the bottom edge of the postcard or letter directly against a flat table surface. Hold the side margins gently between your thumbs and index fingers with both forearms resting on the table to eliminate hand shake.",
                    isTwoHanded = true,
                    braceElbow = true,
                    visualHandPoseHint = "BILATERAL_CORNER_PINCH_ON_TABLE"
                )
            }

            "RECEIPT_BILL", "PAPER_DOCUMENT", "PRESCRIPTION_SLIP", "DOCUMENT_PRINT" -> {
                GripRecommendation(
                    title = "Tabletop Flattening Grip",
                    description = "Lay the document or receipt completely flat on the tabletop. Rest the heel of your non-dominant palm on the top margin to anchor it in place while scanning.",
                    isTwoHanded = false,
                    braceElbow = true,
                    visualHandPoseHint = "FLAT_SURFACE_PALM_ANCHOR"
                )
            }

            "FOOD_GROCERY", "BOX", "CARTON", "PACKAGE" -> {
                GripRecommendation(
                    title = "Two-Handed Side-Wall Clamp",
                    description = "Set the base of the package on the counter and press both flat palms against the left and right sides. Keep elbows planted on the counter surface.",
                    isTwoHanded = true,
                    braceElbow = true,
                    visualHandPoseHint = "BILATERAL_SIDE_WALL_CLAMP"
                )
            }

            "PILL_BOTTLE", "BOTTLE", "VIAL", "MEDICATION" -> {
                if (isSevereTremor) {
                    GripRecommendation(
                        title = "Two-Handed Palm Clamp",
                        description = "Enclose the cylinder with both palms resting flat against the sides. Keep your elbows firmly planted on the table to mechanically cancel tremors.",
                        isTwoHanded = true,
                        braceElbow = true,
                        visualHandPoseHint = "TWO_HAND_CYLINDER_CLAMP"
                    )
                } else {
                    GripRecommendation(
                        title = "Whole-Palm Wrap Grip",
                        description = "Wrap your entire palm and four fingers fully around the middle of the cylinder. Avoid holding with just your fingertips.",
                        isTwoHanded = false,
                        braceElbow = true,
                        visualHandPoseHint = "WHOLE_PALM_WRAP"
                    )
                }
            }

            "MUG", "CUP", "GLASS" -> {
                GripRecommendation(
                    title = "Base-Cradling Grip",
                    description = "Cradle the lower base with one palm while wrapping your other hand around the side. Avoid using a single-finger handle pinch.",
                    isTwoHanded = true,
                    braceElbow = true,
                    visualHandPoseHint = "BASE_CRADLE_WRAP"
                )
            }

            else -> {
                GripRecommendation(
                    title = "Braced Bilateral Support Grip",
                    description = "Support the item with both hands using broad palm contact rather than fingertips, and rest your forearms or elbows against a table or armrest.",
                    isTwoHanded = true,
                    braceElbow = true,
                    visualHandPoseHint = "BILATERAL_TABLE_BRACED_SUPPORT"
                )
            }
        }
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
