﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.summary

import com.steadyread.xr.ui.SummaryChip
import java.util.Locale

/**
 * Universal Intelligent Summarizer Service (§4.2).
 *
 * Reads real-time data from WHATEVER object is pointed at (medication, food packaging,
 * electronics, mail, receipts, appliances, menus, or documents) and extracts structured,
 * digestible summary chips without relying on any fixed dataset.
 *
 * Safety & Accuracy Invariants:
 * 1. Every chip value is extracted directly from the live OCR text.
 * 2. All numbers, dates, units, and warnings are verified verbatim against the source.
 * 3. Chunks reduce cognitive load so elderly users never have to parse a wall of small print.
  * Developed by Praneetha Kamabathula.
 */
class LabelSummarizerService {

    data class ScannedSummary(
        val dynamicTitle: String,
        val chips: List<SummaryChip>,
        val fullText: String
    )

    /**
     * Dynamically parses live OCR text from any pointed object into structured summary chips.
     */
    fun summarizeObject(rawOcrText: String): ScannedSummary {
        val cleanLines = rawOcrText
            .lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }

        if (cleanLines.isEmpty()) {
            return ScannedSummary(
                dynamicTitle = "Unidentified Object",
                chips = listOf(
                    SummaryChip(
                        category = "Status",
                        icon = "",
                        verbatimValue = "No readable text detected. Ensure good lighting and point directly at the label.",
                        isVerifiedVerbatim = true
                    )
                ),
                fullText = ""
            )
        }

        // 1. Dynamic Title Extraction: The most prominent headline on the pointed object
        val dynamicTitle = extractProminentTitle(cleanLines)

        // 2. Multi-Category Content Analysis
        val uppercaseFull = rawOcrText.uppercase(Locale.ROOT)
        val chips = mutableListOf<SummaryChip>()

        // Category A: Warnings, Cautions, Allergens, or Hazards
        val warningChunks = extractWarningsAndAllergens(cleanLines)
        for (warning in warningChunks) {
            chips.add(
                SummaryChip(
                    category = "Warnings & Cautions",
                    icon = "",
                    verbatimValue = warning,
                    isVerifiedVerbatim = isVerbatimSubset(warning, uppercaseFull)
                )
            )
        }

        // Category B: Primary Instructions, Directions, or How to Use
        val instructionChunks = extractInstructionsAndUsage(cleanLines)
        for (instruction in instructionChunks) {
            chips.add(
                SummaryChip(
                    category = "Instructions & Directions",
                    icon = "",
                    verbatimValue = instruction,
                    isVerifiedVerbatim = isVerbatimSubset(instruction, uppercaseFull)
                )
            )
        }

        // Category C: Measurements, Specifications, Dosage, or Quantities
        val measurementChunks = extractMeasurementsAndSpecs(cleanLines)
        for (measurement in measurementChunks) {
            chips.add(
                SummaryChip(
                    category = "Specifications & Amounts",
                    icon = "",
                    verbatimValue = measurement,
                    isVerifiedVerbatim = isVerbatimSubset(measurement, uppercaseFull)
                )
            )
        }

        // Category D: Dates, Expiry, or Timestamps
        val dateChunks = extractDatesAndExpiry(cleanLines)
        for (date in dateChunks) {
            chips.add(
                SummaryChip(
                    category = "Dates & Validity",
                    icon = "",
                    verbatimValue = date,
                    isVerifiedVerbatim = isVerbatimSubset(date, uppercaseFull)
                )
            )
        }

        // Category E: Greetings, Sender, or Recipient (Postcards, Letters, Mail)
        val correspondenceChunks = extractCorrespondenceLines(cleanLines)
        for (line in correspondenceChunks) {
            chips.add(
                SummaryChip(
                    category = "Greeting & Sender",
                    icon = "",
                    verbatimValue = line,
                    isVerifiedVerbatim = isVerbatimSubset(line, uppercaseFull)
                )
            )
        }

        // Category F: Key Information / Message Body (Any remaining unclassified distinct lines)
        val classifiedTexts = chips.map { it.verbatimValue.uppercase(Locale.ROOT) }.toSet()
        val remainingHighlights = cleanLines
            .filter { line ->
                val upper = line.uppercase(Locale.ROOT)
                upper != dynamicTitle.uppercase(Locale.ROOT) &&
                    classifiedTexts.none { classified -> classified.contains(upper) || upper.contains(classified) }
            }
            .take(5)

        for (highlight in remainingHighlights) {
            chips.add(
                SummaryChip(
                    category = "Message / Detail",
                    icon = "",
                    verbatimValue = highlight,
                    isVerifiedVerbatim = isVerbatimSubset(highlight, uppercaseFull)
                )
            )
        }

        // Fallback: If no specific categories were discovered, chunk the text lines into digestible cards
        if (chips.isEmpty()) {
            cleanLines.chunked(2).take(4).forEachIndexed { index, chunkLines ->
                val combined = chunkLines.joinToString(" • ")
                chips.add(
                    SummaryChip(
                        category = "Section ${index + 1}",
                        icon = "",
                        verbatimValue = combined,
                        isVerifiedVerbatim = true
                    )
                )
            }
        }

        return ScannedSummary(
            dynamicTitle = dynamicTitle,
            chips = chips,
            fullText = rawOcrText
        )
    }

    /**
     * Determines the primary object title from the most prominent line of text.
     */
    private fun extractProminentTitle(lines: List<String>): String {
        // Prefer lines that look like brand names, product titles, or headlines (longer, capitalized)
        val candidate = lines.firstOrNull { line ->
            line.length in 4..60 && !line.startsWith("EXP", ignoreCase = true) && !line.startsWith("BATCH", ignoreCase = true)
        } ?: lines.first()

        return candidate.take(50)
    }

    private fun extractWarningsAndAllergens(lines: List<String>): List<String> {
        val warningKeywords = listOf(
            "WARNING", "CAUTION", "DANGER", "DO NOT", "AVOID", "MAY CAUSE",
            "ALLERGEN", "CONTAINS", "KEEP OUT", "POISON", "FOR EXTERNAL USE",
            "SIDE EFFECTS", "PRECAUTION", "HAZARD", "FLAMMABLE"
        )
        return lines.filter { line ->
            val upper = line.uppercase(Locale.ROOT)
            warningKeywords.any { upper.contains(it) }
        }.distinct().take(3)
    }

    private fun extractInstructionsAndUsage(lines: List<String>): List<String> {
        val instructionKeywords = listOf(
            "TAKE", "APPLY", "USE", "DIRECTIONS", "HOW TO", "INSTRUCTIONS",
            "SERVE", "PREPARE", "COOK", "CONNECT", "PRESS", "SHAKE WELL",
            "STORE AT", "KEEP REFRIGERATED", "ONCE DAILY", "TWICE DAILY", "WITH FOOD", "WITH MEALS"
        )
        return lines.filter { line ->
            val upper = line.uppercase(Locale.ROOT)
            instructionKeywords.any { upper.contains(it) }
        }.distinct().take(3)
    }

    private fun extractMeasurementsAndSpecs(lines: List<String>): List<String> {
        val specRegex = Regex(
            """(?:\b\d+(?:\.\d+)?\s*(?:MG|ML|G|KG|OZ|LBS|CAL|KCAL|V|VOLTS|W|WATTS|HZ|TABLET|CAPSULE|PILL|QTY|COUNT|FL\s*OZ)\b|\$\s*\d+(?:\.\d{2})?)""",
            RegexOption.IGNORE_CASE
        )
        return lines.filter { line ->
            specRegex.containsMatchIn(line) && !line.startsWith("EXP", ignoreCase = true)
        }.distinct().take(3)
    }

    private fun extractDatesAndExpiry(lines: List<String>): List<String> {
        val dateRegex = Regex(
            """(?:EXP|BEST\s+BY|USE\s+BY|MFG|DATE|VALID\s+THRU|EXPIRES)?[\s\.:]*(?:\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}|\d{1,2}[/\-\.]\d{2,4}|\b(?:JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[A-Z]*\s+\d{1,4}(?:,?\s*\d{4})?)""",
            RegexOption.IGNORE_CASE
        )
        return lines.filter { line ->
            dateRegex.containsMatchIn(line)
        }.distinct().take(2)
    }

    private fun extractCorrespondenceLines(lines: List<String>): List<String> {
        val markers = listOf(
            "DEAR ", "FROM:", "TO:", "LOVE,", "SINCERELY", "WARM REGARDS",
            "BEST WISHES", "GREETINGS FROM", "YOURS TRULY", "SENT BY"
        )
        return lines.filter { line ->
            val upper = line.uppercase(Locale.ROOT)
            markers.any { upper.contains(it) }
        }.distinct().take(3)
    }

    /**
     * Verifies that every word in the chip exists in the original OCR text.
     */
    private fun isVerbatimSubset(chunk: String, sourceText: String): Boolean {
        val cleanChunkWords = chunk.split(Regex("""[\s,;]+""")).map { it.trim().uppercase(Locale.ROOT) }
        val sourceWordSet = sourceText.split(Regex("""[\s,;]+""")).map { it.trim().uppercase(Locale.ROOT) }.toSet()
        return cleanChunkWords.all { word ->
            word.length <= 1 || sourceWordSet.any { source -> source.contains(word) || word.contains(source) }
        }
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
