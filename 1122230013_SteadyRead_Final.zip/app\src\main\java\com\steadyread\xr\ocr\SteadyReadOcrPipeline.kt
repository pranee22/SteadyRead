﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Rect
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.steadyread.xr.interaction.MediaPipeHandTracker
import com.steadyread.xr.spatial.SpatialGroundingManager
import com.steadyread.xr.ui.HandTrackingTelemetry
import com.steadyread.xr.ui.NormalizedRect
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Structured key field extracted for the "Primary Read" viewport.
  * Developed by Praneetha Kamabathula.
 */
data class MagnifiedKeyField(
    val title: String,
    val body: String
)

/**
 * Rich live frame analysis result combining OCR text, spatial bounding boxes,
 * and high-resolution optical bitmaps for real image magnification.
 */
data class LiveScanFrameResult(
    val rawText: String,
    val unionBoundingBox: NormalizedRect,
    val textBlockBoxes: List<NormalizedRect>,
    val confidence: Float,
    val croppedObjectBitmap: Bitmap?,
    val fullFrameBitmap: Bitmap?
)

/**
 * Module 2: The Core Optical & OCR Pipeline
 *
 * 1. Captures upright camera frames for true optical magnification (so users see the actual
 *    magnified image of a postcard, document, or label to verify summary accuracy).
 * 2. Computes precise normalized bounding boxes around detected objects and text lines.
 * 3. Runs real-time webcam optical hand & tremor tracking (motion + skin-tone centroid,
 *    velocity in m/s, jitter in mm, and low-pass tremor stabilization).
 */
class SteadyReadOcrPipeline(
    private val spatialGroundingManager: SpatialGroundingManager,
    private val useV1SamplePayload: Boolean = false,
    var onLiveTextScannedListener: ((String) -> Unit)? = null,
    var onLiveFrameProcessedListener: ((LiveScanFrameResult) -> Unit)? = null,
    var onHandTrackingUpdatedListener: ((HandTrackingTelemetry) -> Unit)? = null
) : ImageAnalysis.Analyzer {

    companion object {
        const val V1_PRIMARY_READ_SAMPLE =
            "TAKE 1 TABLET (25 MG) BY MOUTH EVERY 12 HOURS WITH FOOD. DO NOT CRUSH OR CHEW."

        val V1_KEY_FIELDS = listOf(
            MagnifiedKeyField(
                title = "DOSAGE INSTRUCTIONS (1/3)",
                body = V1_PRIMARY_READ_SAMPLE
            ),
            MagnifiedKeyField(
                title = "MEDICATION & STRENGTH (2/3)",
                body = "PROPRANOLOL ER 25 MG — EXTENDED-RELEASE CAPSULES (QTY: 60)"
            ),
            MagnifiedKeyField(
                title = "SAFETY & EXPIRATION (3/3)",
                body = "EXP: 11/2027 • MAY CAUSE DIZZINESS. AVOID ALCOHOL WHILE TAKING."
            )
        )
    }

    private val recognizer: TextRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val _activeFieldIndex = MutableStateFlow(0)
    val activeFieldIndex: StateFlow<Int> = _activeFieldIndex.asStateFlow()

    private val _primaryReadPayload = MutableStateFlow(V1_PRIMARY_READ_SAMPLE)
    val primaryReadPayload: StateFlow<String> = _primaryReadPayload.asStateFlow()

    private val _primaryReadTitle = MutableStateFlow(V1_KEY_FIELDS.first().title)
    val primaryReadTitle: StateFlow<String> = _primaryReadTitle.asStateFlow()

    // Google MediaPipe AI Hand Tracker & Fallback Webcam Optical Tracker state
    private var mediaPipeTracker: MediaPipeHandTracker? = null

    fun initMediaPipeTracker(context: Context) {
        if (mediaPipeTracker == null) {
            try {
                mediaPipeTracker = MediaPipeHandTracker(context.applicationContext)
            } catch (_: Throwable) {}
        }
    }

    private val gridCols = 32
    private val gridRows = 24
    private var prevLumaGrid: IntArray? = null
    private var prevFrameTimeMs: Long = 0L
    private var smoothedHandX: Float = 0.5f
    private var smoothedHandY: Float = 0.5f
    private var prevRawHandX: Float = 0.5f
    private var prevRawHandY: Float = 0.5f
    private val recentJitterSamplesMm = ArrayDeque<Float>(16)
    private var lastStrikeTimeMs: Long = 0L

    fun activatePrimaryReadFromLock() {
        if (!spatialGroundingManager.isOcrAllowed) return
        val index = _activeFieldIndex.value.coerceIn(V1_KEY_FIELDS.indices)
        val field = V1_KEY_FIELDS[index]
        _primaryReadTitle.value = field.title
        _primaryReadPayload.value = field.body

        spatialGroundingManager.transitionToPrimaryRead(
            activeFieldIndex = index,
            totalFields = V1_KEY_FIELDS.size,
            keyFieldTitle = field.title,
            magnifiedPayload = field.body
        )
    }

    fun nextKeyField() {
        if (!spatialGroundingManager.isOcrAllowed) return
        val nextIndex = (_activeFieldIndex.value + 1) % V1_KEY_FIELDS.size
        _activeFieldIndex.value = nextIndex
        activatePrimaryReadFromLock()
    }

    fun previousKeyField() {
        if (!spatialGroundingManager.isOcrAllowed) return
        val prevIndex = (_activeFieldIndex.value - 1 + V1_KEY_FIELDS.size) % V1_KEY_FIELDS.size
        _activeFieldIndex.value = prevIndex
        activatePrimaryReadFromLock()
    }

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val rotationDegrees = imageProxy.imageInfo.rotationDegrees
        val uprightBitmap = try {
            val rawBitmap = imageProxy.toBitmap()
            if (rotationDegrees != 0) {
                val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
                Bitmap.createBitmap(rawBitmap, 0, 0, rawBitmap.width, rawBitmap.height, matrix, true)
            } else {
                rawBitmap
            }
        } catch (_: Throwable) {
            null
        }

        // 1. Run real-time Google MediaPipe AI Hand Tracker (or Fallback Optical Tracker)
        if (uprightBitmap != null) {
            val handTelemetry = mediaPipeTracker?.processFrame(uprightBitmap)
                ?: trackHandAndMotionFromBitmap(uprightBitmap)
            onHandTrackingUpdatedListener?.invoke(handTelemetry)
        }

        // 2. Run ML Kit Text Recognition & Spatial Bounding Box Extraction
        val inputImage = InputImage.fromMediaImage(mediaImage, rotationDegrees)

        recognizer.process(inputImage)
            .addOnSuccessListener { visionText: Text ->
                val fullText = visionText.text.trim()
                val frameW = (uprightBitmap?.width ?: imageProxy.width).coerceAtLeast(1)
                val frameH = (uprightBitmap?.height ?: imageProxy.height).coerceAtLeast(1)

                val blockBoxes = mutableListOf<NormalizedRect>()
                var minLeft = 1.0f
                var minTop = 1.0f
                var maxRight = 0.0f
                var maxBottom = 0.0f

                for (block in visionText.textBlocks) {
                    val rect = block.boundingBox ?: continue
                    val norm = NormalizedRect(
                        left = (rect.left.toFloat() / frameW).coerceIn(0f, 1f),
                        top = (rect.top.toFloat() / frameH).coerceIn(0f, 1f),
                        right = (rect.right.toFloat() / frameW).coerceIn(0f, 1f),
                        bottom = (rect.bottom.toFloat() / frameH).coerceIn(0f, 1f)
                    )
                    blockBoxes.add(norm)
                    minLeft = min(minLeft, norm.left)
                    minTop = min(minTop, norm.top)
                    maxRight = max(maxRight, norm.right)
                    maxBottom = max(maxBottom, norm.bottom)
                }

                // Pad union bounding box by 8% so the full physical object / postcard is framed
                val unionBox = if (blockBoxes.isNotEmpty()) {
                    NormalizedRect(
                        left = (minLeft - 0.08f).coerceIn(0.04f, 0.90f),
                        top = (minTop - 0.08f).coerceIn(0.04f, 0.90f),
                        right = (maxRight + 0.08f).coerceIn(0.10f, 0.96f),
                        bottom = (maxBottom + 0.08f).coerceIn(0.10f, 0.96f)
                    )
                } else {
                    NormalizedRect(0.16f, 0.16f, 0.84f, 0.84f)
                }

                val croppedBitmap = if (uprightBitmap != null) {
                    cropNormalizedRegion(uprightBitmap, unionBox)
                } else {
                    null
                }

                if (fullText.isNotBlank()) {
                    _primaryReadTitle.value = "LIVE CAMERA OCR"
                    _primaryReadPayload.value = fullText
                    onLiveTextScannedListener?.invoke(fullText)
                }

                onLiveFrameProcessedListener?.invoke(
                    LiveScanFrameResult(
                        rawText = fullText,
                        unionBoundingBox = unionBox,
                        textBlockBoxes = blockBoxes,
                        confidence = if (blockBoxes.isNotEmpty()) 0.96f else 0.75f,
                        croppedObjectBitmap = croppedBitmap ?: uprightBitmap,
                        fullFrameBitmap = uprightBitmap
                    )
                )
            }
            .addOnCompleteListener {
                imageProxy.close()
            }
    }

    /**
     * Crops a high-resolution sub-region of [source] corresponding to [normRect].
     */
    private fun cropNormalizedRegion(source: Bitmap, normRect: NormalizedRect): Bitmap {
        return try {
            val x = (normRect.left * source.width).toInt().coerceIn(0, max(0, source.width - 2))
            val y = (normRect.top * source.height).toInt().coerceIn(0, max(0, source.height - 2))
            val w = (normRect.width * source.width).toInt().coerceIn(1, source.width - x)
            val h = (normRect.height * source.height).toInt().coerceIn(1, source.height - y)
            Bitmap.createBitmap(source, x, y, w, h)
        } catch (_: Throwable) {
            source
        }
    }

    /**
     * Lightweight real-time webcam hand & motion tracker.
     * Detects moving hand/skin regions in front of the webcam, measures velocity (m/s)
     * and tremor jitter (mm), and applies low-pass tremor stabilization.
     */
    private fun trackHandAndMotionFromBitmap(bitmap: Bitmap): HandTrackingTelemetry {
        val nowMs = System.currentTimeMillis()
        val dtSec = if (prevFrameTimeMs > 0L) {
            ((nowMs - prevFrameTimeMs).coerceIn(16L, 500L)) / 1000f
        } else {
            0.033f
        }
        prevFrameTimeMs = nowMs

        val currentLuma = IntArray(gridCols * gridRows)
        val prevLuma = prevLumaGrid

        var weightedSumX = 0f
        var weightedSumY = 0f
        var totalWeight = 0f
        var motionCells = 0

        val w = bitmap.width
        val h = bitmap.height

        for (gy in 0 until gridRows) {
            val py = ((gy + 0.5f) * h / gridRows).toInt().coerceIn(0, h - 1)
            for (gx in 0 until gridCols) {
                val px = ((gx + 0.5f) * w / gridCols).toInt().coerceIn(0, w - 1)
                val pixel = bitmap.getPixel(px, py)
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val luma = (r * 77 + g * 150 + b * 29) shr 8

                val idx = gy * gridCols + gx
                currentLuma[idx] = luma

                val motionDelta = if (prevLuma != null) abs(luma - prevLuma[idx]) else 0
                val isSkinTone = (r > 85 && g > 40 && b > 20 && r > g && (r - b) > 15)

                if (motionDelta > 10 || isSkinTone) {
                    val weight = (motionDelta * 1.6f) + (if (isSkinTone) 14f else 0f)
                    if (motionDelta > 12) motionCells++
                    weightedSumX += (gx.toFloat() / (gridCols - 1)) * weight
                    weightedSumY += (gy.toFloat() / (gridRows - 1)) * weight
                    totalWeight += weight
                }
            }
        }

        prevLumaGrid = currentLuma

        val isHandActive = totalWeight > 60f || motionCells >= 2
        val rawX = if (totalWeight > 1f) (weightedSumX / totalWeight).coerceIn(0.05f, 0.95f) else prevRawHandX
        val rawY = if (totalWeight > 1f) (weightedSumY / totalWeight).coerceIn(0.05f, 0.95f) else prevRawHandY

        // Compute displacement in normalized screen units & convert to physical meters (~0.45m plane)
        val dx = rawX - prevRawHandX
        val dy = rawY - prevRawHandY
        val distNorm = sqrt(dx * dx + dy * dy)
        val distMeters = distNorm * 0.45f
        val velocityMps = (distMeters / dtSec).coerceIn(0f, 3.5f)

        prevRawHandX = rawX
        prevRawHandY = rawY

        // Low-pass tremor filter (smooths 4-8 Hz hand jitter while preserving deliberate movement)
        val alpha = if (velocityMps > 0.32f) 0.55f else 0.18f
        smoothedHandX += alpha * (rawX - smoothedHandX)
        smoothedHandY += alpha * (rawY - smoothedHandY)

        // Instantaneous tremor residual (distance between raw hand position and stabilized cursor in mm)
        val residualNorm = sqrt(
            (rawX - smoothedHandX) * (rawX - smoothedHandX) +
                (rawY - smoothedHandY) * (rawY - smoothedHandY)
        )
        val instantJitterMm = (residualNorm * 450f).coerceIn(0.4f, 45.0f)
        if (recentJitterSamplesMm.size >= 12) recentJitterSamplesMm.removeFirst()
        recentJitterSamplesMm.addLast(instantJitterMm)
        val avgJitterMm = recentJitterSamplesMm.average().toFloat()

        // Detect deliberate downward tap strike (> 0.35 m/s with 380ms refractory debounce)
        if (dy > 0.025f && velocityMps >= 0.35f && (nowMs - lastStrikeTimeMs) > 380L) {
            lastStrikeTimeMs = nowMs
        }

        return HandTrackingTelemetry(
            isHandDetected = isHandActive,
            normalizedX = rawX,
            normalizedY = rawY,
            smoothedX = smoothedHandX,
            smoothedY = smoothedHandY,
            velocityMps = velocityMps,
            jitterMm = avgJitterMm,
            isStabilized = true,
            lastStrikeTimestampMs = lastStrikeTimeMs,
            trackingSource = "Webcam Live Optical Tracker"
        )
    }

    fun close() {
        recognizer.close()
        mediaPipeTracker?.close()
        mediaPipeTracker = null
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
