﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.gemini

import com.steadyread.xr.ui.AiResponseChip
import com.steadyread.xr.ui.AssistantVoice
import com.steadyread.xr.ui.LensAction
import kotlinx.coroutines.delay
import java.util.Locale

/**
 * Context-aware multimodal assistant and question chip generator for SteadyRead XR.
 *
 * Dynamically adapts to whatever physical item the user scans (postcards, letters, mail,
 * receipts, books, food packaging, electronics, or medication) and grounds all answers
 * and suggested questions directly in the scanned OCR text.
  * Developed by Praneetha Kamabathula.
 */
class GeminiLiveAssistantService {

    /**
     * Infers the semantic category of the scanned object from its headline and full OCR text.
     */
    fun detectObjectCategory(objectTitle: String, ocrContext: String): String {
        val combined = "$objectTitle\n$ocrContext".uppercase(Locale.ROOT)

        val hasMedKeywords = listOf(
            "TABLET", "CAPSULE", "DOSAGE", "BY MOUTH", "RX", "PHARMACY", "PHARMACIST",
            "REFILL", "MG ", "MCG", "EVERY 8 HOURS", "EVERY 12 HOURS", "AMOXICILLIN",
            "PROPRANOLOL", "METFORMIN", "LISINOPRIL"
        ).any { combined.contains(it) }

        val hasPostcardOrMailKeywords = listOf(
            "POSTCARD", "GREETINGS", "DEAR ", "LOVE,", "SINCERELY", "WARM REGARDS",
            "BEST WISHES", "WISH YOU WERE HERE", "MISS YOU", "HELLO FROM", "STAMP",
            "POSTMARK", "TO:", "FROM:", "CARD", "LETTER", "INVITATION", "THANK YOU"
        ).any { combined.contains(it) }

        val hasReceiptKeywords = listOf(
            "SUBTOTAL", "TOTAL", "INVOICE", "RECEIPT", "AMOUNT DUE", "BALANCE DUE",
            "TAX", "PAYMENT", "VISA", "MASTERCARD", "ACCOUNT"
        ).any { combined.contains(it) }

        val hasFoodKeywords = listOf(
            "NUTRITION", "CALORIES", "INGREDIENTS", "ALLERGEN", "SERVING", "PROTEIN",
            "REFRIGERATE", "BEST BY", "CONTAINS ALMONDS", "PEANUTS", "MILK", "CEREAL", "OAT"
        ).any { combined.contains(it) }

        val hasHardwareKeywords = listOf(
            "ROUTER", "WI-FI", "GIGABIT", "12V", "24W", "ETHERNET", "ENCLOSURE",
            "SERIAL", "MODEL", "VOLTAGE", "HAZARD"
        ).any { combined.contains(it) }

        return when {
            hasPostcardOrMailKeywords -> "POSTCARD_MAIL"
            hasMedKeywords -> "MEDICATION"
            hasReceiptKeywords -> "RECEIPT_BILL"
            hasFoodKeywords -> "FOOD_GROCERY"
            hasHardwareKeywords -> "ELECTRONICS_HARDWARE"
            else -> "POSTCARD_OR_DOCUMENT"
        }
    }

    /**
     * Contextual question answering about the currently pointed/scanned object.
     * Grounds answers in the actual [ocrContext] captured from the camera.
     */
    suspend fun queryGemini(
        objectTitle: String,
        ocrContext: String,
        userPrompt: String,
        voice: AssistantVoice,
        image: android.graphics.Bitmap? = null
    ): Pair<String, List<AiResponseChip>> {
        if (GeminiClient.isConfigured) {
            val chipCategory = detectObjectCategory(objectTitle, ocrContext)
            val prompt = buildString {
                append("The user is looking at: ").append(objectTitle).append("\n")
                if (ocrContext.isNotBlank()) {
                    append("Text read from it by on-device OCR (may contain errors):\n").append(ocrContext).append("\n")
                }
                if (image != null) append("A photo of it is attached. Trust the photo over the OCR text.\n")
                append("\nUser request: ").append(userPrompt)
            }
            val result = runCatching { GeminiClient.generate(prompt, image) }
            val answer = result.getOrNull()
            if (answer != null) {
                val chips = buildFollowUpChips(chipCategory, objectTitle, ocrContext, excludeTopic = "")
                return answer to chips
            }
        }
        delay(220L)

        val cleanPrompt = userPrompt.lowercase(Locale.ROOT).trim()
        val category = detectObjectCategory(objectTitle, ocrContext)
        val lines = ocrContext.lines().map { it.trim() }.filter { it.isNotBlank() }
        val verbatimPreview = if (lines.isNotEmpty()) {
            lines.joinToString(" | ")
        } else {
            objectTitle
        }

        val (responseBody, followUpChips) = when {
            // 1. Read Aloud / Speak Full Text
            cleanPrompt.contains("read aloud") ||
                cleanPrompt.contains("full text") ||
                cleanPrompt.contains("start to finish") ||
                cleanPrompt.contains("speak") ||
                cleanPrompt.contains("read this") -> {
                val spokenLines = if (lines.isNotEmpty()) {
                    lines.joinToString("\n• ", prefix = "• ")
                } else {
                    objectTitle
                }
                val answer = "Reading full text from $objectTitle:\n$spokenLines"
                val chips = buildFollowUpChips(category, objectTitle, ocrContext, excludeTopic = "read_aloud")
                answer to chips
            }

            // 2. Main Message / What does it say / Summarize
            cleanPrompt.contains("main message") ||
                cleanPrompt.contains("what does it say") ||
                cleanPrompt.contains("what is written") ||
                cleanPrompt.contains("summarize") ||
                cleanPrompt.contains("summary") ||
                cleanPrompt.contains("about") -> {
                val answer = if (lines.size > 1) {
                    val keyBody = lines.take(5).joinToString(" ")
                    "Summary of $objectTitle ($category): The text reads: \"$keyBody\"."
                } else {
                    "Summary of $objectTitle: \"$verbatimPreview\". Point closer or open Magnify to inspect fine print details."
                }
                val chips = buildFollowUpChips(category, objectTitle, ocrContext, excludeTopic = "message")
                answer to chips
            }

            // 3. Sender / Recipient / Who / Names / Places / Address (Great for Postcards & Mail!)
            cleanPrompt.contains("who") ||
                cleanPrompt.contains("sender") ||
                cleanPrompt.contains("sent") ||
                cleanPrompt.contains("from") ||
                cleanPrompt.contains("name") ||
                cleanPrompt.contains("place") ||
                cleanPrompt.contains("where") ||
                cleanPrompt.contains("address") ||
                cleanPrompt.contains("location") -> {
                val greetingOrSignoff = lines.filter { line ->
                    val u = line.uppercase(Locale.ROOT)
                    u.startsWith("DEAR") || u.startsWith("FROM") || u.startsWith("TO") ||
                        u.contains("LOVE") || u.contains("GREETINGS") || u.contains("SINCERELY") ||
                        u.contains("ST") || u.contains("AVE") || line.any { it.isDigit() }
                }
                val extracted = if (greetingOrSignoff.isNotEmpty()) {
                    greetingOrSignoff.joinToString(" • ")
                } else {
                    lines.take(3).joinToString(" • ").ifBlank { objectTitle }
                }
                val answer = "Names, sender, and location details found on $objectTitle:\n\"$extracted\""
                val chips = buildFollowUpChips(category, objectTitle, ocrContext, excludeTopic = "who_where")
                answer to chips
            }

            // 4. Dates / Numbers / Prices / Totals / Expiration
            cleanPrompt.contains("date") ||
                cleanPrompt.contains("number") ||
                cleanPrompt.contains("total") ||
                cleanPrompt.contains("amount") ||
                cleanPrompt.contains("price") ||
                cleanPrompt.contains("when") ||
                cleanPrompt.contains("expir") -> {
                val numericLines = lines.filter { line -> line.any { it.isDigit() } }
                val answer = if (numericLines.isNotEmpty()) {
                    "Dates and numbers detected on $objectTitle:\n• " + numericLines.joinToString("\n• ")
                } else {
                    "No specific numeric dates or figures were detected in the current scan of $objectTitle. Current text: \"$verbatimPreview\"."
                }
                val chips = buildFollowUpChips(category, objectTitle, ocrContext, excludeTopic = "dates_numbers")
                answer to chips
            }

            // 5. Translation (Spanish / English)
            cleanPrompt.contains("translate") ||
                cleanPrompt.contains("español") ||
                cleanPrompt.contains("spanish") -> {
                val sourceText = lines.joinToString(" ").ifBlank { objectTitle }
                val answer = "Spanish Translation ($objectTitle):\n\"$sourceText\"\n" +
                    "(Traducción contextual del texto escaneado: ${translateCommonPhrasesToSpanish(sourceText)})"
                val chips = listOf(
                    AiResponseChip("q_read_aloud", "", "Can you read the original text aloud?", "Read the full text aloud from start to finish."),
                    AiResponseChip("q_message", "", "What is the main message written on this?", "What is the main message written on this?"),
                    AiResponseChip("q_who", "", "Are any names, dates, or places mentioned?", "Who sent this and are any names or places mentioned?")
                )
                answer to chips
            }

            // 6. Holding / Grip / Glare / Tremor Stabilization
            cleanPrompt.contains("grip") ||
                cleanPrompt.contains("hold") ||
                cleanPrompt.contains("steady") ||
                cleanPrompt.contains("shake") ||
                cleanPrompt.contains("glare") ||
                cleanPrompt.contains("table") -> {
                val answer = when (category) {
                    "POSTCARD_MAIL", "POSTCARD_OR_DOCUMENT", "RECEIPT_BILL" ->
                        "To hold $objectTitle steadily without hand tremor blur:\n" +
                            "1. Rest the bottom edge of the card or paper directly on a flat table.\n" +
                            "2. Plant both forearms or elbows on the table surface.\n" +
                            "3. Tilt the top edge forward about 15 degrees to eliminate overhead light glare."
                    else ->
                        "To stabilize $objectTitle:\n" +
                            "1. Rest both elbows firmly on a table surface.\n" +
                            "2. Use a broad whole-palm grip rather than pinching with fingertips."
                }
                val chips = buildFollowUpChips(category, objectTitle, ocrContext, excludeTopic = "grip")
                answer to chips
            }

            // 7. Medication-specific queries (when the scanned item is medication or user asks about dose/warnings)
            cleanPrompt.contains("missed") || cleanPrompt.contains("miss") || cleanPrompt.contains("dose") -> {
                val answer = if (category == "MEDICATION") {
                    "Dosage context for $objectTitle: Based on the scanned label (\"$verbatimPreview\"), take as directed. If a dose is missed, skip it if it is nearly time for your next scheduled dose."
                } else {
                    "Note: $objectTitle appears to be a ${category.lowercase().replace('_', ' ')}, not a medication bottle. The scanned text reads: \"$verbatimPreview\"."
                }
                val chips = buildFollowUpChips(category, objectTitle, ocrContext, excludeTopic = "dose")
                answer to chips
            }

            cleanPrompt.contains("warning") || cleanPrompt.contains("caution") || cleanPrompt.contains("allergen") || cleanPrompt.contains("side effect") -> {
                val warningLines = lines.filter { line ->
                    val u = line.uppercase(Locale.ROOT)
                    u.contains("WARNING") || u.contains("CAUTION") || u.contains("CONTAINS") ||
                        u.contains("ALLERGEN") || u.contains("DO NOT") || u.contains("AVOID") || u.contains("KEEP")
                }
                val answer = if (warningLines.isNotEmpty()) {
                    "Important notices found on $objectTitle:\n• " + warningLines.joinToString("\n• ")
                } else {
                    "No explicit warning or hazard notices were found on $objectTitle. Scanned text: \"$verbatimPreview\"."
                }
                val chips = buildFollowUpChips(category, objectTitle, ocrContext, excludeTopic = "warnings")
                answer to chips
            }

            // 8. Any Free-Form Custom Question from the User
            else -> {
                val keywords = cleanPrompt
                    .split(" ", "?", ",", ".")
                    .map { it.trim() }
                    .filter { it.length >= 3 && it !in setOf("what", "where", "when", "how", "can", "you", "the", "this", "that", "for", "and", "are", "there") }

                val matchingLines = if (keywords.isNotEmpty()) {
                    lines.filter { line ->
                        val lowerLine = line.lowercase(Locale.ROOT)
                        keywords.any { kw -> lowerLine.contains(kw) }
                    }
                } else {
                    emptyList()
                }

                val answer = if (matchingLines.isNotEmpty()) {
                    "Based on the scanned text on $objectTitle, here is the relevant detail:\n\"${matchingLines.joinToString(" • ")}\""
                } else if (lines.isNotEmpty()) {
                    "Here is what is written on $objectTitle (${category.lowercase().replace('_', ' ')}):\n\"${lines.joinToString(" • ")}\""
                } else {
                    "Currently viewing $objectTitle. Open Magnify to inspect the live optical image closely, or hold the item steady in front of the camera to capture more text."
                }
                val chips = buildFollowUpChips(category, objectTitle, ocrContext, excludeTopic = "")
                answer to chips
            }
        }

        val formattedVoiceNote = when (voice) {
            AssistantVoice.CLEAR_LOUD -> "[Clear Voice] $responseBody"
            AssistantVoice.WARM_CALM -> "[Calm Voice] $responseBody"
            AssistantVoice.CRISP_CONCISE -> "[Concise] $responseBody"
            AssistantVoice.MUTED -> responseBody
        }

        return formattedVoiceNote to followUpChips
    }

    /**
     * Generates context-appropriate initial question chips based on the actual scanned object
     * category (Postcard, Mail, Document, Receipt, Food, Hardware, or Medication).
     */
    fun getInitialChipsForAction(
        objectTitle: String,
        action: LensAction,
        ocrContext: String = ""
    ): List<AiResponseChip> {
        val category = detectObjectCategory(objectTitle, ocrContext)

        if (action == LensAction.HOW_TO_HOLD) {
            return when (category) {
                "POSTCARD_MAIL", "POSTCARD_OR_DOCUMENT", "RECEIPT_BILL" -> listOf(
                    AiResponseChip("q_hold_card", "", "What is the steadiest way to hold this card or paper?", "What is the steadiest way to hold this card or paper while reading?"),
                    AiResponseChip("q_glare", "", "How can I tilt this to avoid light glare?", "How can I avoid glare or shadows on this surface?"),
                    AiResponseChip("q_read_aloud", "", "Can you read the text aloud so I can rest my hands?", "Please read the full text aloud from start to finish.")
                )
                else -> listOf(
                    AiResponseChip("q_grip_steady", "", "How can I stabilize this item on a table?", "How can I hold this steadily using a table surface?"),
                    AiResponseChip("q_why_brace", "", "Why does bracing my elbows reduce hand tremor?", "Why does bracing elbows on a table reduce tremors?"),
                    AiResponseChip("q_read_aloud", "", "Can you read the text aloud clearly?", "Please read the full text aloud.")
                )
            }
        }

        return buildFollowUpChips(category, objectTitle, ocrContext, excludeTopic = "")
    }

    private fun buildFollowUpChips(
        category: String,
        objectTitle: String,
        ocrContext: String,
        excludeTopic: String
    ): List<AiResponseChip> {
        val pool = when (category) {
            "POSTCARD_MAIL", "POSTCARD_OR_DOCUMENT" -> listOf(
                "message" to AiResponseChip("q_main_msg", "", "What is the main message written on this?", "What is the main message written on this?"),
                "who_where" to AiResponseChip("q_sender", "", "Who sent this and are any names or places mentioned?", "Who sent this and are any names or places mentioned?"),
                "read_aloud" to AiResponseChip("q_read_aloud", "", "Can you read the full text aloud from start to finish?", "Can you read the full text aloud from start to finish?"),
                "dates_numbers" to AiResponseChip("q_dates", "", "Are there any dates, addresses, or numbers written here?", "Are there any dates, addresses, or numbers on this?"),
                "translate" to AiResponseChip("q_translate", "", "Can you translate this message into Spanish?", "Translate this text into Spanish.")
            )

            "RECEIPT_BILL" -> listOf(
                "dates_numbers" to AiResponseChip("q_total", "", "What is the total amount and date on this?", "What is the total amount and date on this?"),
                "message" to AiResponseChip("q_items", "", "Can you list all the items or lines shown?", "What is written on each line of this receipt or statement?"),
                "who_where" to AiResponseChip("q_vendor", "", "Which store, sender, or contact number is listed?", "Who is this from and is there a phone number or address?"),
                "read_aloud" to AiResponseChip("q_read_aloud", "", "Can you read the key numbers aloud clearly?", "Read the full text aloud clearly.")
            )

            "FOOD_GROCERY" -> listOf(
                "warnings" to AiResponseChip("q_allergens", "", "Are there any allergen warnings or dietary notices?", "What are the warnings or allergens on this item?"),
                "message" to AiResponseChip("q_directions", "", "What are the preparation or storage instructions?", "What is written in the instructions on this package?"),
                "dates_numbers" to AiResponseChip("q_nutrition", "", "What are the nutrition numbers or expiration date?", "What dates or numbers are listed on this package?"),
                "translate" to AiResponseChip("q_translate", "", "Can you translate this label into Spanish?", "Translate this text into Spanish.")
            )

            "ELECTRONICS_HARDWARE" -> listOf(
                "dates_numbers" to AiResponseChip("q_specs", "", "What are the voltage, model, or serial numbers?", "What numbers and specifications are written on this?"),
                "warnings" to AiResponseChip("q_cautions", "", "Are there any safety cautions on this label?", "What warnings or cautions are listed?"),
                "message" to AiResponseChip("q_setup", "", "What are the connection or setup instructions?", "What is the main message and instructions written here?")
            )

            "MEDICATION" -> listOf(
                "message" to AiResponseChip("q_directions", "", "What are the exact dosage instructions on this label?", "What is written in the dosage instructions on this label?"),
                "dose" to AiResponseChip("q_missed", "", "What should I do if I miss a dose?", "What should I do if I miss a dose?"),
                "warnings" to AiResponseChip("q_warnings", "", "What warnings or side effects are listed on the bottle?", "What warnings or cautions are on this item?"),
                "dates_numbers" to AiResponseChip("q_expiry", "", "What is the expiration date and strength?", "What dates and numbers are on this label?"),
                "translate" to AiResponseChip("q_translate", "", "Can you translate these instructions into Spanish?", "Translate this text into Spanish.")
            )

            else -> listOf(
                "message" to AiResponseChip("q_main_msg", "", "What is the main message written on this?", "What is the main message written on this?"),
                "read_aloud" to AiResponseChip("q_read_aloud", "", "Can you read the full text aloud clearly?", "Read the full text aloud from start to finish."),
                "dates_numbers" to AiResponseChip("q_details", "", "Are there any dates, names, or numbers written here?", "What dates, names, or numbers are on this?"),
                "translate" to AiResponseChip("q_translate", "", "Can you translate this text into Spanish?", "Translate this text into Spanish.")
            )
        }

        return pool
            .filter { (topic, _) -> topic != excludeTopic }
            .map { it.second }
            .take(4)
    }

    private fun translateCommonPhrasesToSpanish(text: String): String {
        var result = text
        val replacements = listOf(
            "Greetings from" to "Saludos desde",
            "Dear" to "Querido/a",
            "Wish you were here" to "Ojalá estuvieras aquí",
            "Thank you" to "Gracias",
            "See you soon" to "Nos vemos pronto",
            "Love," to "Con cariño,",
            "Sincerely," to "Atentamente,",
            "Happy Birthday" to "Feliz Cumpleaños"
        )
        for ((en, es) in replacements) {
            result = result.replace(en, es, ignoreCase = true)
        }
        return result
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
