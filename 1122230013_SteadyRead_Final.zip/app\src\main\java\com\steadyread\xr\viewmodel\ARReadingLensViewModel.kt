﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.viewmodel

import android.graphics.Bitmap
import androidx.camera.core.Preview
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.steadyread.xr.gemini.GeminiClient
import com.steadyread.xr.gemini.GeminiLiveAssistantService
import com.steadyread.xr.grip.GripGuidanceService
import com.steadyread.xr.interaction.CalibratedTapFilter
import com.steadyread.xr.ocr.LiveScanFrameResult
import com.steadyread.xr.ocr.MultiFrameOcrStabilizer
import com.steadyread.xr.ocr.SteadyReadOcrPipeline
import com.steadyread.xr.spatial.SpatialGroundingManager
import com.steadyread.xr.spatial.Vec3Meters
import com.steadyread.xr.summary.LabelSummarizerService
import com.steadyread.xr.ui.AiChatMessage
import com.steadyread.xr.ui.AiResponseChip
import com.steadyread.xr.ui.AssistantVoice
import com.steadyread.xr.ui.CalibrationStep
import com.steadyread.xr.ui.GuidanceOption
import com.steadyread.xr.ui.HandTrackingTelemetry
import com.steadyread.xr.ui.LensAction
import com.steadyread.xr.ui.LensState
import com.steadyread.xr.ui.MagnificationContrastMode
import com.steadyread.xr.ui.NormalizedRect
import com.steadyread.xr.ui.OnboardingStep
import com.steadyread.xr.ui.ReadProblem
import com.steadyread.xr.ui.ScannedObjectTarget
import com.steadyread.xr.ui.SummaryChip
import com.steadyread.xr.ui.TextSizePreference
import com.steadyread.xr.ui.TremorProfile
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.sqrt

enum class AssistantMode {
    VOICE,
    TEXT,
    BOTH
}

enum class AiProcessingPreference {
    ON_DEVICE_ONLY,
    PREFER_ON_DEVICE,
    ALLOW_CLOUD
}

/**
 * Primary ViewModel driving SteadyRead XR's state machine, dynamic OCR ingestion,
 * Gemini Live AI response chips, and Optical See-Through (OST) AI Glasses HUD.
  * Developed by Praneetha Kamabathula.
 */
class ARReadingLensViewModel(
    val spatialGroundingManager: SpatialGroundingManager = SpatialGroundingManager(),
    startWithSetupInstructions: Boolean = false
) : ViewModel() {

    private val tapFilter = CalibratedTapFilter()
    private val ocrStabilizer = MultiFrameOcrStabilizer()
    private val gripService = GripGuidanceService()
    private val summarizerService = LabelSummarizerService()
    val geminiAssistant = GeminiLiveAssistantService()

    val ocrPipeline = SteadyReadOcrPipeline(
        spatialGroundingManager = spatialGroundingManager,
        useV1SamplePayload = false
    ).apply {
        onLiveTextScannedListener = { scannedText ->
            onLiveOcrTextScanned(scannedText)
        }
        onLiveFrameProcessedListener = { frameResult ->
            onLiveFrameProcessed(frameResult)
        }
        onHandTrackingUpdatedListener = { telemetry ->
            onHandTrackingUpdated(telemetry)
        }
    }

    // Sizing & Calibration Preferences (Affects typography across the entire app)
    private val _textSizePreference = MutableStateFlow(TextSizePreference())
    val textSizePreference: StateFlow<TextSizePreference> = _textSizePreference.asStateFlow()

    // Tremor profile with Tremor Assistance & Show Grip toggles
    private val _tremorProfile = MutableStateFlow(TremorProfile())
    val tremorProfile: StateFlow<TremorProfile> = _tremorProfile.asStateFlow()

    // Global Settings
    private val _assistantVoice = MutableStateFlow(AssistantVoice.CLEAR_LOUD)
    val assistantVoice: StateFlow<AssistantVoice> = _assistantVoice.asStateFlow()

    private val _assistantMode = MutableStateFlow(AssistantMode.BOTH)
    val assistantMode: StateFlow<AssistantMode> = _assistantMode.asStateFlow()

    private val _aiProcessing = MutableStateFlow(AiProcessingPreference.PREFER_ON_DEVICE)
    val aiProcessing: StateFlow<AiProcessingPreference> = _aiProcessing.asStateFlow()

    private val _isSettingsOpen = MutableStateFlow(false)
    val isSettingsOpen: StateFlow<Boolean> = _isSettingsOpen.asStateFlow()

    private val _isPeripheralSettingsVisible = MutableStateFlow(false)
    val isPeripheralSettingsVisible: StateFlow<Boolean> = _isPeripheralSettingsVisible.asStateFlow()

    // Camera live preview state
    private val _isWebcamPreviewVisible = MutableStateFlow(true)
    val isWebcamPreviewVisible: StateFlow<Boolean> = _isWebcamPreviewVisible.asStateFlow()

    private val _cameraSurfaceProvider = MutableStateFlow<Preview.SurfaceProvider?>(null)
    val cameraSurfaceProvider: StateFlow<Preview.SurfaceProvider?> = _cameraSurfaceProvider.asStateFlow()

    // Live Hand & Tremor Tracking Telemetry (Webcam Optical Flow + Pointer)
    private val _handTrackingTelemetry = MutableStateFlow(HandTrackingTelemetry())
    val handTrackingTelemetry: StateFlow<HandTrackingTelemetry> = _handTrackingTelemetry.asStateFlow()

    private val _isHandOverlayVisible = MutableStateFlow(true)
    val isHandOverlayVisible: StateFlow<Boolean> = _isHandOverlayVisible.asStateFlow()

    // Live Spatial Object Bounding Box & Optical Magnification State
    private val _liveDetectedBox = MutableStateFlow(NormalizedRect(0.20f, 0.20f, 0.80f, 0.80f))
    val liveDetectedBox: StateFlow<NormalizedRect> = _liveDetectedBox.asStateFlow()

    private val _liveTextBlockBoxes = MutableStateFlow<List<NormalizedRect>>(emptyList())
    val liveTextBlockBoxes: StateFlow<List<NormalizedRect>> = _liveTextBlockBoxes.asStateFlow()

    private val _liveCroppedBitmap = MutableStateFlow<Bitmap?>(null)
    val liveCroppedBitmap: StateFlow<Bitmap?> = _liveCroppedBitmap.asStateFlow()

    private val _liveFullFrameBitmap = MutableStateFlow<Bitmap?>(null)
    val liveFullFrameBitmap: StateFlow<Bitmap?> = _liveFullFrameBitmap.asStateFlow()

    private val _magnificationZoom = MutableStateFlow(2.5f)
    val magnificationZoom: StateFlow<Float> = _magnificationZoom.asStateFlow()

    private val _magnificationContrast = MutableStateFlow(MagnificationContrastMode.NATURAL)
    val magnificationContrast: StateFlow<MagnificationContrastMode> = _magnificationContrast.asStateFlow()

    private val _isMagnifierFrozen = MutableStateFlow(true)
    val isMagnifierFrozen: StateFlow<Boolean> = _isMagnifierFrozen.asStateFlow()

    // Voice conversation listening & TTS callbacks
    private val _isVoiceListening = MutableStateFlow(false)
    val isVoiceListening: StateFlow<Boolean> = _isVoiceListening.asStateFlow()

    var onSpeakTextListener: ((String, AssistantVoice) -> Unit)? = null
    var onStartSpeechListeningListener: (() -> Boolean)? = null

    private var hideSettingsJob: Job? = null
    private var lastHandledStrikeMs: Long = 0L
    private var prevPointerTimeMs: Long = 0L

    // Core State Machine
    private val _lensState = MutableStateFlow<LensState>(
        if (startWithSetupInstructions) {
            LensState.SetupInstructions
        } else {
            LensState.Browsing(
                isTremorAssistanceActive = true,
                detectedObjectsInView = emptyList()
            )
        }
    )
    val lensState: StateFlow<LensState> = _lensState.asStateFlow()

    // Dynamically scanned content from whatever object is currently pointed at
    private var activeObjectId: String = "pointed_object_1"
    private var activeHeadline: String = "Scanned Object"
    private var activeRawOcr: String = ""

    init {
        if (activeRawOcr.isBlank()) {
            activeHeadline = "Aim at any postcard, document, or label"
            activeRawOcr = "Point your camera at any postcard, mail, food item, or label and double-tap to inspect."
        }
    }

    // ========================================================================
    // Live Frame, Bounding Box, Bitmap & Hand Tracking Ingestion
    // ========================================================================

    fun onLiveFrameProcessed(frameResult: LiveScanFrameResult) {
        _liveFullFrameBitmap.value = frameResult.fullFrameBitmap ?: _liveFullFrameBitmap.value
        _liveCroppedBitmap.value = frameResult.croppedObjectBitmap ?: _liveCroppedBitmap.value

        // Smoothly interpolate bounding box to eliminate visual jitter
        val prev = _liveDetectedBox.value
        val next = frameResult.unionBoundingBox
        val lerp = 0.35f
        _liveDetectedBox.value = NormalizedRect(
            left = prev.left + lerp * (next.left - prev.left),
            top = prev.top + lerp * (next.top - prev.top),
            right = prev.right + lerp * (next.right - prev.right),
            bottom = prev.bottom + lerp * (next.bottom - prev.bottom)
        )
        _liveTextBlockBoxes.value = frameResult.textBlockBoxes
    }

    fun onHandTrackingUpdated(telemetry: HandTrackingTelemetry) {
        _handTrackingTelemetry.value = telemetry

        val currentState = _lensState.value

        // 1. Process downward air-tap strikes
        if (telemetry.lastStrikeTimestampMs > lastHandledStrikeMs && telemetry.lastStrikeTimestampMs > 0L) {
            lastHandledStrikeMs = telemetry.lastStrikeTimestampMs
            if (currentState is LensState.Calibrating) {
                if (currentState.step is CalibrationStep.TapMeasurement) {
                    advanceCalibrationStep()
                }
            } else if (currentState is LensState.Browsing || currentState is LensState.ObjectTargeted) {
                onSingleTap()
            }
        }

        // 2. Feed live webcam hand tracking into the Calibration Wizard if active
        if (currentState is LensState.Calibrating) {
            when (val step = currentState.step) {
                is CalibrationStep.RestMeasurement -> {
                    _lensState.value = LensState.Calibrating(
                        step.copy(currentJitterMeters = (telemetry.jitterMm / 1000f).coerceIn(0.002f, 0.085f))
                    )
                }
                else -> {}
            }
        }
    }

    /**
     * Allows mouse/touch movement on screen to also drive the hand/tremor tracker for testing.
     */
    fun onPointerMoved(normX: Float, normY: Float) {
        val nowMs = System.currentTimeMillis()
        val dtSec = if (prevPointerTimeMs > 0L) ((nowMs - prevPointerTimeMs).coerceIn(16L, 500L)) / 1000f else 0.033f
        prevPointerTimeMs = nowMs

        val prev = _handTrackingTelemetry.value
        val dx = normX - prev.normalizedX
        val dy = normY - prev.normalizedY
        val distMeters = sqrt(dx * dx + dy * dy) * 0.45f
        val velocityMps = (distMeters / dtSec).coerceIn(0f, 3.5f)

        val alpha = if (velocityMps > 0.35f) 0.55f else 0.20f
        val smoothX = prev.smoothedX + alpha * (normX - prev.smoothedX)
        val smoothY = prev.smoothedY + alpha * (normY - prev.smoothedY)
        val residualMm = (sqrt((normX - smoothX) * (normX - smoothX) + (normY - smoothY) * (normY - smoothY)) * 450f).coerceIn(0.8f, 42f)

        onHandTrackingUpdated(
            HandTrackingTelemetry(
                isHandDetected = true,
                normalizedX = normX.coerceIn(0.02f, 0.98f),
                normalizedY = normY.coerceIn(0.02f, 0.98f),
                smoothedX = smoothX.coerceIn(0.02f, 0.98f),
                smoothedY = smoothY.coerceIn(0.02f, 0.98f),
                velocityMps = velocityMps,
                jitterMm = residualMm,
                isStabilized = _tremorProfile.value.isTremorAssistanceEnabled,
                lastStrikeTimestampMs = prev.lastStrikeTimestampMs,
                trackingSource = "Interactive Hand & Pointer Tracker"
            )
        )
    }

    fun toggleHandOverlay() {
        _isHandOverlayVisible.value = !_isHandOverlayVisible.value
    }

    fun setMagnificationZoom(zoom: Float) {
        _magnificationZoom.value = zoom.coerceIn(1.5f, 6.0f)
    }

    fun stepMagnificationZoom(delta: Float) {
        _magnificationZoom.value = (_magnificationZoom.value + delta).coerceIn(1.5f, 6.0f)
    }

    fun setMagnificationContrast(mode: MagnificationContrastMode) {
        _magnificationContrast.value = mode
    }

    fun toggleMagnifierFrozen() {
        val nextFrozen = !_isMagnifierFrozen.value
        _isMagnifierFrozen.value = nextFrozen
        if (nextFrozen) {
            recaptureMagnifierSnapshot()
        }
    }

    fun recaptureMagnifierSnapshot() {
        val current = _lensState.value
        if (current is LensState.PanelExpanded) {
            val freshTarget = current.target.copy(
                capturedBitmap = _liveCroppedBitmap.value ?: _liveFullFrameBitmap.value ?: current.target.capturedBitmap,
                fullFrameBitmap = _liveFullFrameBitmap.value ?: current.target.fullFrameBitmap,
                boundingBox = _liveDetectedBox.value,
                textBlockBoxes = _liveTextBlockBoxes.value
            )
            _lensState.value = current.copy(target = freshTarget)
        }
    }

    fun onLiveOcrTextScanned(rawText: String, objectIdentifier: String = activeObjectId) {
        if (rawText.isBlank()) return

        activeObjectId = objectIdentifier
        activeRawOcr = rawText

        val summary = summarizerService.summarizeObject(rawText)
        activeHeadline = summary.dynamicTitle

        when (val state = _lensState.value) {
            is LensState.Magnified -> {
                val lines = rawText.lines().map { it.trim() }.filter { it.isNotBlank() }
                val stabilized = ocrStabilizer.ingestFrameText(lines, System.currentTimeMillis())
                _lensState.value = LensState.Magnified(
                    keyText = stabilized.consolidatedHeadline.ifBlank { activeHeadline },
                    subText = stabilized.fullConsolidatedText,
                    confidence = stabilized.confidence
                )
            }
            is LensState.SummaryChips -> {
                _lensState.value = LensState.SummaryChips(
                    title = summary.dynamicTitle,
                    chips = summary.chips,
                    rawOcrText = rawText
                )
            }
            is LensState.Browsing -> {
                _lensState.value = state.copy(
                    detectedObjectsInView = listOf(activeHeadline)
                )
            }
            else -> {}
        }
    }

    // ========================================================================
    // First Setup & Instructions Lifecycle
    // ========================================================================

    // ========================================================================
    // First-run setup: name -> age -> tremor (-> calibration) -> text size -> instructions
    // ========================================================================

    private val _userName = MutableStateFlow("")
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _userAge = MutableStateFlow<Int?>(null)
    val userAge: StateFlow<Int?> = _userAge.asStateFlow()

    private var isOnboarding = false
    private var restJitterMm = 0f
    private val calibrationTapTimes = mutableListOf<Long>()

    fun startOnboarding() {
        isOnboarding = true
        _isSettingsOpen.value = false
        _lensState.value = LensState.Onboarding(OnboardingStep.Name)
    }

    fun submitName(name: String) {
        _userName.value = name.trim().take(40)
        GeminiClient.userName = _userName.value
        _lensState.value = LensState.Onboarding(OnboardingStep.Age)
    }

    fun submitAge(age: Int?) {
        _userAge.value = age
        GeminiClient.userAge = age
        if (age != null) {
            val suggested = when {
                age >= 75 -> 1.0f
                else -> 0.85f
            }
            _textSizePreference.value = _textSizePreference.value.setDegrees(suggested)
        }
        _lensState.value = LensState.Onboarding(OnboardingStep.Tremor)
    }

    fun chooseTremorAssistance(enabled: Boolean) {
        toggleTremorAssistance(enabled)
        if (enabled) {
            toggleShowGrip(true)
            _lensState.value = LensState.Calibrating(
                CalibrationStep.RestMeasurement(secondsRemaining = 5, currentJitterMeters = _handTrackingTelemetry.value.jitterMm / 1000f)
            )
        } else {
            _lensState.value = LensState.Calibrating(CalibrationStep.TextSize(_textSizePreference.value))
        }
    }

    fun showSetupInstructions() {
        _isSettingsOpen.value = false
        _lensState.value = LensState.SetupInstructions
    }

    fun dismissSetupInstructions() {
        isOnboarding = false
        _lensState.value = LensState.Browsing(
            isTremorAssistanceActive = _tremorProfile.value.isTremorAssistanceEnabled,
            detectedObjectsInView = if (activeHeadline.isNotBlank()) listOf(activeHeadline) else emptyList(),
            isPeripheralSettingsVisible = false
        )
    }

    // ========================================================================
    // Gesture Filtering: Single-Tap (Peripheral Settings) & Double-Tap (Bubble)
    // ========================================================================

    fun onSingleTap() {
        _isPeripheralSettingsVisible.value = true
        hideSettingsJob?.cancel()
        hideSettingsJob = viewModelScope.launch {
            delay(5000L)
            _isPeripheralSettingsVisible.value = false
        }
    }

    fun onDoubleTap(targetObjectId: String = activeObjectId, tapX: Float = -1f, tapY: Float = -1f) {
        // With Gemini: select the whole object at the tap point, anywhere in view
        val frameForSearch = _liveFullFrameBitmap.value
        if (GeminiClient.isConfigured && frameForSearch != null && tapX in 0f..1f && tapY in 0f..1f) {
            findAndSelect(frameForSearch, tapX, tapY)
            return
        }
        activeObjectId = targetObjectId
        val headline = activeHeadline.ifBlank { "Scanned Item" }
        val rawText = activeRawOcr.ifBlank {
            "Point your camera at any postcard, document, food package, or label to scan."
        }
        activeRawOcr = rawText
        activeHeadline = headline

        val inferredCategory = geminiAssistant.detectObjectCategory(headline, rawText)
        val grip = gripService.getStableGripForObject(inferredCategory, _tremorProfile.value)

        // Freeze a rock-steady high-resolution snapshot at the moment of double-tap
        _isMagnifierFrozen.value = true
        val frozenCrop = _liveCroppedBitmap.value ?: _liveFullFrameBitmap.value
        val frozenFull = _liveFullFrameBitmap.value

        val target = ScannedObjectTarget(
            id = targetObjectId,
            title = headline,
            category = inferredCategory.lowercase().replace('_', ' '),
            rawText = rawText,
            grip = grip,
            boundingBox = _liveDetectedBox.value,
            textBlockBoxes = _liveTextBlockBoxes.value,
            confidence = if (_liveTextBlockBoxes.value.isNotEmpty()) 0.97f else 0.88f,
            capturedBitmap = frozenCrop,
            fullFrameBitmap = frozenFull
        )

        val actions = mutableListOf<LensAction>()
        actions.add(LensAction.MAGNIFY)
        actions.add(LensAction.SUMMARIZE)

        if (_tremorProfile.value.isTremorAssistanceEnabled && _tremorProfile.value.isShowGripEnabled) {
            actions.add(LensAction.HOW_TO_HOLD)
        }
        actions.add(LensAction.CLOSE)

        _lensState.value = LensState.ObjectTargeted(
            target = target,
            availableActions = actions
        )
    }

    // ========================================================================
    // Whole-object selection: Gemini finds the object at the tap point.
    // People, faces and hands are never selected.
    // ========================================================================

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()
    private var statusJob: Job? = null
    private var findJob: Job? = null

    private fun showStatus(message: String?, durationMs: Long = 3500L) {
        statusJob?.cancel()
        _statusMessage.value = message
        if (message != null) {
            statusJob = viewModelScope.launch {
                delay(durationMs)
                _statusMessage.value = null
            }
        }
    }

    private fun bubbleActions(): List<LensAction> {
        val actions = mutableListOf(LensAction.MAGNIFY, LensAction.SUMMARIZE)
        if (_tremorProfile.value.isTremorAssistanceEnabled && _tremorProfile.value.isShowGripEnabled) {
            actions.add(LensAction.HOW_TO_HOLD)
        }
        actions.add(LensAction.CLOSE)
        return actions
    }

    private fun cropToBox(src: Bitmap, box: NormalizedRect): Bitmap {
        val l = (box.left * src.width).toInt().coerceIn(0, src.width - 1)
        val t = (box.top * src.height).toInt().coerceIn(0, src.height - 1)
        val r = (box.right * src.width).toInt().coerceIn(l + 1, src.width)
        val b = (box.bottom * src.height).toInt().coerceIn(t + 1, src.height)
        return Bitmap.createBitmap(src, l, t, r - l, b - t)
    }

    private fun findAndSelect(frame: Bitmap, tapX: Float, tapY: Float) {
        findJob?.cancel()
        _isSettingsOpen.value = false
        showStatus("Finding it…", 30000L)
        val frozen = frame.copy(frame.config ?: Bitmap.Config.ARGB_8888, false)
        findJob = viewModelScope.launch {
            val result = runCatching { GeminiClient.findObject(frozen, tapX, tapY) }
            val found = result.getOrNull()
            when {
                result.isFailure -> showStatus(result.exceptionOrNull()?.message ?: "Couldn't reach Gemini.", 6000L)
                found == null -> showStatus("Nothing to read there. Double-tap on the object itself.")
                found.isPerson -> showStatus("The lens doesn't select people. Double-tap the object instead.")
                else -> {
                    showStatus(null)
                    val category = geminiAssistant.detectObjectCategory(found.label, activeRawOcr)
                    val target = ScannedObjectTarget(
                        id = "found_${System.currentTimeMillis()}",
                        title = found.label,
                        category = found.label.lowercase(),
                        rawText = activeRawOcr,
                        grip = gripService.getStableGripForObject(category, _tremorProfile.value),
                        boundingBox = found.box,
                        textBlockBoxes = emptyList(),
                        confidence = 0.95f,
                        capturedBitmap = cropToBox(frozen, found.box),
                        fullFrameBitmap = frozen
                    )
                    activeHeadline = found.label
                    _isMagnifierFrozen.value = true
                    _lensState.value = LensState.ObjectTargeted(target = target, availableActions = bubbleActions())
                }
            }
        }
    }

    fun onSelectTargetAction(action: LensAction) {
        val currentState = _lensState.value
        if (currentState !is LensState.ObjectTargeted) return

        val target = currentState.target
        when (action) {
            LensAction.CLOSE -> {
                _lensState.value = LensState.Browsing(
                    isTremorAssistanceActive = _tremorProfile.value.isTremorAssistanceEnabled,
                    detectedObjectsInView = listOf(target.title),
                    isPeripheralSettingsVisible = false
                )
            }

            LensAction.MAGNIFY -> {
                val lines = target.rawText.lines().map { it.trim() }.filter { it.isNotBlank() }
                val mainLine = lines.firstOrNull() ?: target.title
                val subDetails = lines.drop(1)
                val chips = geminiAssistant.getInitialChipsForAction(target.title, LensAction.MAGNIFY, target.rawText)

                _lensState.value = LensState.PanelExpanded(
                    target = target,
                    selectedAction = LensAction.MAGNIFY,
                    resultTitle = mainLine,
                    resultDetails = subDetails,
                    aiChips = chips,
                    conversationLog = emptyList()
                )

                // Read the exact print from the photo of this object, not the whole frame
                if (GeminiClient.isConfigured && target.capturedBitmap != null) {
                    val expanded = _lensState.value as? LensState.PanelExpanded
                    if (expanded != null) {
                        _lensState.value = expanded.copy(isAiThinking = true)
                        viewModelScope.launch {
                            val text = runCatching {
                                GeminiClient.generate(
                                    "Write out all the printed text in this image exactly, one line per line of print. " +
                                        "Do not summarise or add anything. Write [unclear] for any part you cannot read. " +
                                        "If there is no print, say: I can't find any print here.",
                                    target.capturedBitmap
                                )
                            }.getOrElse { "I couldn't reach Gemini (${it.message})." }
                            val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
                            val now = _lensState.value
                            if (now is LensState.PanelExpanded && now.selectedAction == LensAction.MAGNIFY && now.target.id == target.id) {
                                _lensState.value = now.copy(
                                    resultTitle = lines.firstOrNull() ?: target.title,
                                    resultDetails = lines.drop(1),
                                    isAiThinking = false
                                )
                            }
                        }
                    }
                }
            }

            LensAction.SUMMARIZE -> {
                val summary = summarizerService.summarizeObject(target.rawText)
                val details = summary.chips.map {
                    if (it.icon.isNotBlank()) "${it.icon} ${it.category}: ${it.verbatimValue}"
                    else "${it.category}: ${it.verbatimValue}"
                }
                val chips = geminiAssistant.getInitialChipsForAction(target.title, LensAction.SUMMARIZE, target.rawText)

                _lensState.value = LensState.PanelExpanded(
                    target = target,
                    selectedAction = LensAction.SUMMARIZE,
                    resultTitle = summary.dynamicTitle,
                    resultDetails = details,
                    aiChips = chips,
                    conversationLog = emptyList()
                )

                // Replace the on-device summary with a real Gemini summary when a key is set
                if (GeminiClient.isConfigured) {
                    val expanded = _lensState.value as? LensState.PanelExpanded
                    if (expanded != null) {
                        _lensState.value = expanded.copy(isAiThinking = true)
                        viewModelScope.launch {
                            val (answer, newChips) = geminiAssistant.queryGemini(
                                objectTitle = target.title,
                                ocrContext = target.rawText,
                                userPrompt = "Summarize this in two or three short sentences: what it is and the most important thing to do.",
                                voice = _assistantVoice.value,
                                image = target.capturedBitmap ?: target.fullFrameBitmap
                            )
                            val now = _lensState.value
                            if (now is LensState.PanelExpanded && now.selectedAction == LensAction.SUMMARIZE && now.target.id == target.id) {
                                _lensState.value = now.copy(
                                    resultTitle = target.title,
                                    resultDetails = listOf(answer),
                                    aiChips = newChips,
                                    isAiThinking = false
                                )
                            }
                            onSpeakTextListener?.invoke(answer, _assistantVoice.value)
                        }
                    }
                }
            }

            LensAction.HOW_TO_HOLD -> {
                val inferredCategory = geminiAssistant.detectObjectCategory(target.title, target.rawText)
                val grip = target.grip ?: gripService.getStableGripForObject(inferredCategory, _tremorProfile.value)
                val details = listOf(
                    "Grip Style: ${grip.title}",
                    "Posture: ${grip.description}",
                    if (grip.braceElbow) "Surface Brace: Rest forearms or elbows on table surface to dampen tremor amplitude by 85%" else "Elbow Free",
                    "Hand Pose Hint: ${grip.visualHandPoseHint}"
                )
                val chips = geminiAssistant.getInitialChipsForAction(target.title, LensAction.HOW_TO_HOLD, target.rawText)

                _lensState.value = LensState.PanelExpanded(
                    target = target,
                    selectedAction = LensAction.HOW_TO_HOLD,
                    resultTitle = grip.title,
                    resultDetails = details,
                    aiChips = chips,
                    conversationLog = emptyList()
                )
            }

            else -> {}
        }
    }

    fun onAiChipClicked(chip: AiResponseChip) {
        val current = _lensState.value
        if (current !is LensState.PanelExpanded) return

        val target = current.target
        val userMsg = AiChatMessage(isGemini = false, text = chip.prompt)
        val updatedLog = current.conversationLog + userMsg

        _lensState.value = current.copy(
            conversationLog = updatedLog,
            isAiThinking = true
        )

        viewModelScope.launch {
            val (response, newChips) = geminiAssistant.queryGemini(
                objectTitle = target.title,
                ocrContext = target.rawText,
                userPrompt = chip.prompt,
                voice = _assistantVoice.value,
                image = target.capturedBitmap ?: target.fullFrameBitmap
            )

            _lensState.value = current.copy(
                conversationLog = updatedLog + AiChatMessage(isGemini = true, text = response),
                aiChips = newChips,
                isAiThinking = false
            )
            onSpeakTextListener?.invoke(response, _assistantVoice.value)
        }
    }

    fun setCameraSurfaceProvider(provider: Preview.SurfaceProvider) {
        _cameraSurfaceProvider.value = provider
    }

    fun toggleWebcamPreview() {
        _isWebcamPreviewVisible.value = !_isWebcamPreviewVisible.value
    }

    fun toggleVoiceListening() {
        val next = !_isVoiceListening.value
        _isVoiceListening.value = next
        if (next) {
            val startedHardwareMic = onStartSpeechListeningListener?.invoke() ?: false
            val onQuest = android.os.Build.MANUFACTURER.equals("Oculus", ignoreCase = true) ||
                android.os.Build.MANUFACTURER.contains("Meta", ignoreCase = true)
            if (!startedHardwareMic && onQuest) {
                // Quest has no Google speech recognition: say so instead of guessing a question
                _isVoiceListening.value = false
                showStatus("Voice input isn't available on this headset. Type your question instead.", 5000L)
            } else if (!startedHardwareMic) {
                viewModelScope.launch {
                    delay(2000L)
                    if (_isVoiceListening.value) {
                        _isVoiceListening.value = false
                        askCustomQuestion("What is the main message written on this and can you read it aloud?")
                    }
                }
            }
        }
    }

    fun onSpeechRecognized(spokenText: String) {
        _isVoiceListening.value = false
        if (spokenText.isNotBlank()) {
            askCustomQuestion(spokenText)
        }
    }

    fun onSpeechRecognitionFallback() {
        if (_isVoiceListening.value) {
            _isVoiceListening.value = false
            askCustomQuestion("What is the main message written on this and can you read it aloud?")
        }
    }

    fun askCustomQuestion(questionText: String) {
        val trimmed = questionText.trim()
        if (trimmed.isBlank()) return

        val current = _lensState.value
        val (target, existingLog) = when (current) {
            is LensState.PanelExpanded -> current.target to current.conversationLog
            is LensState.ObjectTargeted -> current.target to emptyList()
            else -> return
        }

        val userMsg = AiChatMessage(isGemini = false, text = trimmed)
        val updatedLog = existingLog + userMsg

        _lensState.value = LensState.PanelExpanded(
            target = target,
            selectedAction = (current as? LensState.PanelExpanded)?.selectedAction ?: LensAction.SUMMARIZE,
            resultTitle = (current as? LensState.PanelExpanded)?.resultTitle ?: target.title,
            resultDetails = (current as? LensState.PanelExpanded)?.resultDetails ?: listOf(target.rawText),
            aiChips = (current as? LensState.PanelExpanded)?.aiChips ?: geminiAssistant.getInitialChipsForAction(target.title, LensAction.SUMMARIZE, target.rawText),
            conversationLog = updatedLog,
            isAiThinking = true
        )

        viewModelScope.launch {
            val (response, newChips) = geminiAssistant.queryGemini(
                objectTitle = target.title,
                ocrContext = target.rawText,
                userPrompt = trimmed,
                voice = _assistantVoice.value,
                image = target.capturedBitmap ?: target.fullFrameBitmap
            )

            val activeNow = _lensState.value
            if (activeNow is LensState.PanelExpanded) {
                _lensState.value = activeNow.copy(
                    conversationLog = updatedLog + AiChatMessage(isGemini = true, text = response),
                    aiChips = newChips,
                    isAiThinking = false
                )
            }
            onSpeakTextListener?.invoke(response, _assistantVoice.value)
        }
    }

    fun startTremorCalibrationWizard() {
        _isSettingsOpen.value = false
        startCalibrationFlow()
    }

    fun exitCalibration() {
        _lensState.value = LensState.Browsing(
            isTremorAssistanceActive = _tremorProfile.value.isTremorAssistanceEnabled,
            detectedObjectsInView = if (activeHeadline.isNotBlank()) listOf(activeHeadline) else emptyList()
        )
    }

    fun closeExpandedPanel() {
        val current = _lensState.value
        if (current is LensState.PanelExpanded) {
            val actions = mutableListOf(LensAction.MAGNIFY, LensAction.SUMMARIZE)
            if (_tremorProfile.value.isTremorAssistanceEnabled && _tremorProfile.value.isShowGripEnabled) {
                actions.add(LensAction.HOW_TO_HOLD)
            }
            actions.add(LensAction.CLOSE)
            _lensState.value = LensState.ObjectTargeted(current.target, actions)
        } else {
            _lensState.value = LensState.Browsing(
                isTremorAssistanceActive = _tremorProfile.value.isTremorAssistanceEnabled
            )
        }
    }

    fun dismissTarget() {
        _lensState.value = LensState.Browsing(
            isTremorAssistanceActive = _tremorProfile.value.isTremorAssistanceEnabled,
            detectedObjectsInView = if (activeHeadline.isNotBlank()) listOf(activeHeadline) else emptyList()
        )
    }

    // ========================================================================
    // Accessibility Settings Hub (§3.1, §3.5)
    // ========================================================================

    fun openSettings() {
        _isSettingsOpen.value = true
        _isPeripheralSettingsVisible.value = false
        hideSettingsJob?.cancel()
    }

    fun closeSettings() {
        _isSettingsOpen.value = false
    }

    fun toggleTremorAssistance(enabled: Boolean) {
        val updatedProfile = _tremorProfile.value.copy(
            isTremorAssistanceEnabled = enabled,
            // If tremor assistance is turned off, show grip cannot be active
            isShowGripEnabled = if (!enabled) false else _tremorProfile.value.isShowGripEnabled
        )
        _tremorProfile.value = updatedProfile
        tapFilter.profile = updatedProfile

        // Reactively update ObjectTargeted actions if open
        val current = _lensState.value
        if (current is LensState.ObjectTargeted) {
            val actions = mutableListOf(LensAction.MAGNIFY, LensAction.SUMMARIZE)
            if (enabled && updatedProfile.isShowGripEnabled) {
                actions.add(LensAction.HOW_TO_HOLD)
            }
            actions.add(LensAction.CLOSE)
            _lensState.value = current.copy(availableActions = actions)
        }
    }

    fun toggleShowGrip(enabled: Boolean) {
        if (!_tremorProfile.value.isTremorAssistanceEnabled) return
        val updatedProfile = _tremorProfile.value.copy(isShowGripEnabled = enabled)
        _tremorProfile.value = updatedProfile

        // Reactively update ObjectTargeted actions if open
        val current = _lensState.value
        if (current is LensState.ObjectTargeted) {
            val actions = mutableListOf(LensAction.MAGNIFY, LensAction.SUMMARIZE)
            if (enabled) {
                actions.add(LensAction.HOW_TO_HOLD)
            }
            actions.add(LensAction.CLOSE)
            _lensState.value = current.copy(availableActions = actions)
        }
    }

    fun updateTextSizeDegrees(degrees: Float) {
        _textSizePreference.value = _textSizePreference.value.setDegrees(degrees)
    }

    fun stepTextSizeUp() {
        _textSizePreference.value = _textSizePreference.value.stepUp()
        if (_lensState.value is LensState.Calibrating) {
            _lensState.value = LensState.Calibrating(CalibrationStep.TextSize(_textSizePreference.value))
        }
    }

    fun stepTextSizeDown() {
        _textSizePreference.value = _textSizePreference.value.stepDown()
        if (_lensState.value is LensState.Calibrating) {
            _lensState.value = LensState.Calibrating(CalibrationStep.TextSize(_textSizePreference.value))
        }
    }

    fun setAssistantVoice(voice: AssistantVoice) {
        _assistantVoice.value = voice
    }

    fun setAssistantMode(mode: AssistantMode) {
        _assistantMode.value = mode
    }

    fun setAiProcessing(pref: AiProcessingPreference) {
        _aiProcessing.value = pref
    }

    fun toggleTremorAssistance() {
        toggleTremorAssistance(!_tremorProfile.value.isTremorAssistanceEnabled)
    }

    // ========================================================================
    // Calibration Wizard & Legacy Compatibility (§3.1, §3.2, §3.3)
    // ========================================================================

    fun onTwoHandStretchZoom(leftPalm: Vec3Meters, rightPalm: Vec3Meters) {
        val updated = tapFilter.evaluateTwoHandStretch(leftPalm, rightPalm, _textSizePreference.value)
        _textSizePreference.value = updated
    }

    fun startCalibrationFlow() {
        _isSettingsOpen.value = false
        _lensState.value = LensState.Calibrating(
            CalibrationStep.RestMeasurement(secondsRemaining = 5, currentJitterMeters = _handTrackingTelemetry.value.jitterMm / 1000f)
        )
    }

    fun advanceCalibrationStep() {
        val current = _lensState.value
        if (current !is LensState.Calibrating) return

        when (val step = current.step) {
            is CalibrationStep.TextSize -> {
                if (isOnboarding) {
                    _lensState.value = LensState.SetupInstructions
                } else {
                    exitCalibration()
                }
            }
            is CalibrationStep.RestMeasurement -> {
                restJitterMm = _handTrackingTelemetry.value.jitterMm
                calibrationTapTimes.clear()
                _lensState.value = LensState.Calibrating(
                    CalibrationStep.TapMeasurement(tapsCompleted = 0)
                )
            }
            is CalibrationStep.TapMeasurement -> {
                calibrationTapTimes.add(System.currentTimeMillis())
                if (step.tapsCompleted + 1 >= step.totalTapsRequired) {
                    _lensState.value = LensState.Calibrating(
                        CalibrationStep.AimMeasurement(targetsHit = 0)
                    )
                } else {
                    _lensState.value = LensState.Calibrating(
                        step.copy(tapsCompleted = step.tapsCompleted + 1)
                    )
                }
            }
            is CalibrationStep.AimMeasurement -> {
                if (step.targetsHit + 1 >= step.totalTargets) {
                    // Use what was actually measured: resting jitter and the user's own tap rhythm
                    val gaps = calibrationTapTimes.zipWithNext { a, b -> b - a }.sorted()
                    val medianGap = if (gaps.isNotEmpty()) gaps[gaps.size / 2] else 900L
                    val calibratedProfile = _tremorProfile.value.copy(
                        tremorAmplitudeMeters = (restJitterMm / 1000f).coerceIn(0.002f, 0.08f),
                        tapVelocityThresholdMps = 0.38f,
                        refractoryWindowMs = (medianGap * 0.35f).toLong().coerceIn(150L, 600L),
                        aimConeDegrees = 24.0f
                    )
                    _tremorProfile.value = calibratedProfile
                    tapFilter.profile = calibratedProfile
                    _lensState.value = LensState.Calibrating(CalibrationStep.Completed(calibratedProfile))
                } else {
                    _lensState.value = LensState.Calibrating(
                        step.copy(targetsHit = step.targetsHit + 1)
                    )
                }
            }
            is CalibrationStep.Completed -> {
                if (isOnboarding) {
                    _lensState.value = LensState.Calibrating(CalibrationStep.TextSize(_textSizePreference.value))
                    return
                }
                _lensState.value = LensState.Browsing(
                    isTremorAssistanceActive = _tremorProfile.value.isTremorAssistanceEnabled,
                    detectedObjectsInView = if (activeHeadline.isNotBlank()) listOf(activeHeadline) else emptyList()
                )
            }
        }
    }

    fun onDirectionalTap(
        handStrikeVelocityMps: Float,
        timestampMs: Long,
        targetObjectId: String = activeObjectId
    ) {
        val isValidStrike = tapFilter.evaluateTapStrike(handStrikeVelocityMps, timestampMs)
        if (!isValidStrike) return

        activeObjectId = targetObjectId
        val label = activeHeadline.ifBlank { "Pointed Object" }
        _lensState.value = LensState.ObjectSelected(
            objectId = targetObjectId,
            label = label,
            isConfirmed = false
        )
    }

    fun confirmObjectSelection() {
        val availableActions = if (_tremorProfile.value.isTremorAssistanceEnabled) {
            listOf(
                LensAction.MAGNIFY,
                LensAction.SUMMARIZE,
                LensAction.HOW_TO_HOLD,
                LensAction.ASK
            )
        } else {
            listOf(
                LensAction.MAGNIFY,
                LensAction.SUMMARIZE,
                LensAction.ASK
            )
        }

        _lensState.value = LensState.ActionMenu(
            objectId = activeObjectId,
            actions = availableActions
        )
    }

    fun dismissObjectSelection() {
        _lensState.value = LensState.Browsing(
            isTremorAssistanceActive = _tremorProfile.value.isTremorAssistanceEnabled,
            detectedObjectsInView = if (activeHeadline.isNotBlank()) listOf(activeHeadline) else emptyList()
        )
    }

    fun executeAction(action: LensAction) {
        when (action) {
            LensAction.MAGNIFY -> {
                val lines = activeRawOcr.lines().map { it.trim() }.filter { it.isNotBlank() }
                if (lines.isEmpty()) {
                    onReadProblemEncountered(ReadProblem.UNKNOWN_OBJECT)
                    return
                }

                val result = ocrStabilizer.ingestFrameText(lines, System.currentTimeMillis())
                if (result.diagnosedProblem != null) {
                    onReadProblemEncountered(result.diagnosedProblem)
                } else {
                    _lensState.value = LensState.Magnified(
                        keyText = result.consolidatedHeadline.ifBlank { activeHeadline },
                        subText = result.fullConsolidatedText,
                        confidence = result.confidence
                    )
                }
            }

            LensAction.SUMMARIZE -> {
                if (activeRawOcr.isBlank()) {
                    onReadProblemEncountered(ReadProblem.UNKNOWN_OBJECT)
                    return
                }

                val summary = summarizerService.summarizeObject(activeRawOcr)
                _lensState.value = LensState.SummaryChips(
                    title = summary.dynamicTitle,
                    chips = summary.chips,
                    rawOcrText = activeRawOcr
                )
            }

            LensAction.HOW_TO_HOLD -> {
                val inferredType = inferObjectTypeFromText(activeRawOcr)
                val recommendation = gripService.getStableGripForObject(
                    objectType = inferredType,
                    tremorProfile = _tremorProfile.value
                )
                _lensState.value = LensState.GripGuidance(
                    objectType = activeHeadline.ifBlank { inferredType.lowercase().replace('_', ' ') },
                    grip = recommendation
                )
            }

            LensAction.TRANSLATE -> {
                val summary = summarizerService.summarizeObject(activeRawOcr)
                _lensState.value = LensState.Magnified(
                    keyText = summary.dynamicTitle,
                    subText = "Live translation of: ${summary.fullText.take(150)}",
                    confidence = 0.95f
                )
            }

            LensAction.ASK -> {
                _lensState.value = LensState.Guidance(
                    problem = ReadProblem.UNKNOWN_OBJECT,
                    instruction = "What would you like to know about ${activeHeadline.ifBlank { "this item" }}?",
                    options = listOf(
                        GuidanceOption("Read All Visible Text", GuidanceOption.ActionType.READ_VISIBLE_TEXT_ANYWAY),
                        GuidanceOption("Ask Gemini Assistant", GuidanceOption.ActionType.ASK_ONLINE_CLOUD),
                        GuidanceOption("Back to Menu", GuidanceOption.ActionType.CANCEL)
                    )
                )
            }

            LensAction.CLOSE -> {
                _lensState.value = LensState.Browsing(
                    isTremorAssistanceActive = _tremorProfile.value.isTremorAssistanceEnabled
                )
            }
        }
    }

    fun selectSummaryChip(chip: SummaryChip) {
        _lensState.value = LensState.ChipDetail(
            chip = chip,
            parentTitle = activeHeadline.ifBlank { "Scanned Object" }
        )
    }

    fun backToSummary() {
        val summary = summarizerService.summarizeObject(activeRawOcr)
        _lensState.value = LensState.SummaryChips(
            title = summary.dynamicTitle,
            chips = summary.chips,
            rawOcrText = activeRawOcr
        )
    }

    fun backToActionMenu() {
        confirmObjectSelection()
    }

    fun onReadProblemEncountered(problem: ReadProblem) {
        val options = when (problem) {
            ReadProblem.BLURRY_SHAKING -> listOf(
                GuidanceOption("Rest on Table Surface", GuidanceOption.ActionType.SET_ON_TABLE),
                GuidanceOption("Try Scanning Again", GuidanceOption.ActionType.RETRY_SCAN),
                GuidanceOption("Back", GuidanceOption.ActionType.CANCEL)
            )
            ReadProblem.UNKNOWN_OBJECT -> listOf(
                GuidanceOption("Read Visible Text Anyway", GuidanceOption.ActionType.READ_VISIBLE_TEXT_ANYWAY),
                GuidanceOption("Describe to Assistant", GuidanceOption.ActionType.DESCRIBE_TO_ASSISTANT),
                GuidanceOption("Identify Online (Cloud)", GuidanceOption.ActionType.ASK_ONLINE_CLOUD),
                GuidanceOption("Try Again", GuidanceOption.ActionType.RETRY_SCAN)
            )
            else -> listOf(
                GuidanceOption("Try Scanning Again", GuidanceOption.ActionType.RETRY_SCAN),
                GuidanceOption("Read Visible Text Anyway", GuidanceOption.ActionType.READ_VISIBLE_TEXT_ANYWAY),
                GuidanceOption("Back", GuidanceOption.ActionType.CANCEL)
            )
        }

        _lensState.value = LensState.Guidance(
            problem = problem,
            instruction = problem.detail,
            options = options
        )
    }

    fun executeGuidanceOption(option: GuidanceOption) {
        when (option.actionType) {
            GuidanceOption.ActionType.RETRY_SCAN -> {
                ocrStabilizer.reset()
                executeAction(LensAction.MAGNIFY)
            }
            GuidanceOption.ActionType.READ_VISIBLE_TEXT_ANYWAY -> {
                val lines = activeRawOcr.lines().map { it.trim() }.filter { it.isNotBlank() }
                _lensState.value = LensState.Magnified(
                    keyText = lines.firstOrNull() ?: activeHeadline,
                    subText = activeRawOcr,
                    confidence = 0.50f
                )
            }
            GuidanceOption.ActionType.SET_ON_TABLE -> {
                spatialGroundingManager.onHorizontalSurfaceDetected()
                executeAction(LensAction.MAGNIFY)
            }
            GuidanceOption.ActionType.DESCRIBE_TO_ASSISTANT,
            GuidanceOption.ActionType.ASK_ONLINE_CLOUD -> {
                _lensState.value = LensState.Magnified(
                    keyText = "IDENTIFIED: $activeHeadline",
                    subText = "Verified via Gemini Assistant ($activeRawOcr)",
                    confidence = 0.99f
                )
            }
            GuidanceOption.ActionType.CANCEL -> {
                backToActionMenu()
            }
        }
    }

    private fun inferObjectTypeFromText(text: String): String {
        val upper = text.uppercase()
        return when {
            upper.contains("TABLET") || upper.contains("CAPSULE") || upper.contains("MG") || upper.contains("RX") -> "PILL_BOTTLE"
            upper.contains("FL OZ") || upper.contains("BEVERAGE") || upper.contains("ML") || upper.contains("DRINK") -> "MUG"
            upper.contains("PAGE") || upper.contains("INVOICE") || upper.contains("DEAR") || upper.contains("STATEMENT") -> "PAPER_DOCUMENT"
            else -> "OBJECT"
        }
    }

    override fun onCleared() {
        super.onCleared()
        ocrPipeline.close()
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
