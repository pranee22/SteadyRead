﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.spatial

import androidx.xr.arcore.Anchor
import androidx.xr.arcore.AnchorCreateSuccess
import androidx.xr.arcore.Plane
import androidx.xr.runtime.Session
import androidx.xr.arcore.TrackingState
import androidx.xr.arcore.PlaneType
import androidx.xr.arcore.PlaneLabel
import androidx.xr.runtime.math.Pose
import androidx.xr.runtime.math.Quaternion
import androidx.xr.runtime.math.Vector3
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.sqrt

/**
 * 3D Point / Vector in world-space meters.
  * Developed by Praneetha Kamabathula.
 */
data class Vec3Meters(
    val x: Float,
    val y: Float,
    val z: Float
) {
    fun distanceTo(other: Vec3Meters): Float {
        val dx = x - other.x
        val dy = y - other.y
        val dz = z - other.z
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    operator fun plus(other: Vec3Meters) = Vec3Meters(x + other.x, y + other.y, z + other.z)
}

/**
 * Represents a dropped spatial anchor (ARNode) placed in front of the stationary physical object
 * on a detected horizontal table surface to host the stabilized Glimmer UI viewport.
 */
data class SpatialARNode(
    val nodeId: String,
    val tablePlanePose: Vec3Meters,
    val anchorWorldPose: Vec3Meters,
    val objectBoundingCenter: Vec3Meters,
    val nativeAnchor: Anchor? = null
)

/**
 * Core State Machine for Spatial Grounding & OCR Pipeline:
 * Idle -> SurfaceFound -> ObjectLocked -> PrimaryRead (Magnified Key Field)
 *
 * Core Logic Constraint:
 * OCR text extraction is strictly prohibited in [Idle] and [SurfaceFound], or whenever
 * the physical object is in motion. The object must be placed at rest on the horizontal
 * table before transitioning to [ObjectLocked] and [PrimaryRead].
 */
sealed interface SteadyReadState {
    /** Scanning environment for a horizontal upward-facing surface (table/desk). */
    data object Idle : SteadyReadState

    /**
     * Horizontal table surface detected. Explicitly prompts the user to place the object
     * flat on the table so hand tremors are eliminated before scanning.
     */
    data class SurfaceFound(
        val tableCenterPose: Vec3Meters,
        val tableExtentsMeters: Pair<Float, Float>,
        val isObjectInMotion: Boolean = true,
        val currentObjectVelocityMps: Float = 0f
    ) : SteadyReadState

    /**
     * Object is confirmed stationary on the detected horizontal table.
     * A spatial anchor ([arNode]) is dropped directly in front of the object to host the UI.
     */
    data class ObjectLocked(
        val arNode: SpatialARNode
    ) : SteadyReadState

    /**
     * Primary Read (Magnified Key Field) state: Renders the stabilized, angular-scaled
     * OCR payload anchored to [arNode] with left/right 3D hand reach zones active.
     */
    data class PrimaryRead(
        val arNode: SpatialARNode,
        val activeFieldIndex: Int,
        val totalFields: Int,
        val keyFieldTitle: String,
        val magnifiedPayload: String
    ) : SteadyReadState
}

/**
 * Module 1: Spatial Tracking & Environmental Grounding Manager
 *
 * Responsibilities:
 * 1. Subscribes to `androidx.xr.arcore.Plane` to map horizontal upward-facing planes (tables).
 * 2. Enforces the Core Logic Constraint: NEVER attempts to read text while the object is in motion.
 *    Requires the object to be placed onto the horizontal plane with velocity <= [MAX_REST_VELOCITY_MPS]
 *    and vertical proximity to the plane Y coordinate <= [TABLE_CONTACT_TOLERANCE_METERS].
 * 3. Drops a spatial anchor ([SpatialARNode]) in front of the stationary object to host the UI.
 */
class SpatialGroundingManager {

    companion object {
        /** Maximum allowed velocity (m/s) for an object to be considered stationary on the table. */
        const val MAX_REST_VELOCITY_MPS = 0.015f

        /** Maximum vertical distance (meters) from the horizontal table plane to confirm placement. */
        const val TABLE_CONTACT_TOLERANCE_METERS = 0.04f

        /** Offset in meters toward the user (+Z) and upward (+Y) to place the UI ARNode in front of the object. */
        val UI_ARNODE_OFFSET = Vec3Meters(x = 0.0f, y = 0.11f, z = 0.09f)
    }

    private val _readerState = MutableStateFlow<SteadyReadState>(SteadyReadState.Idle)
    val readerState: StateFlow<SteadyReadState> = _readerState.asStateFlow()

    private var planeSubscriptionJob: Job? = null

    /**
     * Returns true ONLY when the physical object has been placed on a detected horizontal
     * surface, confirmed stationary, and anchored via an [SpatialARNode].
     */
    val isOcrAllowed: Boolean
        get() = when (_readerState.value) {
            is SteadyReadState.Idle,
            is SteadyReadState.SurfaceFound -> false
            is SteadyReadState.ObjectLocked,
            is SteadyReadState.PrimaryRead -> true
        }

    /**
     * Subscribes to ARCore for Jetpack XR (`Plane.subscribe(session)`) and filters for
     * horizontal upward-facing surfaces (tables/desks).
     */
    fun bindArCoreSession(scope: CoroutineScope, session: Session) {
        planeSubscriptionJob?.cancel()
        planeSubscriptionJob = scope.launch {
            Plane.subscribe(session).collectLatest { planes ->
                val horizontalTable = planes.firstOrNull { plane ->
                    val state = plane.state.value
                    state.trackingState == TrackingState.TRACKING &&
                        plane.type == PlaneType.HORIZONTAL_UPWARD_FACING &&
                        (state.label == PlaneLabel.TABLE || state.label == PlaneLabel.UNKNOWN)
                }

                if (horizontalTable != null) {
                    val planeState = horizontalTable.state.value
                    val pose = planeState.centerPose.translation
                    val tableCenter = Vec3Meters(pose.x, pose.y, pose.z)
                    val extents = planeState.extents.width to planeState.extents.height

                    if (_readerState.value is SteadyReadState.Idle) {
                        _readerState.value = SteadyReadState.SurfaceFound(
                            tableCenterPose = tableCenter,
                            tableExtentsMeters = extents,
                            isObjectInMotion = true,
                            currentObjectVelocityMps = 0f
                        )
                    }
                }
            }
        }
    }

    /**
     * Evaluates object motion and placement relative to the detected horizontal table plane.
     *
     * Core Logic Constraint:
     * - If `objectVelocityMps > MAX_REST_VELOCITY_MPS` OR the object is not resting on the table,
     *   the state remains in (or reverts to) [SteadyReadState.SurfaceFound], blocking OCR.
     * - Once the object is stationary on the horizontal surface, drops a spatial anchor ([SpatialARNode])
     *   in front of the object and transitions to [SteadyReadState.ObjectLocked].
     */
    fun evaluateObjectPlacement(
        objectPosition: Vec3Meters,
        objectVelocityMps: Float,
        session: Session? = null
    ): Boolean {
        val currentState = _readerState.value

        // Cannot lock an object before a horizontal plane has been mapped
        val tableCenter = when (currentState) {
            is SteadyReadState.Idle -> return false
            is SteadyReadState.SurfaceFound -> currentState.tableCenterPose
            is SteadyReadState.ObjectLocked -> currentState.arNode.tablePlanePose
            is SteadyReadState.PrimaryRead -> currentState.arNode.tablePlanePose
        }

        val verticalDistanceToTable = kotlin.math.abs(objectPosition.y - tableCenter.y)
        val isRestingOnTable = verticalDistanceToTable <= TABLE_CONTACT_TOLERANCE_METERS
        val isStationary = objectVelocityMps <= MAX_REST_VELOCITY_MPS

        if (!isRestingOnTable || !isStationary) {
            // Core Logic Constraint enforced: if object moves or is lifted off table, immediately
            // disengage lock and revert to SurfaceFound so OCR never runs on a moving object.
            _readerState.value = SteadyReadState.SurfaceFound(
                tableCenterPose = tableCenter,
                tableExtentsMeters = 0.60f to 0.45f,
                isObjectInMotion = !isStationary,
                currentObjectVelocityMps = objectVelocityMps
            )
            return false
        }

        // Object is stationary on the horizontal table: drop spatial ARNode in front of object
        val anchorPosition = objectPosition + UI_ARNODE_OFFSET
        val nativeAnchor = session?.let { xrSession ->
            val anchorPose = Pose(
                Vector3(anchorPosition.x, anchorPosition.y, anchorPosition.z),
                Quaternion.Identity
            )
            when (val result = Anchor.create(xrSession, anchorPose)) {
                is AnchorCreateSuccess -> result.anchor
                else -> null
            }
        }

        val arNode = SpatialARNode(
            nodeId = "ar_node_viewport_v1",
            tablePlanePose = tableCenter,
            anchorWorldPose = anchorPosition,
            objectBoundingCenter = objectPosition,
            nativeAnchor = nativeAnchor
        )

        _readerState.value = SteadyReadState.ObjectLocked(arNode = arNode)
        return true
    }

    /**
     * Simulates or triggers horizontal plane detection when testing without live hardware sensors.
     */
    fun onHorizontalSurfaceDetected(
        tableCenter: Vec3Meters = Vec3Meters(0.0f, -0.35f, -0.55f),
        extentsMeters: Pair<Float, Float> = 0.80f to 0.50f
    ) {
        _readerState.value = SteadyReadState.SurfaceFound(
            tableCenterPose = tableCenter,
            tableExtentsMeters = extentsMeters,
            isObjectInMotion = true,
            currentObjectVelocityMps = 0.12f
        )
    }

    /**
     * Transitions from [SteadyReadState.ObjectLocked] into [SteadyReadState.PrimaryRead]
     * with the stabilized, magnified key field payload.
     */
    fun transitionToPrimaryRead(
        activeFieldIndex: Int,
        totalFields: Int,
        keyFieldTitle: String,
        magnifiedPayload: String
    ) {
        val current = _readerState.value
        val arNode = when (current) {
            is SteadyReadState.ObjectLocked -> current.arNode
            is SteadyReadState.PrimaryRead -> current.arNode
            else -> return // Strictly refuse transition if object is not locked on horizontal surface
        }

        _readerState.value = SteadyReadState.PrimaryRead(
            arNode = arNode,
            activeFieldIndex = activeFieldIndex,
            totalFields = totalFields,
            keyFieldTitle = keyFieldTitle,
            magnifiedPayload = magnifiedPayload
        )
    }

    /**
     * Unlocks the current object and returns to [SteadyReadState.SurfaceFound] so the user
     * can reposition or place a new physical item on the table.
     */
    fun releaseObjectLock() {
        val current = _readerState.value
        val tablePose = when (current) {
            is SteadyReadState.ObjectLocked -> current.arNode.tablePlanePose
            is SteadyReadState.PrimaryRead -> current.arNode.tablePlanePose
            is SteadyReadState.SurfaceFound -> current.tableCenterPose
            is SteadyReadState.Idle -> Vec3Meters(0.0f, -0.35f, -0.55f)
        }
        _readerState.value = SteadyReadState.SurfaceFound(
            tableCenterPose = tablePose,
            tableExtentsMeters = 0.80f to 0.50f,
            isObjectInMotion = true,
            currentObjectVelocityMps = 0f
        )
    }

    fun resetToIdle() {
        _readerState.value = SteadyReadState.Idle
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
