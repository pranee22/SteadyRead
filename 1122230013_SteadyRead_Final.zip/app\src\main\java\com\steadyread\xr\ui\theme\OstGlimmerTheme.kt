﻿/*
 * SteadyRead XR — Spatial Assistive AR Reading System
 * Author: Praneetha Kamabathula
 * Copyright (c) 2026 Praneetha Kamabathula. All rights reserved.
 * Proprietary & Confidential — Academic / Research Prototype.
 */
package com.steadyread.xr.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.xr.glimmer.Colors
import androidx.xr.glimmer.GlimmerTheme
import androidx.xr.glimmer.Typography
import androidx.xr.glimmer.googlefonts.createGoogleSansFlexTypography
import kotlin.math.tan

/**
 * Visual Design System for AI Glasses (Optical See-Through Additive Waveguide Displays).
 *
 * Guidelines from developer.android.com/design/ui/ai-glasses/guides/foundations/made-for-glasses:
 * 1. The Real World IS the Background: Pure black (Color.Transparent / #000000) emits 0 light.
 *    No giant opaque black windows or nested "boxes in boxes".
 * 2. High Contrast & Glanceability: Dark subtle translucent scrims (30-40% opacity black) for cards.
 * 3. High-luminance white text with desaturated green (#9FD8A8) interactive accents.
 * 4. Peripheral placement: Scaffolding and cards sit at the side, keeping center vision open.
  * Developed by Praneetha Kamabathula.
 */
object OstOpticalPalette {
    val Transparent = Color.Transparent
    val WaveguideBlack = Color(0xFF000000)
    val CardScrim = Color(0x66000000) // 40% translucent black glass
    val GlassCardHover = Color(0x8C000000)
    val HighContrastWhite = Color(0xFFFFFFFF)
    val SecondaryText = Color(0xFFD8E6DC)
    val InteractiveGreen = Color(0xFF9FD8A8)
    val InteractiveGreenDim = Color(0x4D9FD8A8)
    val SurfaceDark = Color(0xFF121413)
}

@Immutable
data class SpatialAngularTypography(
    val titleAngleDegrees: Float = 1.4f,
    val bodyAngleDegrees: Float = 1.0f,
    val captionAngleDegrees: Float = 0.78f,
    val nominalViewingDistanceMeters: Float = 0.80f,
    val titleStyle: TextStyle,
    val bodyStyle: TextStyle,
    val captionStyle: TextStyle
) {
    fun computePhysicalHeightMm(angleDegrees: Float, distanceMeters: Float = nominalViewingDistanceMeters): Float {
        val halfAngleRad = Math.toRadians((angleDegrees / 2.0)).toFloat()
        return 2f * (distanceMeters * 1000f) * tan(halfAngleRad)
    }

    companion object {
        fun angleDegreesToSpatialSp(angleDegrees: Float): TextUnit {
            val baseSpPerDegree = 24f
            return (angleDegrees * baseSpPerDegree).sp
        }
    }
}

val LocalSpatialAngularTypography = staticCompositionLocalOf<SpatialAngularTypography> {
    error("LocalSpatialAngularTypography not initialized inside OstGlimmerTheme")
}

/** Text-size setting as a multiplier (1.0 = default). Applied to every fixed size via [ssp]. */
val LocalTextScale = staticCompositionLocalOf { 1f }

/** Like .sp, but follows the text-size setting so changes apply across the whole app. */
val Int.ssp: TextUnit
    @Composable
    @ReadOnlyComposable
    get() = (this * LocalTextScale.current).sp

@Composable
fun OstGlimmerTheme(
    bodyVisualAngleDegrees: Float = 1.0f,
    content: @Composable () -> Unit
) {
    // Official Glimmer Colors: primary, secondary, positive, negative, background, surface
    val ostGlimmerColors = Colors(
        primary = OstOpticalPalette.InteractiveGreen,
        secondary = OstOpticalPalette.SecondaryText,
        positive = OstOpticalPalette.InteractiveGreen,
        negative = Color(0xFFFFB4AB),
        background = OstOpticalPalette.WaveguideBlack,
        surface = OstOpticalPalette.SurfaceDark
    )

    val baseGlimmerTypography: Typography = createGoogleSansFlexTypography()

    val titleSp = (bodyVisualAngleDegrees * 1.4f * 24f).sp
    val bodySp = (bodyVisualAngleDegrees * 24f).sp
    val captionSp = (bodyVisualAngleDegrees * 0.78f * 24f).sp

    val angularTypography = SpatialAngularTypography(
        titleAngleDegrees = bodyVisualAngleDegrees * 1.4f,
        bodyAngleDegrees = bodyVisualAngleDegrees,
        captionAngleDegrees = bodyVisualAngleDegrees * 0.78f,
        titleStyle = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Bold,
            fontSize = titleSp,
            lineHeight = titleSp * 1.25f,
            color = OstOpticalPalette.HighContrastWhite
        ),
        bodyStyle = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Medium,
            fontSize = bodySp,
            lineHeight = bodySp * 1.35f,
            color = OstOpticalPalette.HighContrastWhite
        ),
        captionStyle = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Medium,
            fontSize = captionSp,
            lineHeight = captionSp * 1.3f,
            color = OstOpticalPalette.InteractiveGreen
        )
    )

    CompositionLocalProvider(
        LocalSpatialAngularTypography provides angularTypography,
        LocalTextScale provides bodyVisualAngleDegrees
    ) {
        GlimmerTheme(
            colors = ostGlimmerColors,
            typography = baseGlimmerTypography,
            content = content
        )
    }
}
// End of file — Authored by Praneetha Kamabathula (SteadyRead XR)
